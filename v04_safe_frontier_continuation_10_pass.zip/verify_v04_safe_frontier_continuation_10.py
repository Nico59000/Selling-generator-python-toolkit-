#!/usr/bin/env python3
from __future__ import annotations
import json,hashlib,sys,tempfile,zipfile,subprocess,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent
N=0

def ck(cond,msg):
 global N
 N+=1
 if not cond: raise AssertionError(msg)

def load(name): return json.loads((ROOT/name).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def selfless(d):
 x=dict(d); claimed=x.pop('sha256_without_self',None)
 raw=json.dumps(x,sort_keys=True,separators=(',',':')).encode()
 return claimed,hashlib.sha256(raw).hexdigest()
def verify_self(name):
 d=load(name);a,b=selfless(d);ck(a==b,f'selfless {name}');return d

cp=verify_self('V04_SAFE_FRONTIER_CONTINUATION_10_CHECKPOINT.json')
ck(cp['version']=='v0.4-continuation-10','checkpoint version')
ck(cp['status'].startswith('RESEARCH-CHECKPOINT'),'checkpoint state')
ck(sha(ROOT/'V04_SAFE_FRONTIER_CONTINUATION_9_CHECKPOINT.json')==cp['predecessor']['sha256'],'predecessor checkpoint hash')

c41=verify_self('V04_DEPTH41_2083_2130_CLASSIFICATION.json')
ck(c41['status']=='PASS-48/48-EXACT','d41 class status')
rows41=c41['results']; ck([r['id'] for r in rows41]==list(range(2083,2131)),'d41 ids')
ck(sum(len(r['ordinary_walls']) for r in rows41)==183,'d41 exits')
ck(not any(r.get('multiwall_components') for r in rows41),'d41 no multiwall')
for r in rows41:
 ck(set(r['ordinary_walls'])<=set('ghklmn'),f'd41 walls {r["id"]}')
 ck(isinstance(r.get('polynomials'),dict),f'd41 polys {r["id"]}')

q41=verify_self('V04_DEPTH41_2083_2130_QUOTIENT_TOOLKIT.json')
ck(q41['counts']=={'classes':48,'ordinary_exits':183,'hits':110,'new':73,'multiwall_cells':0},'q41 counts')
ck(q41['hit_buckets']=={'d40':69,'d41':34,'same-pass':6,'d31':1},'q41 buckets')
ck([n['id'] for n in q41['new_depth42_nodes']]==list(range(2451,2524)),'d42 ids')
ck(sum(e['status']=='HIT' for e in q41['events'])==110,'q41 hit event count')
ck(sum(e['status']=='NEW' for e in q41['events'])==73,'q41 new event count')
for e in q41['events']:
 ck(e['status'] in ('HIT','NEW'),'q41 event status')
 ck(0<=e['source']<=2130,'q41 source')

idx41=verify_self('V04_REPRESENTATIVE_INDEX_AFTER_D41.json')
ck(idx41['representative_count']==2524,'idx41 count')
ck([r['id'] for r in idx41['representatives']]==list(range(2524)),'idx41 contiguous')

c32=verify_self('V04_DEPTH32_2131_2450_CLASSIFICATION_SCC.json')
ck(c32['status']=='PASS-320/320-EXACT-SCC-BY-SCC','d32 class status')
rows32=c32['results'];ck([r['id'] for r in rows32]==list(range(2131,2451)),'d32 ids')
ck(c32['counts']=={'classes':320,'ordinary_exits':1164,'multiwall_cells':2},'d32 class counts')
ck(c32['multiwall_ids']==[2283,2450],'d32 multi ids')
for r in rows32:
 ck(set(r['ordinary_walls'])<=set('ghklmn'),f'd32 walls {r["id"]}')
 ck(r['enlarged_source_scc'] in (0,1),f'd32 scc {r["id"]}')
for rid in (2283,2450):
 r=next(x for x in rows32 if x['id']==rid)
 ck(r['multiwall_components']==[{'factor':'2*q + 5*r - 3','walls':['h','l']}],f'd32 multi {rid}')
# chunks exact cover
chunk_rows=[]
for p in sorted((ROOT/'d32_chunks').glob('*.json')):
 d=json.loads(p.read_text());a,b=selfless(d);ck(a==b,f'chunk self {p.name}');ck(d['status']=='NONPUBLISHABLE-CHUNK',f'chunk status {p.name}');chunk_rows += d['results']
ck(sorted(r['id'] for r in chunk_rows)==list(range(2131,2451)),'chunk cover')
ck(len({r['id'] for r in chunk_rows})==320,'chunk unique')

q32=verify_self('V04_DEPTH32_2131_2450_QUOTIENT_SCC_TOOLKIT.json')
ck(q32['counts']=={'classes':320,'ordinary_exits':1164,'hits':779,'new':385,'multiwall_cells':2},'q32 counts')
ck(q32['hit_buckets']=={'d31':394,'d32':296,'same-pass':88,'d42':1},'q32 buckets')
ck(q32['source_scc_counts']=={'0':{'exits':1151,'hits':773,'new':378},'1':{'exits':13,'hits':6,'new':7}},'q32 source counts')
ck([n['id'] for n in q32['new_depth33_nodes']]==list(range(2524,2909)),'d33 ids')
ck(q32['d32_internal_scc']['count']==172,'d32 internal scc count')
ck(q32['enlarged_d23_to_d32_scc']['sizes']==[1601,40,2,1,1,1,1],'enlarged scc sizes')
ck(q32['enlarged_d23_to_d32_scc']['vertex_count']==1647,'enlarged vertex count')
for e in q32['events']:
 ck(e['status'] in ('HIT','NEW'),'q32 event status')
 ck(e['enlarged_source_scc'] in (0,1),'q32 source scc')

idx32=verify_self('V04_REPRESENTATIVE_INDEX_AFTER_D32.json')
ck(idx32['representative_count']==2909,'idx32 count')
ck([r['id'] for r in idx32['representatives']]==list(range(2909)),'idx32 contiguous')

h1=verify_self('V04_SELLING_3D5D_DET_SWAP_H1_ZERO_NO_GO.json')['certificate']
ck(h1['relation_count']==17,'h1 relation count');ck(h1['all_relation_matrix_identities_exact'],'h1 relations exact')
ck(h1['constraint_rank']==30,'h1 constraint rank');ck(h1['relation_solution_dimension']==6,'h1 z dim');ck(h1['coboundary_rank']==6,'h1 b rank');ck(h1['H1_dimension']==0,'h1 zero')

est=verify_self('V04_TO_V05_RELEASE_ESTIMATE.json')
ck(est['status']=='PLANNING-ESTIMATE/NONMATHEMATICAL-NONBINDING','estimate type')
ck(est['estimate']['additional_passes_after_continuation_10']['range']==[3,5],'estimate range')
ck(len(est['proposed_release_gates'])==5,'estimate gates')

trep=verify_self('V04_SELLING_TOOLKIT_044_TEST_REPORT.json')
ck(trep['pytest']=='15/15 PASS','toolkit pytest report');ck(trep['installed_version']=='0.4.4','toolkit version report')
ck(sha(ROOT/'selling_toolkit-0.4.4-py3-none-any.whl')==trep['wheel_sha256'],'wheel hash')
ck(sha(ROOT/'selling_toolkit_v04_4_source.zip')==trep['source_zip_sha256'],'source hash')

r7=load('V04_R7_SOURCE_RHO_MARKED_SCREEN_EXTENDED.json')
# accept retained schema, require zero unrecycled evidence somewhere in serialized content
ck('unrecycled' in json.dumps(r7).lower(),'R7 schema mentions unrecycled')

# Dynamic replay from source toolkit
with tempfile.TemporaryDirectory() as td:
 td=Path(td); src=td/'src';src.mkdir()
 with zipfile.ZipFile(ROOT/'selling_toolkit_v04_4_source.zip') as z:z.extractall(src)
 sys.path.insert(0,str(src))
 import selling_toolkit
 ck(selling_toolkit.__version__=='0.4.4','source version')
 from selling_toolkit.layers import classify_exact
 from selling_toolkit.fast_layers import quotient_layer_fast,FastHitRange
 from selling_toolkit.cohomology import DeterminantSwapH1NoGo
 seed=load('toolchain/synthetic_invariant_Qa.seed.json')
 q40=load('V04_DEPTH40_1772_1820_QUOTIENT_TOOLKIT.json')
 q31=load('V04_DEPTH31_1821_2082_QUOTIENT_SCC_TOOLKIT.json')
 idx31=load('V04_REPRESENTATIVE_INDEX_AFTER_D31.json')['representatives']
 # deterministic exact sample reclassification d41
 sample41_ids={2083,2095,2107,2119,2130}; sample41=[n for n in q40['new_depth41_nodes'] if n['id'] in sample41_ids]
 rr=classify_exact(sample41,seed,workers=5)
 ck(len(rr)==5,'reclass d41 sample count')
 stored={r['id']:r for r in rows41}
 for r in rr:
  s=stored[r['id']]
  ck(r['ordinary_walls']==s['ordinary_walls'],f'reclass d41 walls {r["id"]}')
  ck(r.get('multiwall_components',[])==s.get('multiwall_components',[]),f'reclass d41 multi {r["id"]}')
 # selected d32 replay including both multiwalls
 sample_ids={2131,2283,2450}; sample=[n for n in q31['new_depth32_nodes'] if n['id'] in sample_ids]
 sr=classify_exact(sample,seed,workers=3); sm={r['id']:r for r in rows32}
 for r in sr:
  ck(r['ordinary_walls']==sm[r['id']]['ordinary_walls'],f'reclass d32 walls {r["id"]}')
  ck(r.get('multiwall_components',[])==sm[r['id']].get('multiwall_components',[]),f'reclass d32 multi {r["id"]}')
 # q41 exact fast replay
 ranges=[FastHitRange('d40',1772,1820),FastHitRange('d31',1821,2082),FastHitRange('d41',2083,2130),FastHitRange('d32',2131,2450)]
 qr=quotient_layer_fast(seed=seed,global_representatives=idx31,nodes=q40['new_depth41_nodes'],classifications=rows41,target_depth=42,kind='DEPTH42',layer_label='d42',hit_ranges=ranges)
 ck(qr['counts']==q41['counts'],'replay q41 counts');ck(qr['events']==q41['events'],'replay q41 events');ck(qr['new_nodes']==q41['new_depth42_nodes'],'replay q41 new')
 # q32 exact fast replay
 gprev=q31['enlarged_d23_d24_d25_d26_d27_d28_d29_d30_d31_scc']; source_scc={i:c['scc'] for c in gprev['components'] for i in c['ids']}
 ranges2=[FastHitRange('d31',1821,2082),FastHitRange('d41',2083,2130),FastHitRange('d32',2131,2450),FastHitRange('d42',2451,2523)]
 qr2=quotient_layer_fast(seed=seed,global_representatives=idx41['representatives'],nodes=q31['new_depth32_nodes'],classifications=rows32,target_depth=33,kind='DEPTH33',layer_label='d33',hit_ranges=ranges2,source_scc=source_scc)
 ck(qr2['counts']==q32['counts'],'replay q32 counts');ck(qr2['events']==q32['events'],'replay q32 events');ck(qr2['new_nodes']==q32['new_depth33_nodes'],'replay q32 new')
 hc=DeterminantSwapH1NoGo.certificate();ck(hc['H1_dimension']==0 and hc['constraint_rank']==30 and hc['coboundary_rank']==6,'dynamic H1 replay')
 # tests
 env=dict(__import__('os').environ);env['PYTHONPATH']=str(src);pr=subprocess.run([sys.executable,'-m','pytest','-q',str(src/'tests'/'test_toolkit.py')],capture_output=True,text=True,env=env)
 ck(pr.returncode==0 and '15 passed' in pr.stdout,'dynamic pytest')
 # wheel clean install and version
 target=td/'wheel'; target.mkdir()
 pi=subprocess.run([sys.executable,'-m','pip','install','--no-deps','--target',str(target),str(ROOT/'selling_toolkit-0.4.4-py3-none-any.whl')],capture_output=True,text=True)
 ck(pi.returncode==0,'wheel install')
 code=f"import sys;sys.path.insert(0,{str(target)!r});import selling_toolkit;print(selling_toolkit.__version__)"
 pv=subprocess.run([sys.executable,'-c',code],capture_output=True,text=True)
 ck(pv.returncode==0 and pv.stdout.strip()=='0.4.4','wheel version')

print(json.dumps({'status':'PASS','checks':N,'version':'v0.4-continuation-10'},indent=2))
