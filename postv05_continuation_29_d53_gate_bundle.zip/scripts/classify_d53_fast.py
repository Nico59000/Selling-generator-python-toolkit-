import os,json,sys,time,argparse
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import sympy as sp
from sympy.core.cache import clear_cache
BASE=Path('/mnt/data/cont29');sys.path.insert(0,'/mnt/data/cont28/toolkit_src')
from selling_seed2d.chart import build_chart
from selling_seed2d.classifier import ExactBoundaryClassifier
INDEX=Path('/mnt/data/cont28/POSTV05_REPRESENTATIVE_INDEX_AFTER_D43.json');SEED=Path('/mnt/data/cont26/final_stage/inputs/synthetic_invariant_Qa.seed.json')
RES=BASE/'fast_results';RES.mkdir(exist_ok=True);_G=None
class FastSignMixin:
 def root_sign(self, poly_r, root_poly, iv):
  r=self.r;G=sp.Poly(poly_r,r,domain=sp.QQ);F=sp.Poly(root_poly,r,domain=sp.QQ)
  if G.is_zero:return 0
  R=G.rem(F)
  if R.is_zero:return 0
  d=R.degree()
  if d<=0:
   v=R.LC();return 1 if v>0 else -1
  if d==1:
   a,b=R.all_coeffs();t=-b/a
   if F.eval(t)==0:return 0
   lo,hi=iv
   for _ in range(40):
    if hi<t:return -1 if a>0 else 1
    if t<lo:return 1 if a>0 else -1
    if lo==hi:return 1 if a*(lo-t)>0 else -1
    lo,hi=sp.refine_root(F,lo,hi,eps=(hi-lo)/10)
  return super().root_sign(poly_r,root_poly,iv)
class FastExactBoundaryClassifier(FastSignMixin,ExactBoundaryClassifier):pass
def load(p):return json.load(open(p,encoding='utf-8'))
def imat(rows):return sp.Matrix([[sp.Integer(v) for v in row] for row in rows])
def init_worker(seed):
 global _G
 c=build_chart(seed);_G=FastExactBoundaryClassifier(c.q,c.r,c.wall_vector,c.D0)
def worker(node):
 try:
  c=_G.classify_cell(imat(node['L']))
  return {'id':int(node['id']),'ordinary_walls':list(c['ordinary_walls']),'multiwall_components':[{'factor':z['factor'],'walls':list(z['walls'])} for z in c.get('multiwall_components',[])],'polynomials':c.get('polynomials',{})}
 finally:clear_cache()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--start',type=int,default=16875);ap.add_argument('--end',type=int,default=17361);ap.add_argument('--workers',type=int,default=5);ap.add_argument('--ids',nargs='*',type=int);a=ap.parse_args()
 reps=load(INDEX)['representatives'];ids=a.ids if a.ids else list(range(a.start,a.end+1));nodes=[reps[i] for i in ids];todo=[n for n in nodes if not (RES/f"{n['id']}.json").exists()]
 print('START',len(todo),flush=True);t=time.time();ok=0
 with ProcessPoolExecutor(max_workers=a.workers,initializer=init_worker,initargs=(load(SEED),)) as ex:
  fs={ex.submit(worker,n):n for n in todo}
  for f in as_completed(fs):
   x=f.result();p=RES/f"{x['id']}.json";tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(x,sort_keys=True,separators=(',',':'))+'\n');os.replace(tmp,p);ok+=1
   if ok%100==0:print('P',ok,round(time.time()-t,1),flush=True)
 print('END',ok,round(time.time()-t,2),flush=True)
if __name__=='__main__':main()
