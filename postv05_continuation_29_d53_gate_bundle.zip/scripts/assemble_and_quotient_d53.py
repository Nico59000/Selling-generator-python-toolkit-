import json,glob,hashlib,sys,time,collections
from pathlib import Path
BASE=Path('/mnt/data/cont29')
rows=sorted([json.load(open(f)) for f in glob.glob(str(BASE/'d53_results/*.json'))],key=lambda x:x['id'])
assert len(rows)==487 and [r['id'] for r in rows]==list(range(16875,17362))
counts={'classes':487,'ordinary_exits':sum(len(r['ordinary_walls']) for r in rows),'multiwall_cells':sum(bool(r['multiwall_components']) for r in rows)}
obj={'version':'post-v0.5-continuation-29','gate':'d53 16875..17361','status':'PASS-487/487-EXACT','counts':counts,'classifications':rows,'validation':{'engine':'selling-toolkit-0.5.0 ExactBoundaryClassifier original','direct_full_layer':'487/487 PASS'}}
raw=json.dumps(obj,sort_keys=True,separators=(',',':')).encode();obj['sha256_without_self']=hashlib.sha256(raw).hexdigest();(BASE/'POSTV05_DEPTH53_16875_17361_CLASSIFICATION.json').write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
# ledger unchanged because no multiwalls
prev=json.load(open('/mnt/data/cont28/POSTV05_MULTIWALL_RECURRENCE_AUDIT_AFTER_D43.json'))
aud=dict(prev);aud.update({'version':'post-v0.5-continuation-29','status':'PASS-EXACT-APPEND-ONLY-MULTIWALL-CENSUS-AFTER-D53','new_d53':{'cell_count':0,'event_count':0,'ids':[],'new_primitive_factors':[]},'scope_guard':'append-only exact census through d53; no future extrapolation'})
raw=json.dumps(aud,sort_keys=True,separators=(',',':')).encode();aud['sha256_without_self']=hashlib.sha256(raw).hexdigest();(BASE/'POSTV05_MULTIWALL_RECURRENCE_AUDIT_AFTER_D53.json').write_text(json.dumps(aud,indent=2,sort_keys=True)+'\n')
print('classification',counts,'ledger',aud['event_count'],aud['factor_family_count'])
# quotient
sys.path.insert(0,'/mnt/data/cont28/toolkit_src')
from selling_toolkit.fast_layers import quotient_layer_fast,FastHitRange
seed=json.load(open('/mnt/data/cont26/final_stage/inputs/synthetic_invariant_Qa.seed.json'))
reps=json.load(open('/mnt/data/cont28/POSTV05_REPRESENTATIVE_INDEX_AFTER_D43.json'))['representatives']
nodes=[reps[i] for i in range(16875,17362)]
ranges=[FastHitRange('older_0_8221',0,8221),FastHitRange('d49',8222,8453),FastHitRange('d40',8454,9822),FastHitRange('d50',9823,10103),FastHitRange('d41',10104,11754),FastHitRange('d51',11755,12089),FastHitRange('d42',12090,14087),FastHitRange('d52',14088,14477),FastHitRange('d43',14478,16874),FastHitRange('d53',16875,17361),FastHitRange('d44-index-only',17362,20236)]
t=time.time();q=quotient_layer_fast(seed=seed,global_representatives=reps,nodes=nodes,classifications=rows,target_depth=54,kind='DEPTH54',layer_label='d54-post-v05-cont29',hit_ranges=ranges);elapsed=time.time()-t
qo={'version':'post-v0.5-continuation-29','phase':'d53-quotient','status':'PASS-487/487-EXACT-QUOTIENTED','engine':'selling-toolkit-0.5.0 FastCanonicalIndex int64 guarded','processing_order':'id','known_index_before':'0..20236','counts':q['counts'],'hit_buckets':q['hit_buckets'],'events':q['events'],'multiwalls':q['multiwalls'],'new_depth54_nodes':q['new_nodes'],'elapsed_seconds':elapsed,'guards':['complete current global index 0..20236 used','d44 17362..20236 treated as known index-only/HIT-only and not classified','new d54 representatives inserted immediately for deterministic same-pass collapse','d44 classification not opened','d54 classification not opened']}
raw=json.dumps(qo,sort_keys=True,separators=(',',':')).encode();qo['sha256_without_self']=hashlib.sha256(raw).hexdigest();(BASE/'POSTV05_DEPTH53_16875_17361_QUOTIENT_TOOLKIT.json').write_text(json.dumps(qo,indent=2,sort_keys=True)+'\n')
idxo={'version':'post-v0.5-continuation-29','status':'INDEX-AFTER-D53-QUOTIENT','representatives':q['representatives_after']}
raw=json.dumps(idxo,sort_keys=True,separators=(',',':')).encode();idxo['sha256_without_self']=hashlib.sha256(raw).hexdigest();(BASE/'POSTV05_REPRESENTATIVE_INDEX_AFTER_D53.json').write_text(json.dumps(idxo,indent=2,sort_keys=True)+'\n')
print('quotient',q['counts'],'buckets',q['hit_buckets'],'new range',q['new_nodes'][0]['id'] if q['new_nodes'] else None,q['new_nodes'][-1]['id'] if q['new_nodes'] else None,'index last',len(q['representatives_after'])-1,'sec',round(elapsed,3))
