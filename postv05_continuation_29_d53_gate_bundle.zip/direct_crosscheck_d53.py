import json,sys,time,hashlib
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import sympy as sp
from sympy.core.cache import clear_cache
R=Path('/mnt/data/cont29/postseal_fresh_extract'); sys.path.insert(0,str(R/'toolkit_src_extracted'))
from selling_seed2d.chart import build_chart
from selling_seed2d.classifier import ExactBoundaryClassifier
idx=json.load(open(R/'POSTV05_REPRESENTATIVE_INDEX_AFTER_D43.json'))['representatives']; seed=json.load(open(R/'inputs/synthetic_invariant_Qa.seed.json')); _G=None
ids=sorted(set(round(16875+i*(17361-16875)/39) for i in range(40)))
def imat(rows):return sp.Matrix([[sp.Integer(v) for v in row] for row in rows])
def init_worker(seed):
 global _G
 c=build_chart(seed);_G=ExactBoundaryClassifier(c.q,c.r,c.wall_vector,c.D0)
def worker(i):
 try:
  c=_G.classify_cell(imat(idx[i]['L']));return {'id':i,'ordinary_walls':list(c['ordinary_walls']),'multiwall_components':[{'factor':z['factor'],'walls':list(z['walls'])} for z in c.get('multiwall_components',[])],'polynomials':c.get('polynomials',{})}
 finally:clear_cache()
t=time.time();bad=[]
with ProcessPoolExecutor(max_workers=5,initializer=init_worker,initargs=(seed,)) as ex:
 for f in as_completed([ex.submit(worker,i) for i in ids]):
  x=f.result();exp=json.load(open(R/'chunks'/f"{x['id']}.json"))
  if x!=exp:bad.append(x['id'])
report={'version':'post-v0.5-continuation-29','status':'PASS' if not bad else 'FAIL','checked':len(ids),'ids':ids,'failures':bad,'multiwall_in_layer':0,'elapsed_seconds':time.time()-t,'method':'fresh frozen selling-toolkit 0.5.0 ExactBoundaryClassifier direct distributed crosscheck'}
raw=json.dumps(report,sort_keys=True,separators=(',',':')).encode();report['sha256_without_self']=hashlib.sha256(raw).hexdigest();(R/'DIRECT_TOOLKIT_D53_CROSSCHECK.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print(json.dumps(report,indent=2))
