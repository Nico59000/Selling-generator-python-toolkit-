import json,sys,time,hashlib
from pathlib import Path
BASE=Path('/mnt/data/cont27'); sys.path.insert(0,str(BASE/'toolkit_src'))
from selling_toolkit.fast_layers import quotient_layer_fast, FastHitRange
idx=json.load(open('/mnt/data/cont26/work/d42_gate/POSTV05_REPRESENTATIVE_INDEX_AFTER_D42.json'))
reps=idx['representatives']; nodes=[reps[i] for i in range(14088,14478)]
cls=json.load(open(BASE/'POSTV05_DEPTH52_14088_14477_CLASSIFICATION.json'))['classifications']
seed=json.load(open('/mnt/data/cont26/work/c24/inputs/synthetic_invariant_Qa.seed.json'))
ranges=[
 FastHitRange('older_0_8221',0,8221), FastHitRange('d49',8222,8453), FastHitRange('d40',8454,9822),
 FastHitRange('d50',9823,10103), FastHitRange('d41',10104,11754), FastHitRange('d51',11755,12089),
 FastHitRange('d42',12090,14087), FastHitRange('d52',14088,14477), FastHitRange('d43-index-only',14478,16874),
]
t=time.time(); q=quotient_layer_fast(seed=seed,global_representatives=reps,nodes=nodes,classifications=cls,target_depth=53,kind='DEPTH53',layer_label='d53-post-v05-cont27',hit_ranges=ranges); elapsed=time.time()-t
obj={'version':'post-v0.5-continuation-27','phase':'d52-quotient','status':'PASS-390/390-EXACT-QUOTIENTED','engine':'selling-toolkit-0.5.0 FastCanonicalIndex int64 guarded','processing_order':'id','known_index_before':'0..16874','counts':q['counts'],'hit_buckets':q['hit_buckets'],'events':q['events'],'multiwalls':q['multiwalls'],'new_depth53_nodes':q['new_nodes'],'elapsed_seconds':elapsed,'guards':['complete post-d42 global index 0..16874 used','d43 14478..16874 treated as known index-only/HIT-only and not classified','new d53 representatives inserted immediately for deterministic same-pass collapse','multiwall components retained/not expanded','d53 classification not opened','public toolkit 0.5.0 API/CLI/schema unchanged']}
raw=json.dumps(obj,sort_keys=True,separators=(',',':')).encode();obj['sha256_without_self']=hashlib.sha256(raw).hexdigest();(BASE/'POSTV05_DEPTH52_14088_14477_QUOTIENT_TOOLKIT.json').write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
idxout={'version':'post-v0.5-continuation-27','status':'INDEX-AFTER-D52','representatives':q['representatives_after']};raw=json.dumps(idxout,sort_keys=True,separators=(',',':')).encode();idxout['sha256_without_self']=hashlib.sha256(raw).hexdigest();(BASE/'POSTV05_REPRESENTATIVE_INDEX_AFTER_D52.json').write_text(json.dumps(idxout,indent=2,sort_keys=True)+'\n')
print(json.dumps({'counts':q['counts'],'hit_buckets':q['hit_buckets'],'new_range':[q['new_nodes'][0]['id'],q['new_nodes'][-1]['id']] if q['new_nodes'] else None,'index_last':len(q['representatives_after'])-1,'elapsed':elapsed},indent=2))
