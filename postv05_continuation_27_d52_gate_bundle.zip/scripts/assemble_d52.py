import json,hashlib
from pathlib import Path
from collections import Counter,defaultdict
B=Path('/mnt/data/cont27'); R=B/'class_results'
rows=[json.load(open(R/f'{i}.json')) for i in range(14088,14478)]
assert len(rows)==390 and [x['id'] for x in rows]==list(range(14088,14478))
ordinary=sum(len(x['ordinary_walls']) for x in rows); multis=[x for x in rows if x.get('multiwall_components')]
obj={'version':'post-v0.5-continuation-27','status':'PASS-EXACT','gate':'d52 14088..14477','classifications':rows,'counts':{'classes':390,'ordinary_exits':ordinary,'multiwall_cells':len(multis),'multiwall_ids':[x['id'] for x in multis]}}
raw=json.dumps(obj,sort_keys=True,separators=(',',':')).encode(); obj['sha256_without_self']=hashlib.sha256(raw).hexdigest(); (B/'POSTV05_DEPTH52_14088_14477_CLASSIFICATION.json').write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
old=json.load(open('/mnt/data/cont26/final_stage/POSTV05_MULTIWALL_RECURRENCE_AUDIT_AFTER_D42.json')); events=list(old['events'])
for x in multis:
 for c in x['multiwall_components']:
  events.append({'depth':52,'factor':c['factor'],'id':x['id'],'layer':'d52-post-v0.5-cont27','source':'post-v0.5 continuation 27 exact classification','walls':c['walls']})
fams=defaultdict(list)
for e in events:fams[e['factor']].append(e)
pair=Counter('/'.join(sorted(e['walls'])) for e in events); opp={'g/l','h/m','k/n'}
family_rows=[]
for f,es in fams.items():
 family_rows.append({'factor':f,'event_count':len(es),'depths':sorted(set(e['depth'] for e in es)),'ids':[e['id'] for e in es],'wall_pair_counts':dict(sorted(Counter('/'.join(sorted(e['walls'])) for e in es).items()))})
family_rows.sort(key=lambda z:(min(z['depths']),z['factor']))
aud={'version':'post-v0.5-continuation-27','status':'PASS-EXACT-APPEND-ONLY-MULTIWALL-CENSUS-AFTER-D52','event_count':len(events),'events':events,'factor_family_count':len(family_rows),'families':family_rows,'pair_incidence':{'counts':dict(sorted((k.replace('/',''),v) for k,v in pair.items())),'adjacent_pairs_observed':len([k for k in pair if k not in opp]),'opposite_pairs_observed':len([k for k in pair if k in opp]),'opposite_pairs':sorted(k for k in pair if k in opp)},'new_d52':{'event_count':sum(len(x['multiwall_components']) for x in multis),'cell_count':len(multis),'ids':[x['id'] for x in multis]},'scope_guard':'append-only exact census through d52; no future extrapolation'}
raw=json.dumps(aud,sort_keys=True,separators=(',',':')).encode(); aud['sha256_without_self']=hashlib.sha256(raw).hexdigest(); (B/'POSTV05_MULTIWALL_RECURRENCE_AUDIT_AFTER_D52.json').write_text(json.dumps(aud,indent=2,sort_keys=True)+'\n')
oldf={z['factor'] for z in old['families']}
print(json.dumps({'classes':390,'ordinary':ordinary,'multi_cells':len(multis),'multi_ids':[x['id'] for x in multis],'events':len(events),'families':len(family_rows),'pairs':aud['pair_incidence'],'new_family_factors':[f['factor'] for f in family_rows if f['factor'] not in oldf]},indent=2))
