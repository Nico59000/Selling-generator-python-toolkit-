#!/usr/bin/env python3
import json,sys,zipfile,tempfile,shutil,hashlib,time,os
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import sympy as sp
from sympy.core.cache import clear_cache

def load(p): return json.load(open(p,encoding='utf-8'))
_G=None
def init_worker(toolkit_dir,seed):
 global _G
 sys.path.insert(0,str(toolkit_dir))
 from selling_seed2d.chart import build_chart
 from selling_seed2d.classifier import ExactBoundaryClassifier
 c=build_chart(seed); _G=ExactBoundaryClassifier(c.q,c.r,c.wall_vector,c.D0)
def worker(node):
 try:
  L=sp.Matrix([[sp.Integer(v) for v in row] for row in node['L']]); c=_G.classify_cell(L)
  return {'id':int(node['id']),'ordinary_walls':list(c['ordinary_walls']),'multiwall_components':[{'factor':z['factor'],'walls':list(z['walls'])} for z in c.get('multiwall_components',[])],'polynomials':c.get('polynomials',{})}
 finally: clear_cache()
def main(root):
 root=Path(root).resolve(); t=time.time(); failures=[]
 td=Path(tempfile.mkdtemp(prefix='tk_',dir=str(root)))
 with zipfile.ZipFile(root/'inputs/selling_toolkit_v05_0_source.zip') as z:z.extractall(td)
 cand=[p for p in [td,*td.iterdir()] if p.is_dir() and (p/'selling_seed2d').exists() and (p/'selling_toolkit').exists()]; assert cand; tk=cand[0]
 idx=load(root/'POSTV05_REPRESENTATIVE_INDEX_AFTER_D42.json')['representatives']; nodes=idx[14088:14478]
 exp={x['id']:x for x in load(root/'POSTV05_DEPTH52_14088_14477_CLASSIFICATION.json')['classifications']}; got={}
 with ProcessPoolExecutor(max_workers=5,initializer=init_worker,initargs=(tk,load(root/'inputs/synthetic_invariant_Qa.seed.json'))) as ex:
  fs=[ex.submit(worker,n) for n in nodes]
  for f in as_completed(fs):
   x=f.result(); got[x['id']]=x
 for i in range(14088,14478):
  if got.get(i)!=exp.get(i): failures.append(i)
 # quotient replay with fresh source tree
 sys.path.insert(0,str(tk))
 from selling_toolkit.fast_layers import quotient_layer_fast,FastHitRange
 ranges=[FastHitRange('older_0_8221',0,8221),FastHitRange('d49',8222,8453),FastHitRange('d40',8454,9822),FastHitRange('d50',9823,10103),FastHitRange('d41',10104,11754),FastHitRange('d51',11755,12089),FastHitRange('d42',12090,14087),FastHitRange('d52',14088,14477),FastHitRange('d43-index-only',14478,16874)]
 q=quotient_layer_fast(seed=load(root/'inputs/synthetic_invariant_Qa.seed.json'),global_representatives=idx,nodes=nodes,classifications=[got[i] for i in range(14088,14478)],target_depth=53,kind='DEPTH53',layer_label='d53-post-v05-cont27',hit_ranges=ranges)
 obs=load(root/'POSTV05_DEPTH52_14088_14477_QUOTIENT_TOOLKIT.json')
 events_exact=q['events']==obs['events']; new_exact=q['new_nodes']==obs['new_depth53_nodes']
 report={'version':'post-v0.5-continuation-27','status':'PASS' if not failures and events_exact and new_exact else 'FAIL','fresh_reclassification':390,'classification_failures':failures,'ordinary_exits':q['counts']['ordinary_exits'],'multiwall_cells':q['counts']['multiwall_cells'],'hits':q['counts']['hits'],'new':q['counts']['new'],'event_sequence_exact':events_exact,'new_nodes_exact':new_exact,'elapsed_seconds':time.time()-t,'toolkit':'selling-toolkit 0.5.0 fresh source extraction'}
 raw=json.dumps(report,sort_keys=True,separators=(',',':')).encode();report['sha256_without_self']=hashlib.sha256(raw).hexdigest();(root/'POSTV05_CONTINUATION_27_POSTSEAL_REPLAY_REPORT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
 shutil.rmtree(td,ignore_errors=True); print(json.dumps(report,indent=2))
if __name__=='__main__': main(sys.argv[1] if len(sys.argv)>1 else '.')
