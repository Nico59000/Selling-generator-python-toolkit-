"""Experimental HTNT forward-span research harness.

NOT part of selling-toolkit 0.5.0 public surface.
Derived from HTNT_structural_forward_methodology_v4.
Only finite explicitly supplied spans are represented here.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Hashable, Iterable, Tuple
import sympy as sp

@dataclass(frozen=True)
class Witness:
    deck_index: int
    relabel_index: int
    sign: int
    def __post_init__(self):
        if self.sign not in (-1, 1):
            raise ValueError("sign must be +/-1")

@dataclass(frozen=True)
class EventClass:
    canonical_ref: Hashable
    sigma: Hashable
    J2: int
    orbit: Tuple[int, int, int]
    source_path: str = ""

@dataclass(frozen=True)
class ForwardEdge:
    source: Hashable
    target: Hashable
    witness: Witness | None = None

@dataclass(frozen=True)
class ReturnEdge:
    source: Hashable
    target: Hashable
    witness: Witness

@dataclass
class ForwardSpan:
    domain: Tuple[Hashable, ...]
    codomain: Tuple[Hashable, ...]
    forward_edges: Tuple[ForwardEdge, ...]
    return_edges: Tuple[ReturnEdge, ...] = ()

    def matrix_N(self) -> sp.Matrix:
        di={x:i for i,x in enumerate(self.domain)}
        ci={x:i for i,x in enumerate(self.codomain)}
        M=sp.zeros(len(self.codomain),len(self.domain))
        for e in self.forward_edges:
            M[ci[e.target],di[e.source]] += 1
        return M

    def defect_signature(self) -> tuple[int,int]:
        M=self.matrix_N(); rank=M.rank()
        return (M.cols-rank, M.rows-rank)

def compose_matrix(G: ForwardSpan, F: ForwardSpan) -> sp.Matrix:
    if F.codomain != G.domain:
        raise ValueError("typed span boundary mismatch")
    return G.matrix_N()*F.matrix_N()

def verify_direct_composition(G: ForwardSpan, F: ForwardSpan, direct: sp.Matrix) -> bool:
    return compose_matrix(G,F) == direct
