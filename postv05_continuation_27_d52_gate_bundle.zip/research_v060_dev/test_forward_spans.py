import sympy as sp
from forward_spans import ForwardSpan,ForwardEdge

def test_signatures_v4_examples():
    Fs=ForwardSpan(('s4','s6'),('s5',),(ForwardEdge('s4','s5'),))
    assert Fs.matrix_N()==sp.Matrix([[1,0]]) and Fs.defect_signature()==(1,0)
    Fx=ForwardSpan(('a','b'),('c','d'),(ForwardEdge('a','c'),ForwardEdge('b','d')))
    assert Fx.matrix_N()==sp.eye(2) and Fx.defect_signature()==(0,0)
    Fsplit=ForwardSpan(('a','b'),('c','d','e','f'),(ForwardEdge('a','c'),ForwardEdge('a','d'),ForwardEdge('b','e'),ForwardEdge('b','f')))
    assert Fsplit.matrix_N()==sp.Matrix([[1,0],[1,0],[0,1],[0,1]]) and Fsplit.defect_signature()==(0,2)
    F65=ForwardSpan(('a','b','c','d'),('x','y'),(ForwardEdge('a','x'),ForwardEdge('d','y')))
    assert F65.matrix_N()==sp.Matrix([[1,0,0,0],[0,0,0,1]]) and F65.defect_signature()==(2,0)

def test_two_stage_composition():
    F=ForwardSpan(('a','b'),('c','d'),(ForwardEdge('a','c'),ForwardEdge('b','d')))
    G=ForwardSpan(('c','d'),('e','f'),(ForwardEdge('c','e'),ForwardEdge('d','f')))
    assert G.matrix_N()*F.matrix_N()==sp.eye(2)
