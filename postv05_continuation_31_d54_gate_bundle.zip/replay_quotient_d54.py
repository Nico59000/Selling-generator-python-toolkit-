import json,sys,time,hashlib
from pathlib import Path
ROOT=Path('/mnt/data/cont31/postseal_fresh_extract');sys.path.insert(0,str(ROOT/'toolkit_src_extracted'))
from selling_toolkit.fast_layers import quotient_layer_fast,FastHitRange
seed=json.load(open(ROOT/'inputs/synthetic_invariant_Qa.seed.json'))
reps=json.load(open(ROOT/'POSTV05_REPRESENTATIVE_INDEX_AFTER_D44.json'))['representatives']
rows=[json.load(open(ROOT/'fresh_replay_results'/f'{i}.json')) for i in range(20237,20815)]
nodes=[reps[i] for i in range(20237,20815)]
ranges=[FastHitRange('older_0_8221',0,8221),FastHitRange('d49',8222,8453),FastHitRange('d40',8454,9822),FastHitRange('d50',9823,10103),FastHitRange('d41',10104,11754),FastHitRange('d51',11755,12089),FastHitRange('d42',12090,14087),FastHitRange('d52',14088,14477),FastHitRange('d43',14478,16874),FastHitRange('d53',16875,17361),FastHitRange('d44',17362,20236),FastHitRange('d54',20237,20814),FastHitRange('d45-index-only',20815,24255)]
t=time.time();q=quotient_layer_fast(seed=seed,global_representatives=reps,nodes=nodes,classifications=rows,target_depth=55,kind='DEPTH55',layer_label='d55-post-v05-cont31',hit_ranges=ranges);elapsed=time.time()-t
orig=json.load(open(ROOT/'POSTV05_DEPTH54_20237_20814_QUOTIENT_TOOLKIT.json'))
computed=[(int(e['source']),e['wall'],e['status'],int(e['target']),e['J2']) for e in q['events']]
observed=[(int(e['source']),e['wall'],e['status'],int(e['target']),e['J2']) for e in orig['events']]
new_exact=q['new_nodes']==orig['new_depth55_nodes']
rep={'version':'post-v0.5-continuation-31','status':'PASS' if computed==observed and new_exact and q['counts']==orig['counts'] and q['hit_buckets']==orig['hit_buckets'] else 'FAIL','counts':q['counts'],'hit_buckets':q['hit_buckets'],'event_sequence_exact':computed==observed,'new_nodes_exact':new_exact,'elapsed_seconds':elapsed}
raw=json.dumps(rep,sort_keys=True,separators=(',',':')).encode();rep['sha256_without_self']=hashlib.sha256(raw).hexdigest();(ROOT/'D54_QUOTIENT_FRESH_REPLAY_REPORT.json').write_text(json.dumps(rep,indent=2,sort_keys=True)+'\n');print(json.dumps(rep,indent=2))
