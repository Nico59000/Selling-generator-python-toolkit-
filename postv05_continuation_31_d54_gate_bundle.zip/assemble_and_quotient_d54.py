import json,glob,hashlib,sys,time,collections
from pathlib import Path
BASE=Path('/mnt/data/cont31')
rows=sorted([json.load(open(f)) for f in glob.glob(str(BASE/'d54_results/*.json'))],key=lambda x:x['id'])
assert len(rows)==578 and [r['id'] for r in rows]==list(range(20237,20815))
counts={'classes':578,'ordinary_exits':sum(len(r['ordinary_walls']) for r in rows),'multiwall_cells':sum(bool(r['multiwall_components']) for r in rows)}
obj={'version':'post-v0.5-continuation-31','gate':'d54 20237..20814','status':'PASS-578/578-EXACT','counts':counts,'classifications':rows,'validation':{'engine':'selling-toolkit-0.5.0 ExactBoundaryClassifier original','direct_full_layer':'578/578 PASS'}}
raw=json.dumps(obj,sort_keys=True,separators=(',',':')).encode();obj['sha256_without_self']=hashlib.sha256(raw).hexdigest();(BASE/'POSTV05_DEPTH54_20237_20814_CLASSIFICATION.json').write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
# append-only multiwall ledger
prev=json.load(open('/mnt/data/cont30/POSTV05_MULTIWALL_RECURRENCE_AUDIT_AFTER_D44.json'))
idx=json.load(open('/mnt/data/cont30/POSTV05_REPRESENTATIVE_INDEX_AFTER_D44.json'))['representatives']
events=list(prev['events'])
for r in rows:
 for z in r['multiwall_components']:
  events.append({'depth':54,'factor':z['factor'],'id':r['id'],'layer':'d54','source':idx[r['id']]['source'],'walls':z['walls']})
fams={}
for e in events:
 f=e['factor'];fams.setdefault(f,{'factor':f,'ids':[],'depths':set(),'wall_pair_counts':collections.Counter()});fams[f]['ids'].append(e['id']);fams[f]['depths'].add(e['depth']);fams[f]['wall_pair_counts']['/'.join(e['walls'])]+=1
fl=[]
for f,d in sorted(fams.items()):fl.append({'factor':f,'event_count':len(d['ids']),'ids':d['ids'],'depths':sorted(d['depths']),'wall_pair_counts':dict(sorted(d['wall_pair_counts'].items()))})
pc=collections.Counter(''.join(e['walls']) for e in events);oldf=set(x['factor'] for x in prev['families']);newf=sorted(set(z['factor'] for r in rows for z in r['multiwall_components'])-oldf)
aud={'version':'post-v0.5-continuation-31','status':'PASS-EXACT-APPEND-ONLY-MULTIWALL-CENSUS-AFTER-D54','event_count':len(events),'factor_family_count':len(fl),'events':events,'families':fl,'new_d54':{'cell_count':counts['multiwall_cells'],'event_count':sum(len(r['multiwall_components']) for r in rows),'ids':[r['id'] for r in rows if r['multiwall_components']],'new_primitive_factors':newf},'pair_incidence':{'adjacent_pairs_observed':len(pc),'counts':dict(sorted(pc.items())),'opposite_pairs_observed':0,'opposite_pairs':[]},'scope_guard':'append-only exact census through d54; no future extrapolation'}
raw=json.dumps(aud,sort_keys=True,separators=(',',':')).encode();aud['sha256_without_self']=hashlib.sha256(raw).hexdigest();(BASE/'POSTV05_MULTIWALL_RECURRENCE_AUDIT_AFTER_D54.json').write_text(json.dumps(aud,indent=2,sort_keys=True)+'\n')
print('classification',counts,'ledger',len(events),len(fl),'newf',newf,flush=True)
# quotient only after full assertions above
sys.path.insert(0,str(BASE/'toolkit_src'))
from selling_toolkit.fast_layers import quotient_layer_fast,FastHitRange
seed=json.load(open('/mnt/data/cont30/final_stage/inputs/synthetic_invariant_Qa.seed.json'))
reps=idx; nodes=[reps[i] for i in range(20237,20815)]
ranges=[FastHitRange('older_0_8221',0,8221),FastHitRange('d49',8222,8453),FastHitRange('d40',8454,9822),FastHitRange('d50',9823,10103),FastHitRange('d41',10104,11754),FastHitRange('d51',11755,12089),FastHitRange('d42',12090,14087),FastHitRange('d52',14088,14477),FastHitRange('d43',14478,16874),FastHitRange('d53',16875,17361),FastHitRange('d44',17362,20236),FastHitRange('d54',20237,20814),FastHitRange('d45-index-only',20815,24255)]
t=time.time();q=quotient_layer_fast(seed=seed,global_representatives=reps,nodes=nodes,classifications=rows,target_depth=55,kind='DEPTH55',layer_label='d55-post-v05-cont31',hit_ranges=ranges);elapsed=time.time()-t
qo={'version':'post-v0.5-continuation-31','phase':'d54-quotient','status':'PASS-578/578-EXACT-QUOTIENTED','engine':'selling-toolkit-0.5.0 FastCanonicalIndex int64 guarded','processing_order':'id','known_index_before':'0..24255','counts':q['counts'],'hit_buckets':q['hit_buckets'],'events':q['events'],'multiwalls':q['multiwalls'],'new_depth55_nodes':q['new_nodes'],'elapsed_seconds':elapsed,'guards':['complete current global index 0..24255 used','d45 20815..24255 treated as known index-only/HIT-only and not classified','new d55 representatives inserted immediately for deterministic same-pass collapse','d45 classification not opened','next principal layer not opened']}
raw=json.dumps(qo,sort_keys=True,separators=(',',':')).encode();qo['sha256_without_self']=hashlib.sha256(raw).hexdigest();(BASE/'POSTV05_DEPTH54_20237_20814_QUOTIENT_TOOLKIT.json').write_text(json.dumps(qo,indent=2,sort_keys=True)+'\n')
idxo={'version':'post-v0.5-continuation-31','status':'INDEX-AFTER-D54','representatives':q['representatives_after']};raw=json.dumps(idxo,sort_keys=True,separators=(',',':')).encode();idxo['sha256_without_self']=hashlib.sha256(raw).hexdigest();(BASE/'POSTV05_REPRESENTATIVE_INDEX_AFTER_D54.json').write_text(json.dumps(idxo,indent=2,sort_keys=True)+'\n')
print('quotient',q['counts'],'hit_buckets',q['hit_buckets'],'new_range',([q['new_nodes'][0]['id'],q['new_nodes'][-1]['id']] if q['new_nodes'] else None),'index_last',len(q['representatives_after'])-1,'elapsed',round(elapsed,3),flush=True)
