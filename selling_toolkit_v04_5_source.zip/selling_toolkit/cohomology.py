from __future__ import annotations
from dataclasses import dataclass
import sympy as sp
from selling_seed2d.algebra import S,FIRST_MOVE
from .extension import DeterminantSwapSellingLift3D5D

@dataclass(frozen=True)
class DeterminantSwapH1NoGo:
    """Finite exact relation certificate forcing H^1=0 for the det-swap module.

    Coefficients are V=Mat_{2x3}(Q) with cocycle law
        C(AB)=C(A)B + D(A)C(B),
    where D(A) is the determinant-swap two-fibre representation.

    We do *not* claim the listed relations form a complete presentation of the
    Selling matrix group.  They are exact identities in that group and already
    cut the generator-level cocycle solution space down to the six-dimensional
    coboundary space.  Hence every actual group cocycle is a coboundary.
    """
    status: str = "PROVEN-H1-ZERO-FOR-LINEAR-LOWER-TRIANGULAR-DET-SWAP-MODULE"

    EXTRA_RELATIONS = (
        tuple("klhklh"),
        tuple("knkhmh"),
        tuple("mnlnml"),
        tuple("hgkngnkg"),
    )

    @staticmethod
    def generators():
        return {w:sp.Matrix(S[i-1]) for w,i in FIRST_MOVE.items()}

    @classmethod
    def order3_relations(cls):
        G=cls.generators(); ws=list(G)
        out=[]
        for i,a in enumerate(ws):
            for b in ws[i+1:]:
                if (G[a]*G[b])**3==sp.eye(3): out.append(tuple([a,b]*3))
        return tuple(out)

    @classmethod
    def relation_words(cls):
        invol=tuple((w,w) for w in cls.generators())
        return invol + cls.order3_relations() + cls.EXTRA_RELATIONS

    @classmethod
    def relation_matrix_identity(cls,word):
        A=sp.eye(3)
        for w in word: A=A*cls.generators()[w]
        return A==sp.eye(3)

    @classmethod
    def _symbolic_cocycle_data(cls):
        G=cls.generators(); ws=list(G)
        vars=[]; C={}
        for w in ws:
            xs=sp.symbols(f'c_{w}_0:6'); vars.extend(xs); C[w]=sp.Matrix(2,3,xs)
        def word_c(word):
            A=sp.eye(3); c=sp.zeros(2,3); d=sp.eye(2)
            for w in word:
                B=G[w]; db=DeterminantSwapSellingLift3D5D.fibre_action(B)
                c=c*B+d*C[w]; A=A*B; d=d*db
            return A,sp.expand(c),d
        return G,ws,vars,C,word_c

    @classmethod
    def constraint_matrix(cls):
        _G,_ws,vars,_C,word_c=cls._symbolic_cocycle_data()
        eqs=[]
        for word in cls.relation_words():
            A,c,d=word_c(word)
            if A!=sp.eye(3) or d!=sp.eye(2):
                raise AssertionError(f'not an exact source/fibre relation: {word}')
            eqs.extend(list(c))
        M,_=sp.linear_eq_to_matrix(eqs,vars)
        return M

    @classmethod
    def coboundary_matrix(cls):
        G=cls.generators(); ws=list(G)
        ks=sp.symbols('k0:6'); K=sp.Matrix(2,3,ks)
        vec=[]
        for w in ws:
            D=DeterminantSwapSellingLift3D5D.fibre_action(G[w])
            vec.extend(list(K*G[w]-D*K))
        B,_=sp.linear_eq_to_matrix(vec,ks)
        return B

    @classmethod
    def certificate(cls):
        rels=cls.relation_words(); M=cls.constraint_matrix(); B=cls.coboundary_matrix()
        rel_ok=[cls.relation_matrix_identity(w) for w in rels]
        zdim=36-M.rank(); bdim=B.rank()
        if M*B != sp.zeros(M.rows,B.cols):
            raise AssertionError('coboundaries violate exact relation constraints')
        if zdim!=bdim:
            raise AssertionError('relation solution space not equal in dimension to coboundaries')
        return {
            'status':cls.status,
            'generator_order':list(cls.generators()),
            'generator_count':6,
            'coefficient_dimension':6,
            'generator_cocycle_unknown_dimension':36,
            'relation_count':len(rels),
            'relations':[''.join(w) for w in rels],
            'all_relation_matrix_identities_exact':all(rel_ok),
            'constraint_rank':int(M.rank()),
            'relation_solution_dimension':int(zdim),
            'coboundary_rank':int(bdim),
            'H1_dimension':int(zdim-bdim),
            'logic':'Actual group 1-cocycles satisfy every listed exact relation, so Z^1(actual) is contained in the relation-solution space. Coboundaries lie in actual Z^1 and have the same dimension as the relation-solution space; therefore Z^1(actual)=B^1 and H^1=0.',
            'presentation_guard':'The listed relations are not claimed to be a complete presentation; completeness is unnecessary for this upper-bound/no-go argument.',
            'scope_guard':'Only linear lower-triangular 5D lifts with the determinant-swap fibre representation are covered. Nonlinear lifts, other fibre representations, and native 5D walls/conorms remain open.'
        }


@dataclass(frozen=True)
class GoldenResidualAffineH1NoGo:
    """Exact H^1=0 no-go for affine shifts of the signed golden residual.

    The residual coordinate r=Delta(X,Y) carries the scalar sign module
        chi(A)=sign(det A).
    An affine action has the form r |-> chi(A) r + b(A), with
        b(AB)=b(A)+chi(A)b(B).
    The same finite set of exact Selling matrix relations used by
    DeterminantSwapH1NoGo cuts the six generator values b_w down to the
    one-dimensional coboundary space b_m(A)=(1-chi(A))m.  Hence every actual
    scalar sign-module cocycle is a coboundary.  Through Gamma_phi this also
    rules out a nontrivial affine-translation class on the positive golden
    residual fibre; it does not rule out other fibre representations or
    genuinely nonlinear/native 5D wall systems.
    """
    status: str = "PROVEN-H1-ZERO-FOR-GOLDEN-RESIDUAL-AFFINE-SIGN-MODULE"

    @staticmethod
    def generators():
        return DeterminantSwapH1NoGo.generators()

    @staticmethod
    def chi(A: sp.Matrix) -> sp.Integer:
        A=sp.Matrix(A)
        if A.det()==0: raise ValueError('source matrix must be invertible')
        return sp.Integer(1 if A.det()>0 else -1)

    @classmethod
    def relation_words(cls):
        return DeterminantSwapH1NoGo.relation_words()

    @classmethod
    def constraint_matrix(cls):
        G=cls.generators(); ws=list(G); vals=sp.symbols('b0:6'); B=dict(zip(ws,vals))
        eqs=[]
        for word in cls.relation_words():
            A=sp.eye(3); b=sp.Integer(0)
            for w in word:
                b=sp.expand(b + cls.chi(A)*B[w])
                A=A*G[w]
            if A!=sp.eye(3): raise AssertionError(f'not an exact source relation: {word}')
            eqs.append(b)
        M,_=sp.linear_eq_to_matrix(eqs,vals)
        return M

    @classmethod
    def coboundary_matrix(cls):
        # b_m(A)=m-chi(A)m=(1-chi(A))m on generator values.
        G=cls.generators(); ws=list(G)
        return sp.Matrix([[1-cls.chi(G[w])] for w in ws])

    @classmethod
    def certificate(cls):
        M=cls.constraint_matrix(); B=cls.coboundary_matrix(); rels=cls.relation_words()
        zdim=6-M.rank(); bdim=B.rank()
        if M*B != sp.zeros(M.rows,B.cols):
            raise AssertionError('scalar coboundaries violate exact relation constraints')
        if zdim!=bdim:
            raise AssertionError('relation solution dimension does not equal scalar coboundary dimension')
        return {
            'status':cls.status,
            'generator_order':list(cls.generators()),
            'generator_count':6,
            'coefficient_dimension':1,
            'generator_cocycle_unknown_dimension':6,
            'relation_count':len(rels),
            'relations':[''.join(w) for w in rels],
            'constraint_rank':int(M.rank()),
            'relation_solution_dimension':int(zdim),
            'coboundary_rank':int(bdim),
            'H1_dimension':int(zdim-bdim),
            'relation_nullspace':[[str(x) for x in v] for v in M.nullspace()],
            'coboundary_generator':[str(x) for x in B],
            'affine_action':'r -> chi(A)*r + b(A), chi(A)=sign(det A)',
            'gauge_identity':'b_m(A)=(1-chi(A))*m; translation H_m(r)=r+m conjugates pure sign action to the affine coboundary action',
            'golden_interpretation':'via Delta(Gamma_phi(r))=r, any such affine residual cocycle is gauge-trivial before re-encoding in the positive golden fibre',
            'presentation_guard':'The exact relation list is only a sufficient constraint set, not claimed as a complete presentation.',
            'scope_guard':'This no-go covers affine translations of the one-dimensional signed residual. Other fibre representations, nonlinear maps not affine in residual coordinates, and native 5D walls/conorms remain open.'
        }
