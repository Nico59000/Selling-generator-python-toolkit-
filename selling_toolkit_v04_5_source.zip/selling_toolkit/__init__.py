"""Selling Toolkit v0.4.

Append-only research API around the exact Selling reduction engine.
"""
from .layers import CanonicalIndex, quotient_layer, tarjan_scc, classify_exact
from .fast_layers import FastCanonicalIndex, FastHitRange, quotient_layer_fast
from .rational_forms import quadratic_form_invariants, compare_rational_congruence, explicit_isotropic_ternary_congruence, fixed_scale_quartic_covariance_orbit, find_isotropic_vector_exact, explicit_isotropic_ternary_congruence_exact, fixed_scale_quartic_covariance_orbit_exact
from .quartic import PascalReducedQuartic, rho_covariant, reconstruct_pascal_reduced, reconstruct_lorentz_rho, reduce_to_pascal_coordinates, transform_quartic_gl3, transform_rho_gl3, reconstruct_gl3_lorentz_rho
from .extension import ProductLift3D5D, TrivialSellingLift3D5D, ProjectionPreservingLinearLift3D5D, DeterminantSwapSellingLift3D5D, GoldenResidualFibreAdapter, CoboundaryCoupledSellingLift3D5D
from .cohomology import DeterminantSwapH1NoGo, GoldenResidualAffineH1NoGo

__version__ = "0.4.5"
__all__ = [
    "CanonicalIndex", "quotient_layer", "tarjan_scc", "classify_exact", "FastCanonicalIndex", "FastHitRange", "quotient_layer_fast",
    "PascalReducedQuartic", "rho_covariant", "reconstruct_pascal_reduced", "reconstruct_lorentz_rho", "reduce_to_pascal_coordinates", "transform_quartic_gl3", "transform_rho_gl3", "reconstruct_gl3_lorentz_rho",
    "ProductLift3D5D", "TrivialSellingLift3D5D", "ProjectionPreservingLinearLift3D5D", "DeterminantSwapSellingLift3D5D", "GoldenResidualFibreAdapter", "CoboundaryCoupledSellingLift3D5D",
    "DeterminantSwapH1NoGo", "GoldenResidualAffineH1NoGo",
    "quadratic_form_invariants", "compare_rational_congruence", "explicit_isotropic_ternary_congruence", "fixed_scale_quartic_covariance_orbit", "find_isotropic_vector_exact", "explicit_isotropic_ternary_congruence_exact", "fixed_scale_quartic_covariance_orbit_exact",
]
