#!/usr/bin/env python3
import sys,json,zipfile,tempfile,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as td:
    zipfile.ZipFile(R/'inputs/selling_toolkit_v05_0_source.zip').extractall(td)
    sys.path.insert(0,td)
    from selling_seed2d.algebra import S,FIRST_MOVE,WALL_ACTION,RELABEL,build_finite_group
    from selling_seed2d.seed import seed_matrices
    seed=json.load(open(R/'inputs/synthetic_invariant_Qa.seed.json'))
    reps=json.load(open(R/'inputs/V04_REPRESENTATIVE_INDEX_AFTER_D36.json'))['representatives']
    idx45=json.load(open(R/'inputs/V04_REPRESENTATIVE_INDEX_AFTER_D45.json'))['representatives']
    nodes=idx45[4858:4988]
    clf=json.load(open(R/'POSTV05_DEPTH46_4858_4987_CLASSIFICATION.json'))
    quot=json.load(open(R/'POSTV05_DEPTH46_4858_4987_QUOTIENT_TOOLKIT.json'))
    _Q,_A,Qc,deck_named=seed_matrices(seed); deck=build_finite_group([g for _,g in deck_named],32)
    def smat(M):return tuple(tuple(int(x) for x in row) for row in M.tolist())
    def mm(A,B):
        C=list(zip(*B));return tuple(tuple(sum(a*b for a,b in zip(row,col)) for col in C) for row in A)
    def tr(A):return tuple(zip(*A))
    def neg(A):return tuple(tuple(-x for x in row) for row in A)
    def key(A):return tuple(x for row in A for x in row)
    D=[smat(x) for x in deck]; RR=[smat(x) for x in RELABEL]; Sm={w:smat(S[FIRST_MOVE[w]-1]) for w in FIRST_MOVE}; Wm={w:smat(WALL_ACTION[w]) for w in WALL_ACTION}; Q=smat(Qc)
    variants={}; current=[dict(x) for x in reps]
    def add(rid,A):
        for di,d in enumerate(D):
            DA=mm(d,A)
            for ri,r in enumerate(RR):
                X=mm(DA,r); variants.setdefault(key(X),(rid,di,ri,1)); variants.setdefault(key(neg(X)),(rid,di,ri,-1))
    for x in current:add(int(x['id']),tuple(tuple(int(v) for v in row) for row in x['A']))
    cm={r['id']:r for r in clf['results']}; got=[]; new=[]; next_id=len(current)
    for n in nodes:
        A=tuple(tuple(int(v) for v in row) for row in n['A']); L=tuple(tuple(int(v) for v in row) for row in n['L'])
        for wall in cm[n['id']]['ordinary_walls']:
            An=mm(A,Sm[wall]); Ln=mm(Wm[wall],L); M=mm(mm(tr(An),Q),An)
            con=[sum(M[i][j] for j in range(3)) for i in range(3)]+[-M[0][1],-M[0][2],-M[1][2]]; j2=sum(v*v for v in con)
            e={'source':n['id'],'wall':wall,'J2':str(j2)}; hit=variants.get(key(An))
            if hit is not None:
                target,di,ri,sign=hit;e.update(status='HIT',target=target,deck_index=di,relabel_index=ri,sign=sign)
            else:
                target=next_id;next_id+=1;e.update(status='NEW',target=target)
                nn={'id':target,'path_from_C2':n.get('path_from_C2','')+wall,'kind':'DEPTH47','depth':47,'source':n['id'],'arrival_wall':wall,'A':[[str(v) for v in row] for row in An],'L':[[str(v) for v in row] for row in Ln],'M':[[str(v) for v in row] for row in M],'J2':str(j2),'conorm6':[str(v) for v in con],'_layer':'d47-post-v05-cont15'}
                new.append(nn);current.append(nn);add(target,An)
            got.append(e)
    checks={
      'classification_coverage':[r['id'] for r in clf['results']]==list(range(4858,4988)),
      'ordinary_exits':len(got)==482,
      'events_match':got==quot['events'],
      'new_nodes_match':new==quot['new_depth47_nodes'],
      'new_count':len(new)==168,
      'final_index':len(current)==5946,
      'multiwalls':[(r['id'],r['multiwall_components']) for r in clf['results'] if r.get('multiwall_components')]==[(4933,[{'factor':'6*q + 5*r - 7','walls':['h','n']}]),(4939,[{'factor':'6*q + 5*r - 7','walls':['k','m']}])]
    }
    bad=[k for k,v in checks.items() if not v]
    print(json.dumps({'status':'PASS' if not bad else 'FAIL','checks':checks,'failed':bad},sort_keys=True))
    raise SystemExit(1 if bad else 0)
