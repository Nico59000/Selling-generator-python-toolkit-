#!/usr/bin/env python3
from __future__ import annotations
import json,hashlib,sys,tempfile,zipfile,subprocess,os,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parent
N=0
def ck(cond,msg):
 global N;N+=1
 if not cond: raise AssertionError(msg)
def load(name):return json.loads((ROOT/name).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def selfless(d):
 x=dict(d);claimed=x.pop('sha256_without_self',None);raw=json.dumps(x,sort_keys=True,separators=(',',':')).encode();return claimed,hashlib.sha256(raw).hexdigest()
def verify_self(name):
 d=load(name);a,b=selfless(d);ck(a==b,f'selfless {name}');return d
cp=verify_self('V04_SAFE_FRONTIER_CONTINUATION_11_CHECKPOINT.json')
ck(cp['version']=='v0.4-continuation-11','checkpoint version');ck(cp['status'].startswith('RESEARCH-CHECKPOINT'),'checkpoint state')
ck(sha(ROOT/'V04_SAFE_FRONTIER_CONTINUATION_10_CHECKPOINT.json')==cp['predecessor']['sha256'],'predecessor hash')
# d42
c42=verify_self('V04_DEPTH42_2451_2523_CLASSIFICATION.json');rows42=c42['results']
ck(c42['status']=='PASS-73/73-EXACT','d42 class status');ck([r['id'] for r in rows42]==list(range(2451,2524)),'d42 ids')
ck(c42['counts']=={'classes':73,'ordinary_exits':261,'multiwall_cells':0},'d42 class counts');ck(not any(r.get('multiwall_components') for r in rows42),'d42 no multi')
for r in rows42: ck(set(r['ordinary_walls'])<=set('ghklmn'),f'd42 walls {r["id"]}');ck(isinstance(r.get('polynomials'),dict),f'd42 polynomials {r["id"]}')
chunks=[]
for p in sorted((ROOT/'d42_chunks').glob('*.json')):
 d=json.loads(p.read_text());a,b=selfless(d);ck(a==b,f'd42 chunk self {p.name}');ck(d['status']=='NONPUBLISHABLE-CHUNK',f'd42 chunk status {p.name}');chunks+=d['results']
ck(sorted(r['id'] for r in chunks)==list(range(2451,2524)),'d42 chunks cover');ck(len({r['id'] for r in chunks})==73,'d42 chunks unique')
q42=verify_self('V04_DEPTH42_2451_2523_QUOTIENT_TOOLKIT.json')
ck(q42['counts']=={'classes':73,'ordinary_exits':261,'hits':190,'new':71,'multiwall_cells':0},'q42 counts');ck(q42['hit_buckets']=={'d41':80,'d42':86,'same-pass':23,'d32':1},'q42 buckets')
ck([n['id'] for n in q42['new_depth43_nodes']]==list(range(2909,2980)),'d43 ids')
for e in q42['events']:ck(e['status'] in ('HIT','NEW'),'q42 event status')
idx42=verify_self('V04_REPRESENTATIVE_INDEX_AFTER_D42.json');ck(idx42['representative_count']==2980,'idx42 count');ck([r['id'] for r in idx42['representatives']]==list(range(2980)),'idx42 contiguous')
# d33
c33=verify_self('V04_DEPTH33_2524_2908_CLASSIFICATION_SCC.json');rows33=c33['results']
ck(c33['status']=='PASS-385/385-EXACT-SCC-BY-SCC','d33 class status');ck([r['id'] for r in rows33]==list(range(2524,2909)),'d33 ids')
ck(c33['counts']=={'classes':385,'ordinary_exits':1411,'multiwall_cells':2},'d33 class counts');ck(c33['source_scc_group_sizes']=={'0':378,'1':7},'d33 source sizes');ck(c33['multiwall_ids']==[2895,2899],'d33 multi ids')
expect={2895:[{'factor':'98*q + 345*r - 179','walls':['k','l']}],2899:[{'factor':'98*q + 345*r - 179','walls':['g','m']}]}
for r in rows33:
 ck(set(r['ordinary_walls'])<=set('ghklmn'),f'd33 walls {r["id"]}');ck(r['enlarged_source_scc'] in (0,1),f'd33 source scc {r["id"]}')
 if r['id'] in expect:ck(r['multiwall_components']==expect[r['id']],f'd33 multi {r["id"]}')
chunks=[]
for p in sorted((ROOT/'d33_chunks').glob('*.json')):
 d=json.loads(p.read_text());a,b=selfless(d);ck(a==b,f'd33 chunk self {p.name}');ck(d['status']=='NONPUBLISHABLE-CHUNK',f'd33 chunk status {p.name}');chunks+=d['results']
ck(sorted(r['id'] for r in chunks)==list(range(2524,2909)),'d33 chunks cover');ck(len({r['id'] for r in chunks})==385,'d33 chunks unique')
q33=verify_self('V04_DEPTH33_2524_2908_QUOTIENT_SCC_TOOLKIT.json')
ck(q33['counts']=={'classes':385,'ordinary_exits':1411,'hits':943,'new':468,'multiwall_cells':2},'q33 counts');ck(q33['hit_buckets']=={'d32':473,'d33':365,'same-pass':105},'q33 buckets')
ck(q33['source_scc_counts']=={'0':{'exits':1388,'hits':925,'new':463},'1':{'exits':23,'hits':18,'new':5}},'q33 source counts')
ck([n['id'] for n in q33['new_depth34_nodes']]==list(range(2980,3448)),'d34 ids');ck(q33['d33_internal_scc']['count']==203,'d33 internal SCC')
ck(q33['enlarged_d23_to_d33_scc']['vertex_count']==2032,'enlarged vertex count');ck(q33['enlarged_d23_to_d33_scc']['sizes']==[1979,47,2,1,1,1,1],'enlarged sizes')
for e in q33['events']:ck(e['status'] in ('HIT','NEW'),'q33 event status');ck(e['enlarged_source_scc'] in (0,1),'q33 event source scc')
idx33=verify_self('V04_REPRESENTATIVE_INDEX_AFTER_D33.json');ck(idx33['representative_count']==3448,'idx33 count');ck([r['id'] for r in idx33['representatives']]==list(range(3448)),'idx33 contiguous')
# structural certs
ha=verify_self('V04_GOLDEN_RESIDUAL_AFFINE_H1_ZERO_NO_GO.json')['certificate'];ck(ha['constraint_rank']==5,'affine h1 rank');ck(ha['relation_solution_dimension']==1,'affine zdim');ck(ha['coboundary_rank']==1,'affine bdim');ck(ha['H1_dimension']==0,'affine H1 zero')
hlin=load('V04_SELLING_3D5D_DET_SWAP_H1_ZERO_NO_GO.json')['certificate'];ck(hlin['H1_dimension']==0,'linear H1 retained')
st=verify_self('V04_PUBLIC_SCHEMA_STABILITY_PASS1.json');ck(st['status']=='PASS-PUBLIC-SCHEMA-STABILITY-1-OF-2','schema gate');ck(st['old_exports_preserved'],'old exports');ck(not st['changed_old_signatures'],'old signatures');ck(st['cli_byte_identical'],'cli stable');ck(st['quartic_rational_reference_outputs_identical'],'quartic outputs stable')
est=verify_self('V04_TO_V05_RELEASE_ESTIMATE_CONT11.json');ck(est['estimate']['additional_passes_after_continuation_11']['range']==[2,4],'v05 estimate range');ck(est['estimate']['additional_passes_after_continuation_11']['most_likely']==3,'v05 estimate central')
trep=verify_self('V04_SELLING_TOOLKIT_045_TEST_REPORT.json');ck(trep['pytest']=='16/16 PASS','toolkit report');ck(trep['installed_version']=='0.4.5','toolkit version report');ck(sha(ROOT/trep['wheel'])==trep['wheel_sha256'],'wheel hash');ck(sha(ROOT/trep['source_zip'])==trep['source_zip_sha256'],'source hash')
r7=load('V04_R7_SOURCE_RHO_MARKED_SCREEN_EXTENDED.json');ck('unrecycled' in json.dumps(r7).lower(),'R7 unrecycled field retained')
# dynamic replay
with tempfile.TemporaryDirectory() as td:
 td=Path(td);new=td/'new';old=td/'old';new.mkdir();old.mkdir()
 with zipfile.ZipFile(ROOT/'selling_toolkit_v04_5_source.zip') as z:z.extractall(new)
 with zipfile.ZipFile(ROOT/'selling_toolkit_v04_4_source.zip') as z:z.extractall(old)
 # API snapshots in isolated subprocesses
 code="import inspect,json,selling_toolkit;print(json.dumps({'all':selling_toolkit.__all__,'sig':{n:str(inspect.signature(getattr(selling_toolkit,n))) for n in selling_toolkit.__all__ if callable(getattr(selling_toolkit,n))}},sort_keys=True))"
 def snap(path):
  env=dict(os.environ);env['PYTHONPATH']=str(path);p=subprocess.run([sys.executable,'-c',code],capture_output=True,text=True,env=env);ck(p.returncode==0,'snapshot subprocess');return json.loads(p.stdout)
 so,sn=snap(old),snap(new);ck(all(n in sn['all'] for n in so['all']),'dynamic exports preserved');ck(all(sn['sig'].get(n)==v for n,v in so['sig'].items()),'dynamic signatures preserved')
 sys.path.insert(0,str(new));import selling_toolkit;ck(selling_toolkit.__version__=='0.4.5','source version')
 from selling_toolkit.layers import classify_exact,tarjan_scc
 from selling_toolkit.fast_layers import quotient_layer_fast,FastHitRange
 from selling_toolkit.cohomology import DeterminantSwapH1NoGo,GoldenResidualAffineH1NoGo
 seed=load('toolchain/synthetic_invariant_Qa.seed.json');q41=load('V04_DEPTH41_2083_2130_QUOTIENT_TOOLKIT.json');q32prev=load('V04_DEPTH32_2131_2450_QUOTIENT_SCC_TOOLKIT.json');idx32prev=load('V04_REPRESENTATIVE_INDEX_AFTER_D32.json')['representatives']
 # exact reclassification selected
 ids={2451,2487,2523};rr=classify_exact([n for n in q41['new_depth42_nodes'] if n['id'] in ids],seed,workers=3);sm={r['id']:r for r in rows42}
 for r in rr:ck(r['ordinary_walls']==sm[r['id']]['ordinary_walls'],f'reclass d42 {r["id"]}');ck(r.get('multiwall_components',[])==sm[r['id']].get('multiwall_components',[]),f'reclass d42 multi {r["id"]}')
 ids={2524,2895,2899,2908};rr=classify_exact([n for n in q32prev['new_depth33_nodes'] if n['id'] in ids],seed,workers=4);sm={r['id']:r for r in rows33}
 for r in rr:ck(r['ordinary_walls']==sm[r['id']]['ordinary_walls'],f'reclass d33 {r["id"]}');ck(r.get('multiwall_components',[])==sm[r['id']].get('multiwall_components',[]),f'reclass d33 multi {r["id"]}')
 # q42 replay
 ranges=[FastHitRange('d40',1772,1820),FastHitRange('d31',1821,2082),FastHitRange('d41',2083,2130),FastHitRange('d32',2131,2450),FastHitRange('d42',2451,2523),FastHitRange('d33',2524,2908)]
 qr=quotient_layer_fast(seed=seed,global_representatives=idx32prev,nodes=q41['new_depth42_nodes'],classifications=rows42,target_depth=43,kind='DEPTH43',layer_label='d43',hit_ranges=ranges);ck(qr['events']==q42['events'],'q42 replay events');ck(qr['new_nodes']==q42['new_depth43_nodes'],'q42 replay new')
 # q33 replay
 gprev=q32prev['enlarged_d23_to_d32_scc'];source_scc={i:c['scc'] for c in gprev['components'] for i in c['ids']};ranges2=[FastHitRange('d31',1821,2082),FastHitRange('d41',2083,2130),FastHitRange('d32',2131,2450),FastHitRange('d42',2451,2523),FastHitRange('d33',2524,2908),FastHitRange('d43',2909,2979)]
 qr2=quotient_layer_fast(seed=seed,global_representatives=idx42['representatives'],nodes=q32prev['new_depth33_nodes'],classifications=rows33,target_depth=34,kind='DEPTH34',layer_label='d34',hit_ranges=ranges2,source_scc=source_scc);ck(qr2['events']==q33['events'],'q33 replay events');ck(qr2['new_nodes']==q33['new_depth34_nodes'],'q33 replay new')
 # dynamic H1
 ck(DeterminantSwapH1NoGo.certificate()['H1_dimension']==0,'dynamic linear H1');hc=GoldenResidualAffineH1NoGo.certificate();ck(hc['H1_dimension']==0 and hc['constraint_rank']==5,'dynamic affine H1')
 # pytest
 env=dict(os.environ);env['PYTHONPATH']=str(new);pr=subprocess.run([sys.executable,'-m','pytest','-q',str(new/'tests'/'test_toolkit.py')],capture_output=True,text=True,env=env);ck(pr.returncode==0 and '16 passed' in pr.stdout,'dynamic pytest')
 # wheel install
 target=td/'wheel';target.mkdir();pi=subprocess.run([sys.executable,'-m','pip','install','--no-deps','--target',str(target),str(ROOT/'selling_toolkit-0.4.5-py3-none-any.whl')],capture_output=True,text=True);ck(pi.returncode==0,'wheel install');pv=subprocess.run([sys.executable,'-c',f"import sys;sys.path.insert(0,{str(target)!r});import selling_toolkit;print(selling_toolkit.__version__)"],capture_output=True,text=True);ck(pv.returncode==0 and pv.stdout.strip()=='0.4.5','wheel version')
print(json.dumps({'status':'PASS','checks':N,'version':'v0.4-continuation-11'},indent=2))
