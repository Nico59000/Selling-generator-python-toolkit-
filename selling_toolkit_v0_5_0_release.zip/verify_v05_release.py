import json,hashlib,zipfile,tempfile,subprocess,sys,os,shutil
from pathlib import Path
B=Path(__file__).resolve().parent
checks=[]
def ck(cond,name):
    if not cond: raise AssertionError(name)
    checks.append(name)
def J(name): return json.load(open(B/name))
def selfhash_ok(name):
    j=J(name); exp=j.get('sha256_without_self');
    if exp is None:return True
    jj=dict(j);jj.pop('sha256_without_self',None)
    got=hashlib.sha256(json.dumps(jj,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    return got==exp
# self hashes
for n in [
'V04_DEPTH45_4078_4187_CLASSIFICATION.json','V04_DEPTH45_4078_4187_QUOTIENT_TOOLKIT.json','V04_REPRESENTATIVE_INDEX_AFTER_D45.json',
'V04_DEPTH36_4188_4857_CLASSIFICATION_SCC.json','V04_DEPTH36_4188_4857_QUOTIENT_SCC_TOOLKIT.json','V04_DEPTH36_SCC_RECALCULATION.json','V04_REPRESENTATIVE_INDEX_AFTER_D36.json',
'V04_SAFE_FRONTIER_CONTINUATION_14_CHECKPOINT.json','V04_V55_3D5D_CROSSED_MODULE_OVERLAY.json','V04_V55_3D5D_CROSSED_MODULE_FOX_OVERLAY.json','V05_MIGRATION_046_TO_050_REPORT.json']:
    ck(selfhash_ok(n),f'selfhash {n}')
# d45
c45=J('V04_DEPTH45_4078_4187_CLASSIFICATION.json');q45=J('V04_DEPTH45_4078_4187_QUOTIENT_TOOLKIT.json')
ck(c45['status'].startswith('PASS-110/110'),'d45 class status'); ck(len(c45['results'])==110,'d45 110')
ck(q45['counts']=={'classes':110,'ordinary_exits':395,'hits':265,'new':130,'multiwall_cells':0},'d45 counts')
ck(q45['new_nodes'][0]['id']==4858 and q45['new_nodes'][-1]['id']==4987,'d46 range')
# d36
c36=J('V04_DEPTH36_4188_4857_CLASSIFICATION_SCC.json');q36=J('V04_DEPTH36_4188_4857_QUOTIENT_SCC_TOOLKIT.json')
ck(c36['counts']=={'classes':670,'ordinary_exits':2458,'multiwall_cells':6},'d36 class counts')
ck(q36['counts']=={'classes':670,'ordinary_exits':2458,'hits':1668,'new':790,'multiwall_cells':6},'d36 q counts')
ck(q36['hit_buckets']=={'d35':810,'d36':662,'same-pass':195,'d46':1},'d36 buckets')
ck(q36['new_depth37_nodes'][0]['id']==4988 and q36['new_depth37_nodes'][-1]['id']==5777,'d37 range')
ck([m['id'] for m in q36['multiwalls']]==[4522,4524,4525,4526,4779,4783],'d36 multi ids')
# index
idx=J('V04_REPRESENTATIVE_INDEX_AFTER_D36.json'); ck(idx['representative_count']==5778,'index count'); ck([r['id'] for r in idx['representatives']]==list(range(5778)),'index contiguous')
# SCC
s=J('V04_DEPTH36_SCC_RECALCULATION.json'); ck(s['d36_internal_scc']['count']==339,'d36 internal scc'); ck(s['enlarged_d23_to_d36_scc']['sizes']==[3633,71,2,1,1,1,1],'enlarged sizes')
# chunks exact coverage
for sub,total in [('d45_chunks',110),('d36_chunks',670)]:
    ids=[]
    for p in sorted((B/sub).glob('*.json')):
        j=json.load(open(p)); ck(j['status']=='NONPUBLISHABLE-CHUNK',f'{sub} chunk status {p.name}')
        for r in j['results']: ids.append(r['id'])
    exp=list(range(4078,4188)) if sub=='d45_chunks' else list(range(4188,4858))
    ck(sorted(ids)==exp,f'{sub} exact coverage')
# v55 overlay source guard
ov=J('V04_V55_3D5D_CROSSED_MODULE_OVERLAY.json'); fox=J('V04_V55_3D5D_CROSSED_MODULE_FOX_OVERLAY.json')
ck(ov['status'].startswith('PASS-TYPED'),'overlay status')
ck(fox['status'].startswith('PASS-TYPED'),'fox status')
ck(fox['augmented_Fox_gate']['Fox_boundary']['kernel_rank']==11,'fox kernel rank')
ck(fox['augmented_Fox_gate']['Squier_augmentation']['augmentation_rank']==10,'squier rank')
ck(fox['augmented_Fox_gate']['quotient']['kernel_mod_squier']=='Z direct_sum (Z/2)^5','fox quotient')
ck(fox['promotion_decision']['global_2functor']=='NT/NOT-PROMOTED','global 2functor guard')
# source v55 facts
v55=J('v55_sources/v55_SELLING_3D5D_MARKED_PAIR_2LIFT_CHECKPOINT.json')
ck(v55['opposite_pair_quotient']['homomorphism_checks']=='576/576 PASS','v55 576')
ck(v55['crossed_module_2lift']['finite_relation_complex_status']=='PROVEN-EXACT-2-LIFT-ON-THE-17-RELATION-COMPLEX','v55 2lift')
pf=J('v55_sources/v55_SELLING_3D5D_PEIFFER_REPORT.json'); ck(pf['passed']==463 and pf['failed']==[],'v55 peiffer report'); ck(pf['census']['critical_3cells']==84,'v55 84')
# R7 retained
r7=J('V04_R7_SOURCE_RHO_MARKED_SCREEN_EXTENDED.json'); ck(r7.get('status')=='PASS-SCREEN/NO-UNRECYCLED-R7-CANDIDATE','R7 retained')
# migration
mig=J('V05_MIGRATION_046_TO_050_REPORT.json'); ck(mig['status']=='PASS-METADATA-ONLY-MIGRATION','migration'); ck(mig['all_core_modules_byte_identical'],'core byte identical')
# source tests + wheel clean install + exact quotient replay
with tempfile.TemporaryDirectory() as td:
    td=Path(td); src=td/'src';src.mkdir()
    with zipfile.ZipFile(B/'selling_toolkit_v05_0_source.zip') as z:z.extractall(src)
    rr=subprocess.run([sys.executable,'-m','pytest','-q',str(src/'tests')],env={**os.environ,'PYTHONPATH':str(src)},capture_output=True,text=True)
    ck(rr.returncode==0 and '17 passed' in rr.stdout,'pytest 17')
    inst=td/'inst';inst.mkdir(); rr=subprocess.run([sys.executable,'-m','pip','install','--no-deps','--target',str(inst),str(B/'selling_toolkit-0.5.0-py3-none-any.whl')],capture_output=True,text=True)
    ck(rr.returncode==0,'wheel install')
    code='import selling_toolkit;assert selling_toolkit.__version__=="0.5.0"'
    rr=subprocess.run([sys.executable,'-c',code],env={**os.environ,'PYTHONPATH':str(inst)},capture_output=True,text=True);ck(rr.returncode==0,'wheel version')
    sys.path.insert(0,str(src))
    from selling_toolkit.fast_layers import quotient_layer_fast,FastHitRange
    seed=J('toolchain/synthetic_invariant_Qa.seed.json')
    # d45 replay
    idx35=J('V04_REPRESENTATIVE_INDEX_AFTER_D35.json')['representatives']; q44=J('V04_DEPTH44_3448_3537_QUOTIENT_TOOLKIT.json')
    rr=quotient_layer_fast(seed=seed,global_representatives=idx35,nodes=q44['new_depth45_nodes'],classifications=c45['results'],target_depth=46,kind='d46',layer_label='d46',hit_ranges=[FastHitRange('d35',3538,4077),FastHitRange('d44',3448,3537),FastHitRange('d45',4078,4187)])
    ck(rr['events']==q45['events'],'d45 replay events');
    def norm_nodes(xs):
        ys=[]
        for n in xs:
            n=dict(n); k=str(n.get('kind','')).lower(); n['kind']=k.replace('depth','d') if k.startswith('depth') else k; n.pop('_layer',None); ys.append(n)
        return ys
    ck(norm_nodes(rr['new_nodes'])==norm_nodes(q45['new_nodes']),'d45 replay new')
    # d36 replay
    idx45=J('V04_REPRESENTATIVE_INDEX_AFTER_D45.json')['representatives']; q35=J('V04_DEPTH35_3538_4077_QUOTIENT_SCC_TOOLKIT.json')
    node_scc={i:c['scc'] for c in q35['enlarged_d23_to_d35_scc']['components'] for i in c['ids']}
    rr=quotient_layer_fast(seed=seed,global_representatives=idx45,nodes=q35['new_depth36_nodes'],classifications=c36['results'],target_depth=37,kind='d37',layer_label='d37',hit_ranges=[FastHitRange('d35',3538,4077),FastHitRange('d36',4188,4857),FastHitRange('d46',4858,4987)],source_scc=node_scc)
    ck(rr['events']==q36['events'],'d36 replay events'); ck(norm_nodes(rr['new_nodes'])==norm_nodes(q36['new_depth37_nodes']),'d36 replay new')
# checkpoint release gate
cp=J('V04_SAFE_FRONTIER_CONTINUATION_14_CHECKPOINT.json'); ck(cp['toolkit']['release_candidate']=='0.5.0','rc version'); ck(cp['v05_release_gate']['state']=='RC-PRESEAL/NOT-YET-RELEASED','preseal state')
print(json.dumps({'status':'PASS','checks':len(checks),'failed':[]},indent=2))
