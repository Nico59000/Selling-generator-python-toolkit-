import os,json,sys,time,argparse
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
BASE=Path('/mnt/data/cont30');sys.path.insert(0,str(BASE/'toolkit_src'))
import sympy as sp
from sympy.core.cache import clear_cache
from selling_seed2d.chart import build_chart
from selling_seed2d.classifier import ExactBoundaryClassifier
INDEX=BASE/'base29_extract/POSTV05_REPRESENTATIVE_INDEX_AFTER_D53.json'
SEED=BASE/'base29_extract/inputs/synthetic_invariant_Qa.seed.json'
_G=None

def load(p):return json.load(open(p,encoding='utf-8'))
def imat(rows):return sp.Matrix([[sp.Integer(v) for v in row] for row in rows])
def init_worker(seed):
 global _G
 c=build_chart(seed);_G=ExactBoundaryClassifier(c.q,c.r,c.wall_vector,c.D0)
def worker(node):
 try:
  c=_G.classify_cell(imat(node['L']))
  return {'id':int(node['id']),'ordinary_walls':list(c['ordinary_walls']),'multiwall_components':[{'factor':z['factor'],'walls':list(z['walls'])} for z in c.get('multiwall_components',[])],'polynomials':c.get('polynomials',{})}
 finally:clear_cache()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--start',type=int,required=True);ap.add_argument('--end',type=int,required=True);ap.add_argument('--workers',type=int,default=5);ap.add_argument('--out',required=True);a=ap.parse_args()
 out=Path(a.out);out.mkdir(parents=True,exist_ok=True);reps=load(INDEX)['representatives'];nodes=[reps[i] for i in range(a.start,a.end+1)];todo=[n for n in nodes if not (out/f"{n['id']}.json").exists()]
 print('START',len(todo),flush=True);t=time.time();ok=0
 with ProcessPoolExecutor(max_workers=a.workers,initializer=init_worker,initargs=(load(SEED),)) as ex:
  fs={ex.submit(worker,n):n for n in todo}
  for f in as_completed(fs):
   x=f.result();p=out/f"{x['id']}.json";tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(x,sort_keys=True,separators=(',',':'))+'\n');os.replace(tmp,p);ok+=1
   if ok%10==0 or ok==len(todo):print('P',ok,'/',len(todo),'sec',round(time.time()-t,2),flush=True)
 print('END',ok,round(time.time()-t,2),flush=True)
if __name__=='__main__':main()
