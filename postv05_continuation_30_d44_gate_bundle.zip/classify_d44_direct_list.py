import os,json,sys,time
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
BASE=Path('/mnt/data/cont30');sys.path.insert(0,str(BASE/'toolkit_src'))
import sympy as sp
from sympy.core.cache import clear_cache
from selling_seed2d.chart import build_chart
from selling_seed2d.classifier import ExactBoundaryClassifier
IDX=json.load(open(BASE/'base29_extract/POSTV05_REPRESENTATIVE_INDEX_AFTER_D53.json'))['representatives'];SEED=json.load(open(BASE/'base29_extract/inputs/synthetic_invariant_Qa.seed.json'));OUT=BASE/'direct_validation';OUT.mkdir(exist_ok=True);_G=None
def init():
 global _G
 c=build_chart(SEED);_G=ExactBoundaryClassifier(c.q,c.r,c.wall_vector,c.D0)
def work(i):
 try:
  n=IDX[i];L=sp.Matrix([[sp.Integer(v) for v in row] for row in n['L']]);c=_G.classify_cell(L)
  return {'id':i,'ordinary_walls':list(c['ordinary_walls']),'multiwall_components':[{'factor':z['factor'],'walls':list(z['walls'])} for z in c.get('multiwall_components',[])],'polynomials':c.get('polynomials',{})}
 finally:clear_cache()
ids=[int(x) for x in open(BASE/'direct_ids.txt') if x.strip()];todo=[i for i in ids if not (OUT/f'{i}.json').exists()];t=time.time();print('START',len(todo),flush=True)
with ProcessPoolExecutor(max_workers=5,initializer=init) as ex:
 fs={ex.submit(work,i):i for i in todo};done=0
 for f in as_completed(fs):
  x=f.result();p=OUT/f"{x['id']}.json";tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(x,sort_keys=True,separators=(',',':'))+'\n');os.replace(tmp,p);done+=1
  if done%10==0 or done==len(todo):print('P',done,round(time.time()-t,2),flush=True)
print('END',done,round(time.time()-t,2),flush=True)
