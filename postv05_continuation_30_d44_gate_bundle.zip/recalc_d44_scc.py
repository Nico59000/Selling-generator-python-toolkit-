import sys,json,hashlib
from pathlib import Path
from collections import Counter
BASE=Path('/mnt/data/cont30');sys.path.insert(0,str(BASE/'toolkit_src'))
from selling_toolkit.layers import tarjan_scc
def load(p):return json.load(open(p))
def write(name,obj):
 raw=json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode();h=hashlib.sha256(raw).hexdigest();obj=dict(obj);obj['sha256_without_self']=h;(BASE/name).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n');return h
old=load('/mnt/data/cont28/POSTV05_DEPTH43_SCC_RECALCULATION.json');old_comps={c['scc']:c['ids'] for c in old['components']};id2old={i:s for s,ids in old_comps.items() for i in ids}
def ov(s):return -(s+1)
meta_vertices=[ov(s) for s in sorted(old_comps)]+list(range(17362,20237));meta_edges=[]
for e in old.get('condensation_edges',[]):meta_edges.append((ov(e['from']),ov(e['to'])))
q43=load('/mnt/data/cont28/POSTV05_DEPTH43_14478_16874_QUOTIENT_TOOLKIT.json')
for e in q43['events']:
 t=int(e['target']);s=int(e['source'])
 if 17362<=t<=20236:
  assert s in id2old;meta_edges.append((ov(id2old[s]),t))
q44=load(BASE/'POSTV05_DEPTH44_17362_20236_QUOTIENT_TOOLKIT.json')
for e in q44['events']:
 s=int(e['source']);t=int(e['target'])
 if t in id2old:meta_edges.append((s,ov(id2old[t])))
 elif 17362<=t<=20236:meta_edges.append((s,t))
meta=tarjan_scc(meta_vertices,meta_edges);expanded=[]
for c in meta['components']:
 ids=[]
 for v in c['ids']:
  if v<0:ids.extend(old_comps[-v-1])
  else:ids.append(v)
 expanded.append(sorted(ids))
expanded.sort(key=lambda c:(-len(c),c[0]));cid={v:i for i,c in enumerate(expanded) for v in c};cond=Counter()
for a,b in meta_edges:
 aa=old_comps[-a-1][0] if a<0 else a;bb=old_comps[-b-1][0] if b<0 else b
 if cid[aa]!=cid[bb]:cond[(cid[aa],cid[bb])]+=1
res={'version':'post-v0.5-continuation-30','phase':'d44-scc-recalculation','status':'PASS-EXACT-SCC-RECALC','scope':'d23..d44 only; side layers and new d45 excluded','method':'exact old d23..d43 SCC contraction + all d43->d44 and d44->(d23..d44) quotient edges','vertex_count':sum(map(len,expanded)),'count':len(expanded),'sizes':[len(c) for c in expanded],'components':[{'scc':i,'size':len(c),'ids':c} for i,c in enumerate(expanded)],'condensation_edges':[{'from':a,'to':b,'count':n} for (a,b),n in sorted(cond.items())],'edge_summary':{'old_condensation_edges':len(old.get('condensation_edges',[])),'d43_to_d44':sum(17362<=int(e['target'])<=20236 for e in q43['events']),'d44_to_old':sum(int(e['target']) in id2old for e in q44['events']),'d44_to_d44':sum(17362<=int(e['target'])<=20236 for e in q44['events'])},'guards':['old d23..d43 SCC partition from sealed continuation 28','side layers d51,d52,d53,d54 and new d45 excluded','all relevant quotient edges included; multiwalls not expanded','overlays excluded']}
h=write('POSTV05_DEPTH44_SCC_RECALCULATION.json',res);print(json.dumps({'status':res['status'],'vertex_count':res['vertex_count'],'count':res['count'],'sizes':res['sizes'],'edge_summary':res['edge_summary'],'sha256_without_self':h},indent=2));id2new={i:c['scc'] for c in res['components'] for i in c['ids']};cnt=Counter(id2new[int(n['source'])] for n in q44['new_depth45_nodes']);print('D45_SOURCE_SCC',dict(sorted(cnt.items())))
