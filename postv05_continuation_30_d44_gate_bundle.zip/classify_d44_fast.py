import os,json,sys,time,argparse
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import sympy as sp
from sympy.core.cache import clear_cache
BASE=Path('/mnt/data/cont30');sys.path.insert(0,str(BASE/'toolkit_src'))
from selling_seed2d.chart import build_chart
from selling_seed2d.classifier import ExactBoundaryClassifier
IDX=json.load(open(BASE/'base29_extract/POSTV05_REPRESENTATIVE_INDEX_AFTER_D53.json'))['representatives'];SEED=json.load(open(BASE/'base29_extract/inputs/synthetic_invariant_Qa.seed.json'));_G=None
class FastSignMixin:
 def root_sign(self,poly_r,root_poly,iv):
  r=self.r;G=sp.Poly(poly_r,r,domain=sp.QQ);F=sp.Poly(root_poly,r,domain=sp.QQ)
  if G.is_zero:return 0
  R=G.rem(F)
  if R.is_zero:return 0
  if R.degree()<=0:
   v=R.LC();return 1 if v>0 else -1
  if R.degree()==1:
   a,b=R.all_coeffs();t=-b/a
   if F.eval(t)==0:return 0
   lo,hi=iv
   for _ in range(40):
    if hi<t:return -1 if a>0 else 1
    if t<lo:return 1 if a>0 else -1
    if lo==hi:return 1 if a*(lo-t)>0 else -1
    lo,hi=sp.refine_root(F,lo,hi,eps=(hi-lo)/10)
  return super().root_sign(poly_r,root_poly,iv)
class FastExact(FastSignMixin,ExactBoundaryClassifier):pass
def init():
 global _G
 c=build_chart(SEED);_G=FastExact(c.q,c.r,c.wall_vector,c.D0)
def work(i):
 try:
  n=IDX[i];L=sp.Matrix([[sp.Integer(v) for v in row] for row in n['L']]);c=_G.classify_cell(L)
  return {'id':i,'ordinary_walls':list(c['ordinary_walls']),'multiwall_components':[{'factor':z['factor'],'walls':list(z['walls'])} for z in c.get('multiwall_components',[])],'polynomials':c.get('polynomials',{})}
 finally:clear_cache()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--start',type=int,default=17362);ap.add_argument('--end',type=int,default=20236);ap.add_argument('--workers',type=int,default=5);ap.add_argument('--out',default='/mnt/data/cont30/d44_results');a=ap.parse_args();out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
 # seed output with direct results so we never replace them
 for p in (BASE/'direct_validation').glob('*.json'):
  q=out/p.name
  if not q.exists():q.write_bytes(p.read_bytes())
 todo=[i for i in range(a.start,a.end+1) if not (out/f'{i}.json').exists()];print('START total',a.end-a.start+1,'todo',len(todo),flush=True);t=time.time();done=0
 with ProcessPoolExecutor(max_workers=a.workers,initializer=init) as ex:
  fs={ex.submit(work,i):i for i in todo}
  for f in as_completed(fs):
   x=f.result();p=out/f"{x['id']}.json";tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(x,sort_keys=True,separators=(',',':'))+'\n');os.replace(tmp,p);done+=1
   if done%100==0 or done==len(todo):print('P',done,'saved',len(list(out.glob('*.json'))),'sec',round(time.time()-t,2),flush=True)
 print('END',done,'saved',len(list(out.glob('*.json'))),'sec',round(time.time()-t,2),flush=True)
if __name__=='__main__':main()
