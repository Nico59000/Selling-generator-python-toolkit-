import json,sys,time
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import sympy as sp
from sympy.core.cache import clear_cache
BASE=Path('/mnt/data/cont30');sys.path.insert(0,str(BASE/'toolkit_src'))
from selling_seed2d.chart import build_chart
from selling_seed2d.classifier import ExactBoundaryClassifier
IDX=json.load(open(BASE/'base29_extract/POSTV05_REPRESENTATIVE_INDEX_AFTER_D53.json'))['representatives'];SEED=json.load(open(BASE/'base29_extract/inputs/synthetic_invariant_Qa.seed.json'));_G=None
def init():
 global _G
 c=build_chart(SEED);_G=ExactBoundaryClassifier(c.q,c.r,c.wall_vector,c.D0)
def work(i):
 try:
  n=IDX[i];L=sp.Matrix([[sp.Integer(v) for v in row] for row in n['L']]);c=_G.classify_cell(L)
  return {'id':i,'ordinary_walls':list(c['ordinary_walls']),'multiwall_components':[{'factor':z['factor'],'walls':list(z['walls'])} for z in c.get('multiwall_components',[])],'polynomials':c.get('polynomials',{})}
 finally:clear_cache()
rows=[]
for i in range(17362,20237):
 p=BASE/'d44_results'/f'{i}.json'
 if not p.exists():raise SystemExit('incomplete d44')
 x=json.load(open(p))
 if x['multiwall_components']:rows.append(x)
exp={x['id']:x for x in rows};ids=sorted(exp);bad=[];t=time.time();out=BASE/'direct_multiwalls';out.mkdir(exist_ok=True)
with ProcessPoolExecutor(max_workers=5,initializer=init) as ex:
 fs={ex.submit(work,i):i for i in ids}
 for f in as_completed(fs):
  x=f.result();(out/f"{x['id']}.json").write_text(json.dumps(x,sort_keys=True,separators=(',',':'))+'\n')
  if x!=exp[x['id']]:bad.append(x['id'])
rep={'status':'PASS' if not bad else 'FAIL','count':len(ids),'ids':ids,'mismatches':sorted(bad),'elapsed_seconds':time.time()-t,'engine':'selling-toolkit 0.5.0 ExactBoundaryClassifier original direct'}
(BASE/'D44_DIRECT_MULTIWALL_VALIDATION.json').write_text(json.dumps(rep,indent=2,sort_keys=True)+'\n');print(json.dumps(rep),flush=True)
