import json,sys,time,math
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import sympy as sp
from sympy.core.cache import clear_cache
ROOT=Path('/mnt/data/cont30/postseal_fresh_extract');sys.path.insert(0,str(ROOT/'toolkit_src'))
from selling_seed2d.chart import build_chart
from selling_seed2d.classifier import ExactBoundaryClassifier
IDX=json.load(open(ROOT/'POSTV05_REPRESENTATIVE_INDEX_AFTER_D53.json'))['representatives'];SEED=json.load(open(ROOT/'inputs/synthetic_invariant_Qa.seed.json'));EXP={x['id']:x for x in json.load(open(ROOT/'POSTV05_DEPTH44_17362_20236_CLASSIFICATION.json'))['classifications']};_G=None
def init():
 global _G
 c=build_chart(SEED);_G=ExactBoundaryClassifier(c.q,c.r,c.wall_vector,c.D0)
def work(i):
 try:
  n=IDX[i];L=sp.Matrix([[sp.Integer(v) for v in row] for row in n['L']]);c=_G.classify_cell(L)
  return {'id':i,'ordinary_walls':list(c['ordinary_walls']),'multiwall_components':[{'factor':z['factor'],'walls':list(z['walls'])} for z in c.get('multiwall_components',[])],'polynomials':c.get('polynomials',{})}
 finally:clear_cache()
# all multiwalls + 50 distributed points
mw=[i for i,x in EXP.items() if x['multiwall_components']];dist=sorted(set(round(17362+k*(20236-17362)/49) for k in range(50)));ids=sorted(set(mw+dist));t=time.time();bad=[]
with ProcessPoolExecutor(max_workers=5,initializer=init) as ex:
 fs={ex.submit(work,i):i for i in ids}
 for f in as_completed(fs):
  x=f.result();
  if x!=EXP[x['id']]:bad.append(x['id'])
rep={'status':'PASS' if not bad else 'FAIL','checked':len(ids),'multiwall_checked':len(mw),'multiwall_ids':mw,'distributed_points':len(dist),'mismatches':sorted(bad),'elapsed_seconds':time.time()-t,'engine':'fresh extracted selling-toolkit 0.5.0 ExactBoundaryClassifier original'}
(ROOT/'DIRECT_TOOLKIT_D44_CROSSCHECK.json').write_text(json.dumps(rep,indent=2,sort_keys=True)+'\n');print(json.dumps(rep),flush=True)
