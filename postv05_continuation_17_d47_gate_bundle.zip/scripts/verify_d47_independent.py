import sys,json,os,time,hashlib
sys.path.insert(0,'/mnt/data/post_v05/rel/src')
from selling_seed2d.algebra import S,FIRST_MOVE,WALL_ACTION,RELABEL,build_finite_group
from selling_seed2d.seed import seed_matrices
ROOT='/mnt/data/post_v05'; BASE=ROOT+'/rel'; OUT=ROOT+'/d47_gate'
load=lambda p:json.load(open(p))
seed=load(BASE+'/toolchain/synthetic_invariant_Qa.seed.json')
reps=load(ROOT+'/d37_gate/POSTV05_REPRESENTATIVE_INDEX_AFTER_D37.json')['representatives']
nodes=reps[5778:5946]
clf=load(OUT+'/POSTV05_DEPTH47_5778_5945_CLASSIFICATION.json')
quot=load(OUT+'/POSTV05_DEPTH47_5778_5945_QUOTIENT_TOOLKIT.json')
_Q,_A,Qc,deck_named=seed_matrices(seed); deck=build_finite_group([g for _,g in deck_named],32)
def mm(A,B):
    B=list(zip(*B)); return tuple(tuple(sum(a*b for a,b in zip(row,col)) for col in B) for row in A)
def tr(A):return tuple(zip(*A))
def neg(A):return tuple(tuple(-x for x in r) for r in A)
def key(A):return tuple(x for r in A for x in r)
def smat(M):return tuple(tuple(int(x) for x in row) for row in M.tolist())
D=[smat(x) for x in deck]; R=[smat(x) for x in RELABEL]; Sm={w:smat(S[FIRST_MOVE[w]-1]) for w in FIRST_MOVE}; Wm={w:smat(WALL_ACTION[w]) for w in WALL_ACTION}; Q=smat(Qc)
variants={}; current=[dict(x) for x in reps]
def add(rid,A):
    for di,d in enumerate(D):
        DA=mm(d,A)
        for ri,r in enumerate(R):
            X=mm(DA,r)
            variants.setdefault(key(X),(rid,di,ri,1)); variants.setdefault(key(neg(X)),(rid,di,ri,-1))
t=time.time()
for x in current:add(int(x['id']),tuple(tuple(int(v) for v in row) for row in x['A']))
build_sec=time.time()-t
cm={r['id']:r for r in clf['results']}; expected=quot['events']; got=[]; new=[]; next_id=len(current)
for n in nodes:
    i=n['id']; A=tuple(tuple(int(v) for v in row) for row in n['A']); L=tuple(tuple(int(v) for v in row) for row in n['L'])
    for wall in cm[i]['ordinary_walls']:
        An=mm(A,Sm[wall]); Ln=mm(Wm[wall],L); M=mm(mm(tr(An),Q),An)
        con=[sum(M[i][j] for j in range(3)) for i in range(3)]+[-M[0][1],-M[0][2],-M[1][2]]; j2=sum(v*v for v in con)
        e={'source':i,'wall':wall,'J2':str(j2)}; hit=variants.get(key(An))
        if hit is not None:
            target,di,ri,sign=hit;e.update(status='HIT',target=target,deck_index=di,relabel_index=ri,sign=sign)
        else:
            target=next_id;next_id+=1;e.update(status='NEW',target=target)
            nn={'id':target,'path_from_C2':n.get('path_from_C2','')+wall,'kind':'DEPTH48','depth':48,'source':i,'arrival_wall':wall,'A':[[str(v) for v in row] for row in An],'L':[[str(v) for v in row] for row in Ln],'M':[[str(v) for v in row] for row in M],'J2':str(j2),'conorm6':[str(v) for v in con],'_layer':'d48-post-v05-cont17'}
            new.append(nn);current.append(nn);add(target,An)
        got.append(e)
fail=[]
if got!=expected: fail.append('event_sequence_mismatch')
if new!=quot['new_depth48_nodes']: fail.append('new_node_sequence_mismatch')
if len(got)!=606: fail.append('event_count')
if len(new)!=187: fail.append('new_count')
ids=[r['id'] for r in clf['results']]
if ids!=list(range(5778,5946)): fail.append('classification_coverage')
multi=[(r['id'],r.get('multiwall_components',[])) for r in clf['results'] if r.get('multiwall_components')]
expected_multi=[
 (5876,[{'factor':'6*q + 5*r - 7','walls':['g','k']}]),
 (5882,[{'factor':'6*q + 5*r - 7','walls':['g','m']}])]
if multi!=expected_multi: fail.append('multiwall_exact_list')
mx=max(abs(int(v)) for n in nodes for row in n['A'] for v in row)
mxL=max(abs(int(v)) for n in nodes for row in n['L'] for v in row)
sha=lambda p:hashlib.sha256(open(p,'rb').read()).hexdigest()
report={'version':'post-v0.5-continuation-17','status':'PASS' if not fail else 'FAIL','independent_oracle':'pure-Python arbitrary-precision integer canonical quotient; no FastCanonicalIndex used','checks':{'classification_ids_168_contiguous':ids==list(range(5778,5946)),'ordinary_exit_count_606':sum(len(r['ordinary_walls']) for r in clf['results'])==606,'multiwall_exact_two':multi==expected_multi,'event_sequence_matches_fast':got==expected,'new_nodes_match_fast':new==quot['new_depth48_nodes'],'final_index_size':len(current),'final_index_last_id':len(current)-1,'deck_size':len(D),'relabel_size':len(R),'variant_count':len(variants),'input_max_abs_A':mx,'input_max_abs_L':mxL},'failures':fail,'elapsed_variant_build_seconds':build_sec,'source_sha256':{'classification':sha(OUT+'/POSTV05_DEPTH47_5778_5945_CLASSIFICATION.json'),'quotient':sha(OUT+'/POSTV05_DEPTH47_5778_5945_QUOTIENT_TOOLKIT.json'),'index_before':sha(ROOT+'/d37_gate/POSTV05_REPRESENTATIVE_INDEX_AFTER_D37.json')}}
raw=json.dumps(report,sort_keys=True,separators=(',',':')).encode();report['sha256_without_self']=hashlib.sha256(raw).hexdigest()
with open(OUT+'/POSTV05_DEPTH47_INDEPENDENT_VERIFICATION_REPORT.json','w') as f:json.dump(report,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps(report,indent=2,sort_keys=True))
