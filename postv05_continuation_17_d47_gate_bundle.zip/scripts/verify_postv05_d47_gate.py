#!/usr/bin/env python3
import sys,json,zipfile,tempfile,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def load(p): return json.load(open(p))
rows=[];bad=[]
for p in sorted((R/'chunks').glob('d47_*.json')):
    d=load(p); x=dict(d); h=x.pop('sha256_without_self',None); raw=json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
    if hashlib.sha256(raw).hexdigest()!=h: bad.append('chunk_hash:'+p.name)
    rows+=d['results']
rows.sort(key=lambda r:r['id'])
clf=load(R/'POSTV05_DEPTH47_5778_5945_CLASSIFICATION.json')
if rows!=clf['results']: bad.append('chunk_assembly_mismatch')
if [r['id'] for r in rows]!=list(range(5778,5946)): bad.append('coverage')
with tempfile.TemporaryDirectory() as td:
    zipfile.ZipFile(R/'inputs/selling_toolkit_v05_0_source.zip').extractall(td);sys.path.insert(0,td)
    from selling_toolkit.layers import classify_exact
    from selling_seed2d.algebra import S,FIRST_MOVE,WALL_ACTION,RELABEL,build_finite_group
    from selling_seed2d.seed import seed_matrices
    seed=load(R/'inputs/synthetic_invariant_Qa.seed.json');reps=load(R/'inputs/POSTV05_REPRESENTATIVE_INDEX_AFTER_D37.json')['representatives'];nodes=reps[5778:5946]
    cm={r['id']:r for r in rows}; ids=list(range(5778,5788))+[5876,5882]
    direct=classify_exact([reps[i] for i in ids],seed,workers=5)
    if direct!=[cm[i] for i in ids]: bad.append('direct_classifier_mismatch')
    quot=load(R/'POSTV05_DEPTH47_5778_5945_QUOTIENT_TOOLKIT.json')
    _Q,_A,Qc,deck_named=seed_matrices(seed);deck=build_finite_group([g for _,g in deck_named],32)
    def smat(M):return tuple(tuple(int(x) for x in row) for row in M.tolist())
    def mm(A,B):
        C=list(zip(*B));return tuple(tuple(sum(a*b for a,b in zip(row,col)) for col in C) for row in A)
    def tr(A):return tuple(zip(*A))
    def neg(A):return tuple(tuple(-x for x in row) for row in A)
    def key(A):return tuple(x for row in A for x in row)
    D=[smat(x) for x in deck];RR=[smat(x) for x in RELABEL];Sm={w:smat(S[FIRST_MOVE[w]-1]) for w in FIRST_MOVE};Wm={w:smat(WALL_ACTION[w]) for w in WALL_ACTION};Q=smat(Qc)
    variants={};current=[dict(x) for x in reps]
    def add(rid,A):
        for di,d in enumerate(D):
            DA=mm(d,A)
            for ri,r in enumerate(RR):
                X=mm(DA,r);variants.setdefault(key(X),(rid,di,ri,1));variants.setdefault(key(neg(X)),(rid,di,ri,-1))
    for x in current:add(int(x['id']),tuple(tuple(int(v) for v in row) for row in x['A']))
    got=[];new=[];next_id=len(current)
    for n in nodes:
        A=tuple(tuple(int(v) for v in row) for row in n['A']);L=tuple(tuple(int(v) for v in row) for row in n['L'])
        for wall in cm[n['id']]['ordinary_walls']:
            An=mm(A,Sm[wall]);Ln=mm(Wm[wall],L);M=mm(mm(tr(An),Q),An);con=[sum(M[i][j] for j in range(3)) for i in range(3)]+[-M[0][1],-M[0][2],-M[1][2]];j2=sum(v*v for v in con)
            e={'source':n['id'],'wall':wall,'J2':str(j2)};hit=variants.get(key(An))
            if hit is not None:
                target,di,ri,sign=hit;e.update(status='HIT',target=target,deck_index=di,relabel_index=ri,sign=sign)
            else:
                target=next_id;next_id+=1;e.update(status='NEW',target=target)
                nn={'id':target,'path_from_C2':n.get('path_from_C2','')+wall,'kind':'DEPTH48','depth':48,'source':n['id'],'arrival_wall':wall,'A':[[str(v) for v in row] for row in An],'L':[[str(v) for v in row] for row in Ln],'M':[[str(v) for v in row] for row in M],'J2':str(j2),'conorm6':[str(v) for v in con],'_layer':'d48-post-v05-cont17'}
                new.append(nn);current.append(nn);add(target,An)
            got.append(e)
    if got!=quot['events']: bad.append('event_replay_mismatch')
    if new!=quot['new_depth48_nodes']: bad.append('new_node_replay_mismatch')
    if len(current)!=7074: bad.append('final_index_size')
expected_multi=[(5876,'6*q + 5*r - 7',['g','k']),(5882,'6*q + 5*r - 7',['g','m'])]
got_multi=[]
for r in rows:
    for c in r.get('multiwall_components',[]): got_multi.append((r['id'],c['factor'],c['walls']))
if got_multi!=expected_multi: bad.append('multiwall_list')
q=load(R/'POSTV05_DEPTH47_5778_5945_QUOTIENT_TOOLKIT.json')
if q['counts']!={'classes':168,'ordinary_exits':606,'hits':419,'new':187,'multiwall_cells':2}: bad.append('quotient_counts')
if q['hit_buckets']!={'d46':201,'d47':182,'same-pass':36}: bad.append('hit_buckets')
audit=load(R/'POSTV05_CONTINUATION_17_TOOLKIT_FREEZE_AUDIT.json')
if audit['status']!='PASS-TOOLKIT-0.5.0-FROZEN-UNCHANGED': bad.append('toolkit_freeze')
hyp=load(R/'POSTV05_FACTOR345_TRIANGLE345_HYPOTHESIS_REGISTRY.json')
if hyp['status']!='CONTEXT/PENDING-MORPHISM': bad.append('345_guard')
print(json.dumps({'status':'PASS' if not bad else 'FAIL','failed':bad,'classification':len(rows),'events':len(q['events']),'new':len(q['new_depth48_nodes']),'index_last':7073},sort_keys=True))
raise SystemExit(1 if bad else 0)
