#!/usr/bin/env python3
import json,hashlib,zipfile,tempfile,subprocess,sys,os,inspect,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parent
N=0

def ck(cond,msg):
 global N
 if not cond: raise AssertionError(msg)
 N+=1

def load(name): return json.loads((ROOT/name).read_text())
def selfless(d):
 got=d.get('sha256_without_self'); x=dict(d); x.pop('sha256_without_self',None)
 raw=json.dumps(x,sort_keys=True,separators=(',',':')).encode(); return got,hashlib.sha256(raw).hexdigest()
def verify_self(name):
 d=load(name);a,b=selfless(d);ck(a==b,f'selfhash {name}');return d
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

cp=verify_self('V04_SAFE_FRONTIER_CONTINUATION_12_CHECKPOINT.json')
ck(cp['version']=='v0.4-continuation-12','checkpoint version'); ck(cp['status'].startswith('RESEARCH-CHECKPOINT'),'checkpoint state')
ck(cp['numeric_frontier']['global_index']['range']==[0,4077],'checkpoint global range'); ck(cp['numeric_frontier']['global_index']['count']==4078,'checkpoint global count')
# d43 classification + chunks
c43=verify_self('V04_DEPTH43_2909_2979_CLASSIFICATION.json'); rows43=c43['results']
ck(c43['status']=='PASS-71/71-EXACT','d43 class status'); ck([r['id'] for r in rows43]==list(range(2909,2980)),'d43 ids')
ck(c43['counts']=={'classes':71,'ordinary_exits':254,'multiwall_cells':0},'d43 class counts'); ck(c43['multiwall_ids']==[],'d43 no multi')
chunks=[]
for p in sorted((ROOT/'d43_chunks').glob('*.json')):
 d=json.loads(p.read_text()); a,b=selfless(d); ck(a==b,f'd43 chunk self {p.name}'); ck(d['status']=='NONPUBLISHABLE-CHUNK',f'd43 chunk status {p.name}'); chunks+=d['results']
ck(len(list((ROOT/'d43_chunks').glob('*.json')))==8,'d43 chunk count'); ck(sorted(r['id'] for r in chunks)==list(range(2909,2980)),'d43 chunk coverage'); ck(len({r['id'] for r in chunks})==71,'d43 chunk uniqueness')
# d43 quotient/index
q43=verify_self('V04_DEPTH43_2909_2979_QUOTIENT_TOOLKIT.json')
ck(q43['counts']=={'classes':71,'ordinary_exits':254,'hits':164,'new':90,'multiwall_cells':0},'q43 counts'); ck(q43['hit_buckets']=={'d42':95,'d43':48,'same-pass':20,'d34':1},'q43 buckets')
ck([n['id'] for n in q43['new_depth44_nodes']]==list(range(3448,3538)),'d44 ids')
for e in q43['events']: ck(e['status'] in ('HIT','NEW'),'q43 event status')
idx43=verify_self('V04_REPRESENTATIVE_INDEX_AFTER_D43.json'); ck(idx43['representative_count']==3538,'idx43 count'); ck([r['id'] for r in idx43['representatives']]==list(range(3538)),'idx43 contiguous')
# d34 classification + chunks
c34=verify_self('V04_DEPTH34_2980_3447_CLASSIFICATION_SCC.json'); rows34=c34['results']
ck(c34['status']=='PASS-468/468-EXACT-SCC-BY-SCC','d34 class status'); ck([r['id'] for r in rows34]==list(range(2980,3448)),'d34 ids')
ck(c34['counts']=={'classes':468,'ordinary_exits':1718,'multiwall_cells':4},'d34 class counts'); ck(c34['source_scc_group_sizes']=={'0':463,'1':5},'d34 source sizes'); ck(c34['multiwall_ids']==[3214,3390,3396,3447],'d34 multi ids')
expect={3214:[{'factor':'2*q + 5*r - 3','walls':['h','l']}],3390:[{'factor':'362*q + 1389*r - 699','walls':['h','n']}],3396:[{'factor':'362*q + 1389*r - 699','walls':['m','n']}],3447:[{'factor':'2*q + 5*r - 3','walls':['m','n']}]}
for r in rows34:
 ck(set(r['ordinary_walls'])<=set('ghklmn'),f'd34 walls {r["id"]}'); ck(r['enlarged_source_scc'] in (0,1),f'd34 source scc {r["id"]}')
 if r['id'] in expect: ck(r['multiwall_components']==expect[r['id']],f'd34 multi {r["id"]}')
chunks=[]
for p in sorted((ROOT/'d34_chunks').glob('*.json')):
 d=json.loads(p.read_text());a,b=selfless(d);ck(a==b,f'd34 chunk self {p.name}');ck(d['status']=='NONPUBLISHABLE-CHUNK',f'd34 chunk status {p.name}');chunks+=d['results']
ck(len(list((ROOT/'d34_chunks').glob('*.json')))==25,'d34 chunk count'); ck(sorted(r['id'] for r in chunks)==list(range(2980,3448)),'d34 chunks cover'); ck(len({r['id'] for r in chunks})==468,'d34 chunks unique')
q34=verify_self('V04_DEPTH34_2980_3447_QUOTIENT_SCC_TOOLKIT.json')
ck(q34['counts']=={'classes':468,'ordinary_exits':1718,'hits':1178,'new':540,'multiwall_cells':4},'q34 counts'); ck(q34['hit_buckets']=={'d33':573,'d34':478,'same-pass':126,'d43':1},'q34 buckets')
ck(q34['source_scc_counts']=={'0':{'exits':1699,'hits':1167,'new':532},'1':{'exits':19,'hits':11,'new':8}},'q34 source counts')
ck([n['id'] for n in q34['new_depth35_nodes']]==list(range(3538,4078)),'d35 ids'); ck(q34['d34_internal_scc']['count']==229,'d34 internal SCC'); ck(q34['enlarged_d23_to_d34_scc']['vertex_count']==2500,'enlarged vertex count'); ck(q34['enlarged_d23_to_d34_scc']['sizes']==[2442,52,2,1,1,1,1],'enlarged sizes')
for e in q34['events']: ck(e['status'] in ('HIT','NEW'),'q34 event status'); ck(e['enlarged_source_scc'] in (0,1),'q34 event source scc')
idx34=verify_self('V04_REPRESENTATIVE_INDEX_AFTER_D34.json'); ck(idx34['representative_count']==4078,'idx34 count'); ck([r['id'] for r in idx34['representatives']]==list(range(4078)),'idx34 contiguous')
# structural/freeze certs
ng=verify_self('V04_BASE_MODULE_RANK2_FIBRE_NO_GO.json')['certificate']; ck(ng['generated_algebra_dimension']==9,'rank2 algebra dim'); ck(ng['generated_algebra_equals_M3Q'],'rank2 M3'); ck(ng['commutant_dimension']==1,'rank2 commutant'); ck(ng['irreducible_base_module'],'rank2 irreducible'); ck(not ng['rank2_subrepresentation_exists'],'no rank2 subrep'); ck(not ng['rank2_quotient_representation_exists'],'no rank2 quotient')
st=verify_self('V04_PUBLIC_SCHEMA_STABILITY_PASS2.json'); ck(st['status']=='PASS-PUBLIC-SCHEMA-STABILITY-2-OF-2','schema pass2'); ck(st['old_exports_preserved'],'old exports'); ck(not st['changed_old_signatures'],'signatures stable'); ck(st['cli_byte_identical'],'cli stable'); ck(st['quartic_rational_reference_outputs_identical'],'quartic references stable')
fr=verify_self('V04_V05_PUBLIC_FREEZE_CANDIDATE.json'); ck(fr['status']=='PASS-V05-PUBLIC-FREEZE-CANDIDATE/NOT-RELEASED','freeze candidate'); ck(fr['det16_guard']=='RETAINED','det16 retained')
est=verify_self('V04_TO_V05_RELEASE_ESTIMATE_CONT12.json'); ck(est['estimate']['additional_passes_after_continuation_12']['range']==[1,3],'estimate range'); ck(est['estimate']['additional_passes_after_continuation_12']['most_likely']==2,'estimate central')
trep=verify_self('V04_SELLING_TOOLKIT_046_TEST_REPORT.json'); ck(trep['pytest']=='17/17 PASS','toolkit report'); ck(trep['installed_version']=='0.4.6','toolkit installed version'); ck(sha(ROOT/trep['wheel'])==trep['wheel_sha256'],'wheel hash'); ck(sha(ROOT/trep['source_zip'])==trep['source_zip_sha256'],'source zip hash')
r7=verify_self('V04_R7_SOURCE_RHO_MARKED_SCREEN_EXTENDED.json'); ck(r7['unrecycled_candidate_count']==0,'R7 zero unrecycled'); ck(r7['status']=='PASS-SCREEN/NO-UNRECYCLED-R7-CANDIDATE','R7 status'); ck(r7['HTNT']['Qa_infinitude']=='NT','Qa NT')
# retained H1 no-gos
hlin=verify_self('V04_SELLING_3D5D_DET_SWAP_H1_ZERO_NO_GO.json')['certificate']; ck(hlin['H1_dimension']==0,'linear H1 retained')
haff=verify_self('V04_GOLDEN_RESIDUAL_AFFINE_H1_ZERO_NO_GO.json')['certificate']; ck(haff['H1_dimension']==0,'affine H1 retained')
# dynamic replays in clean temp dirs
with tempfile.TemporaryDirectory() as td:
 td=Path(td); old=td/'old'; new=td/'new'; old.mkdir(); new.mkdir()
 with zipfile.ZipFile(ROOT/'selling_toolkit_v04_5_source.zip') as z:z.extractall(old)
 with zipfile.ZipFile(ROOT/'selling_toolkit_v04_6_source.zip') as z:z.extractall(new)
 code="import inspect,json,selling_toolkit;print(json.dumps({'all':selling_toolkit.__all__,'sig':{n:str(inspect.signature(getattr(selling_toolkit,n))) for n in selling_toolkit.__all__ if callable(getattr(selling_toolkit,n))}},sort_keys=True))"
 def snap(path):
  env=dict(os.environ);env['PYTHONPATH']=str(path);p=subprocess.run([sys.executable,'-c',code],capture_output=True,text=True,env=env);ck(p.returncode==0,'snapshot subprocess');return json.loads(p.stdout)
 so,sn=snap(old),snap(new); ck(all(n in sn['all'] for n in so['all']),'dynamic exports preserved'); ck(all(sn['sig'].get(n)==v for n,v in so['sig'].items()),'dynamic signatures preserved')
 # Use candidate source in this process
 sys.path.insert(0,str(new))
 import selling_toolkit
 ck(selling_toolkit.__version__=='0.4.6','source version')
 from selling_toolkit.layers import classify_exact,tarjan_scc
 from selling_toolkit.fast_layers import quotient_layer_fast,FastHitRange
 from selling_toolkit.cohomology import DeterminantSwapH1NoGo,GoldenResidualAffineH1NoGo
 from selling_toolkit.fibre_representations import BaseModuleRank2FibreNoGo
 seed=load('toolchain/synthetic_invariant_Qa.seed.json')
 q42=load('V04_DEPTH42_2451_2523_QUOTIENT_TOOLKIT.json'); q33=load('V04_DEPTH33_2524_2908_QUOTIENT_SCC_TOOLKIT.json'); idx33=load('V04_REPRESENTATIVE_INDEX_AFTER_D33.json')['representatives']
 # selected exact classifications incl. all d34 multiwalls
 ids={2909,2944,2979}; rr=classify_exact([n for n in q42['new_depth43_nodes'] if n['id'] in ids],seed,workers=3); sm={r['id']:r for r in rows43}
 for r in rr: ck(r['ordinary_walls']==sm[r['id']]['ordinary_walls'],f'reclass d43 {r["id"]}'); ck(r.get('multiwall_components',[])==sm[r['id']].get('multiwall_components',[]),f'reclass d43 multi {r["id"]}')
 ids={2980,3214,3390,3396,3447}; rr=classify_exact([n for n in q33['new_depth34_nodes'] if n['id'] in ids],seed,workers=4); sm={r['id']:r for r in rows34}
 for r in rr: ck(r['ordinary_walls']==sm[r['id']]['ordinary_walls'],f'reclass d34 {r["id"]}'); ck(r.get('multiwall_components',[])==sm[r['id']].get('multiwall_components',[]),f'reclass d34 multi {r["id"]}')
 # q43 replay
 ranges=[FastHitRange('d42',2451,2523),FastHitRange('d33',2524,2908),FastHitRange('d43',2909,2979),FastHitRange('d34',2980,3447)]
 qr=quotient_layer_fast(seed=seed,global_representatives=idx33,nodes=q42['new_depth43_nodes'],classifications=rows43,target_depth=44,kind='DEPTH44',layer_label='d44',hit_ranges=ranges); ck(qr['events']==q43['events'],'q43 replay events'); ck(qr['new_nodes']==q43['new_depth44_nodes'],'q43 replay new')
 # q34 replay
 source_scc={i:c['scc'] for c in q33['enlarged_d23_to_d33_scc']['components'] for i in c['ids']}
 ranges2=[FastHitRange('d31',1821,2082),FastHitRange('d41',2083,2130),FastHitRange('d32',2131,2450),FastHitRange('d42',2451,2523),FastHitRange('d33',2524,2908),FastHitRange('d43',2909,2979),FastHitRange('d34',2980,3447),FastHitRange('d44',3448,3537)]
 qr2=quotient_layer_fast(seed=seed,global_representatives=idx43['representatives'],nodes=q33['new_depth34_nodes'],classifications=rows34,target_depth=35,kind='DEPTH35',layer_label='d35',hit_ranges=ranges2,source_scc=source_scc); ck(qr2['events']==q34['events'],'q34 replay events'); ck(qr2['new_nodes']==q34['new_depth35_nodes'],'q34 replay new')
 ck(DeterminantSwapH1NoGo.certificate()['H1_dimension']==0,'dynamic linear H1'); ck(GoldenResidualAffineH1NoGo.certificate()['H1_dimension']==0,'dynamic affine H1'); nc=BaseModuleRank2FibreNoGo.certificate(); ck(nc['generated_algebra_dimension']==9 and nc['commutant_dimension']==1,'dynamic rank2 no-go')
 env=dict(os.environ);env['PYTHONPATH']=str(new);pr=subprocess.run([sys.executable,'-m','pytest','-q',str(new/'tests'/'test_toolkit.py')],capture_output=True,text=True,env=env); ck(pr.returncode==0 and '17 passed' in pr.stdout,'dynamic pytest')
 target=td/'wheel';target.mkdir(); pi=subprocess.run([sys.executable,'-m','pip','install','--no-deps','--target',str(target),str(ROOT/'selling_toolkit-0.4.6-py3-none-any.whl')],capture_output=True,text=True);ck(pi.returncode==0,'wheel install');pv=subprocess.run([sys.executable,'-c',f"import sys;sys.path.insert(0,{str(target)!r});import selling_toolkit;print(selling_toolkit.__version__)"],capture_output=True,text=True);ck(pv.returncode==0 and pv.stdout.strip()=='0.4.6','wheel version')
print(json.dumps({'status':'PASS','checks':N,'version':'v0.4-continuation-12'},indent=2))
