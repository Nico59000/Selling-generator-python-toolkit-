import json,hashlib,zipfile,tempfile,sys,os,subprocess
from pathlib import Path
R=Path(__file__).resolve().parent
checks=0
def ok(c,msg):
 global checks
 assert c,msg; checks+=1
def J(n):return json.load(open(R/n))
def selfok(n):
 d=J(n); s=d.pop('sha256_without_self'); h=hashlib.sha256(json.dumps(d,sort_keys=True,separators=(',',':')).encode()).hexdigest(); ok(s==h,n+' selfhash')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

self_files=[
 'V04_SAFE_FRONTIER_CONTINUATION_9_CHECKPOINT.json',
 'V04_DEPTH40_1772_1820_CLASSIFICATION.json','V04_DEPTH40_1772_1820_QUOTIENT_TOOLKIT.json','V04_REPRESENTATIVE_INDEX_AFTER_D40.json',
 'V04_DEPTH31_1821_2082_CLASSIFICATION_SCC.json','V04_DEPTH31_1821_2082_QUOTIENT_SCC_TOOLKIT.json','V04_REPRESENTATIVE_INDEX_AFTER_D31.json',
 'V04_RATIONAL_ISOTROPIC_UNBOUNDED_CONSTRUCTIVE_WITNESS.json','V04_GOLDEN_RESIDUAL_DET_SWAP_ADAPTER.json','V04_SELLING_3D5D_NONZERO_C_COBOUNDARY_LIFT.json','V04_SELLING_TOOLKIT_043_TEST_REPORT.json',
 'V04_REPRESENTATIVE_INDEX_AFTER_D30.json','V04_DEPTH39_1505_1541_QUOTIENT_TOOLKIT.json','V04_DEPTH30_1542_1771_QUOTIENT_SCC_TOOLKIT.json']
for n in self_files:selfok(n)
# predecessor lock
cp=J('V04_SAFE_FRONTIER_CONTINUATION_9_CHECKPOINT.json');ok(cp['predecessor']['sha256']==sha(R/'V04_SAFE_FRONTIER_CONTINUATION_8_CHECKPOINT.json'),'predecessor checkpoint hash');ok(cp['status']=='RESEARCH-CHECKPOINT / APPEND-ONLY-CONTINUATION','checkpoint status')
# d40 classification and quotient
c40=J('V04_DEPTH40_1772_1820_CLASSIFICATION.json');q40=J('V04_DEPTH40_1772_1820_QUOTIENT_TOOLKIT.json');i40=J('V04_REPRESENTATIVE_INDEX_AFTER_D40.json')
ok(c40['status']=='PASS-49/49-EXACT','d40 class status');ok([r['id'] for r in c40['results']]==list(range(1772,1821)),'d40 ids')
for r in c40['results']:ok(not r['multiwall_components'],'d40 no multiwall')
ok(q40['counts']=={'classes':49,'ordinary_exits':184,'hits':136,'new':48,'multiwall_cells':0},'d40 counts');ok(q40['hit_buckets']=={'d40':59,'d39':56,'same-pass':21},'d40 buckets');ok([n['id'] for n in q40['new_depth41_nodes']]==list(range(2083,2131)),'d41 ids');ok(len(q40['events'])==184,'d40 event count')
for e in q40['events']:ok(e['status'] in {'HIT','NEW'} and isinstance(e['target'],int),'d40 typed event')
ok(i40['representative_count']==2131 and [r['id'] for r in i40['representatives']]==list(range(2131)),'index d40')
# d40 chunk coverage
ids=[]
for p in sorted((R/'d40_chunks').glob('chunk_*.json')):
 d=json.load(open(p));ok(d['status']=='NONPUBLISHABLE-CHUNK','d40 chunk status'); ids.extend(r['id'] for r in d['results'])
ok(sorted(ids)==list(range(1772,1821)) and len(ids)==49,'d40 chunk cover')
# d31 classification and quotient
c31=J('V04_DEPTH31_1821_2082_CLASSIFICATION_SCC.json');q31=J('V04_DEPTH31_1821_2082_QUOTIENT_SCC_TOOLKIT.json');i31=J('V04_REPRESENTATIVE_INDEX_AFTER_D31.json')
ok(c31['status']=='PASS-262/262-EXACT-SCC-BY-SCC','d31 class status');ok([r['id'] for r in c31['results']]==list(range(1821,2083)),'d31 ids');ok([r['id'] for r in c31['results'] if r['multiwall_components']]==[1940,2070,2074],'d31 multi ids')
for r in c31['results']:ok(r['enlarged_source_scc'] in {0,1},'d31 source scc')
ok(q31['counts']=={'classes':262,'ordinary_exits':964,'hits':644,'new':320,'multiwall_cells':3},'d31 counts');ok(q31['hit_buckets']=={'d30':312,'same-pass':74,'d31':257,'d41':1},'d31 buckets');ok([n['id'] for n in q31['new_depth32_nodes']]==list(range(2131,2451)),'d32 ids');ok(len(q31['events'])==964,'d31 event count')
for e in q31['events']:ok(e['status'] in {'HIT','NEW'} and e['enlarged_source_scc'] in {0,1},'d31 typed event')
ok(q31['source_scc_counts']=={'0':{'exits':942,'hits':626,'new':316},'1':{'exits':22,'hits':18,'new':4}},'d31 source counts')
ok(q31['d31_internal_scc']['count']==134,'d31 internal scc count');ok(q31['enlarged_d23_d24_d25_d26_d27_d28_d29_d30_d31_scc']['sizes']==[1285,36,2,1,1,1,1],'combined scc sizes');ok(q31['enlarged_d23_d24_d25_d26_d27_d28_d29_d30_d31_scc']['vertex_count']==1327,'combined vertices');ok(i31['representative_count']==2451 and [r['id'] for r in i31['representatives']]==list(range(2451)),'index d31')
# one d31->d41 collision must remain a hit
hits41=[e for e in q31['events'] if e['status']=='HIT' and 2083<=int(e['target'])<=2130];ok(len(hits41)==1,'exactly one d31 to d41 hit')
# d31 chunk cover
ids=[]
for p in sorted((R/'d31_chunks').glob('scc*.json')):
 d=json.load(open(p));ok(d['status']=='NONPUBLISHABLE-CHUNK','d31 chunk status');ids.extend(r['id'] for r in d['results'])
ok(sorted(ids)==list(range(1821,2083)) and len(ids)==262,'d31 chunk cover')
# source file lock and explicit historical golden residual formula
src=R/'source_context/binet_birefringent_fibonacci_ladder_completion_addendum.tex';txt=src.read_text()
ok(sha(src)==cp['extension_3D5D']['historical_source_sha256'],'golden source sha');ok('\\nu_\\varphi-\\mu_\\varphi=1' in txt,'golden nu-mu source');ok('\\Gamma_\\varphi(r)' in txt and '\\Delta(\\Gamma_\\varphi(r))=r' in txt,'golden gamma/delta source')
# toolkit source tests and exact fast quotient replays
with tempfile.TemporaryDirectory() as td:
 with zipfile.ZipFile(R/'selling_toolkit_v04_3_source.zip') as z:z.extractall(td)
 env=dict(os.environ);env['PYTHONPATH']=td
 rr=subprocess.run([sys.executable,'-m','pytest','-q',str(Path(td)/'tests')],capture_output=True,text=True,env=env);ok(rr.returncode==0 and '14 passed' in rr.stdout,'pytest 14/14')
 sys.path.insert(0,td)
 from selling_toolkit.fast_layers import quotient_layer_fast,FastHitRange
 from selling_toolkit.extension import GoldenResidualFibreAdapter,CoboundaryCoupledSellingLift3D5D,TrivialSellingLift3D5D
 from selling_toolkit.rational_forms import find_isotropic_vector_exact,explicit_isotropic_ternary_congruence_exact
 import sympy as sp
 seed=J('toolchain/synthetic_invariant_Qa.seed.json')
 idx30=J('V04_REPRESENTATIVE_INDEX_AFTER_D30.json'); prev39=J('V04_DEPTH39_1505_1541_QUOTIENT_TOOLKIT.json')
 ranges40=[FastHitRange('older<=d28',0,1323),FastHitRange('d29',1324,1504),FastHitRange('d39',1505,1541),FastHitRange('d30',1542,1771),FastHitRange('d40',1772,1820),FastHitRange('d31',1821,2082)]
 rr40=quotient_layer_fast(seed=seed,global_representatives=idx30['representatives'],nodes=prev39['new_depth40_nodes'],classifications=c40['results'],target_depth=41,kind='DEPTH41',layer_label='d41',hit_ranges=ranges40)
 ok(rr40['events']==q40['events'],'q40 replay events');ok(rr40['new_nodes']==q40['new_depth41_nodes'],'q40 replay new');ok(rr40['multiwalls']==q40['multiwalls'],'q40 replay multi')
 prev30=J('V04_DEPTH30_1542_1771_QUOTIENT_SCC_TOOLKIT.json'); srcs={int(i):int(c['scc']) for c in prev30['enlarged_d23_d24_d25_d26_d27_d28_d29_d30_scc']['components'] for i in c['ids']}
 ranges31=[FastHitRange('older<=d28',0,1323),FastHitRange('d29',1324,1504),FastHitRange('d39',1505,1541),FastHitRange('d30',1542,1771),FastHitRange('d40',1772,1820),FastHitRange('d31',1821,2082),FastHitRange('d41',2083,2130)]
 rr31=quotient_layer_fast(seed=seed,global_representatives=i40['representatives'],nodes=prev30['new_depth31_nodes'],classifications=c31['results'],target_depth=32,kind='DEPTH32',layer_label='d32',hit_ranges=ranges31,source_scc=srcs)
 ok(rr31['events']==q31['events'],'q31 replay events');ok(rr31['new_nodes']==q31['new_depth32_nodes'],'q31 replay new');ok(rr31['multiwalls']==q31['multiwalls'],'q31 replay multi')
 # structural direct replay
 m=sp.symbols('m',positive=True);ok(all(GoldenResidualFibreAdapter.identities(m).values()),'golden adapter direct')
 walls=list(TrivialSellingLift3D5D.wall_base_matrices().values());L=CoboundaryCoupledSellingLift3D5D();ok(any(L.C(A)!=sp.zeros(2,3) for A in walls),'nonzero C exists');
 for A in walls:ok(L.conjugacy_identity(A),'C conjugacy')
 for A in walls:
  for B in walls:ok(L.homomorphism_identity(A,B),'C homomorphism')
 Q0=sp.Matrix([[0,sp.Rational(1,2),0],[sp.Rational(1,2),0,0],[0,0,sp.Rational(-1,4)]])
 A=sp.Matrix([[7,3,1],[2,5,1],[1,0,3]]);Q1=sp.simplify(A.T*Q0*A);iso=find_isotropic_vector_exact(Q1);ok(iso is not None and sp.simplify((iso.T*Q1*iso)[0])==0,'unbounded exact isotropic witness');ex=explicit_isotropic_ternary_congruence_exact(Q0,Q1);ok(ex['witness'] is not None and ex['bounded_search_used'] is False,'unbounded exact congruence witness')
# wheel clean install smoke
with tempfile.TemporaryDirectory() as td:
 wheel=R/'selling_toolkit-0.4.3-py3-none-any.whl';rr=subprocess.run([sys.executable,'-m','pip','install','--no-deps','--target',td,str(wheel)],capture_output=True,text=True);ok(rr.returncode==0,'wheel install')
 code="import selling_toolkit as s; assert s.__version__=='0.4.3'; from selling_toolkit.extension import GoldenResidualFibreAdapter,CoboundaryCoupledSellingLift3D5D; from selling_toolkit.rational_forms import find_isotropic_vector_exact; print(GoldenResidualFibreAdapter.status); print(CoboundaryCoupledSellingLift3D5D.status)"
 ss=subprocess.run([sys.executable,'-c',code],capture_output=True,text=True,env={**os.environ,'PYTHONPATH':td});ok(ss.returncode==0 and 'GOLDEN-RESIDUAL' in ss.stdout and 'NONZERO-C' in ss.stdout,'wheel smoke')
# certificates
rc=J('V04_RATIONAL_ISOTROPIC_UNBOUNDED_CONSTRUCTIVE_WITNESS.json');ok('UNBOUNDED-CONSTRUCTIVE' in rc['status'],'rational cert status');ok(all(x['bounded_search_used'] is False and x['witness_check'] for x in rc['cases']),'rational cases exact');ok(rc['fixed_scale_quartic_case']['bounded_search_used'] is False and rc['fixed_scale_quartic_case']['rho_replay_exact'] is True,'quartic exact constructive replay')
g=J('V04_GOLDEN_RESIDUAL_DET_SWAP_ADAPTER.json');ok(g['status']=='PROVEN-EXACT-GOLDEN-RESIDUAL-FIBRE-INTERTWINER','golden cert status');ok(all(g['identities'].values()),'golden identities');ok(g['all_walls_orientation_reversing'] is True,'golden all wall swaps')
c=J('V04_SELLING_3D5D_NONZERO_C_COBOUNDARY_LIFT.json');ok('GAUGE-TRIVIAL' in c['status'],'C cert guard');ok(c['nonzero_C_wall_count']==6 and c['wall_conjugacy_checks']=='6/6' and c['pair_homomorphism_checks']=='36/36','C cert checks')
r7=J('V04_R7_SOURCE_RHO_MARKED_SCREEN_EXTENDED.json');ok('NO-UNRECYCLED' in r7['status'],'R7 retained')
report={'status':'PASS','checks':checks,'checks_passed':checks,'version':'v0.4-continuation-9'}
print(json.dumps(report,indent=2))
