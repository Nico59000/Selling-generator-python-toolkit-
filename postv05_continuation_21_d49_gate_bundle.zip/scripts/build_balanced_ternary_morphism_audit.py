import sys,json,hashlib
from pathlib import Path
sys.path.insert(0,'/mnt/data/post_v05/rel/src')
import sympy as sp
from selling_seed2d.algebra import RELABEL,homogeneous,gram_from_six
ROOT=Path('/mnt/data/post_v05'); OUT=ROOT/'d49_gate'; OUT.mkdir(exist_ok=True)
G,H,K,L,M,N=sp.symbols('g h k l m n'); syms={'g':G,'h':H,'k':K,'l':L,'m':M,'n':N}
a=-L-H-K;b=-M-G-K;c=-N-G-H;X=gram_from_six(a,b,c,G,H,K)
pairs=[frozenset(('g','l')),frozenset(('h','m')),frozenset(('k','n'))]; pnames={pairs[0]:'GL',pairs[1]:'HM',pairs[2]:'KN'}
rows=[]; induced=set()
for i,A in enumerate(RELABEL):
 h=homogeneous(A.T*X*A); perm={}
 for outlab,e in h.items():
  found=[lab for lab,s in syms.items() if sp.expand(e-s)==0]
  if len(found)!=1: raise RuntimeError((i,outlab,e,found))
  perm[outlab]=found[0]
 pp=[]
 for p in pairs:
  q=frozenset(perm[x] for x in p)
  if q not in pnames:raise RuntimeError(('partition failure',i,p,q))
  pp.append(pnames[q])
 induced.add(tuple(pp)); rows.append({'relabel_index':i,'wall_pullback':perm,'opposite_pair_pullback':pp})
assert len(rows)==24 and len(induced)==6
bal=json.load(open(OUT/'POSTV05_D49_BALANCED_WORD_DIAGNOSTIC.json'))['summary']
obj={
 'version':'post-v0.5-continuation-21',
 'phase':'Balanced Sequences -> Selling opposite-pair -> T5/T7/T9 typed morphism audit',
 'status':'PARTIAL-PROVEN-EQUIVARIANT-PROJECTION / GLOBAL-MORPHISM-PENDING',
 'source_documents':{
  'balanced_sequences':'Altman-Gaujal-Hordijk, Balanced Sequences and Optimal Routing, INRIA RR-3180 (1997)',
  'ternary_gauges':'ternary_algebra_5_7_9_interoperability_addendum_htnt_cited.pdf',
  'cuboctahedral':'cuboctahedral_tetrad_cfs_efs_formal_demo_addendum_ternary_computable_extended.tex',
  'pascal_noether':'v54_GATE6_PASCAL_NOETHER_TYPED_BRIDGE.json'
 },
 'proven_source_projection':{
  'map':'pi_opp: {g,l}->GL, {h,m}->HM, {k,n}->KN',
  'status':'PROVEN-S4-TO-S3-EQUIVARIANT-ALPHABET-PROJECTION',
  'relabels_checked':'24/24',
  'distinct_induced_S3_permutations':'6/6',
  'interpretation':'opposite-edge perfect-matching quotient of tetrahedral wall alphabet',
  'certificate':rows
 },
 'balanced_word_layer':{
  'letter_permutation_invariance':'PROVEN-DEFINITIONAL',
  'd49_raw6_periodic_balanced':bal['raw6']['periodic_closure_balanced'],
  'd49_projected3_periodic_balanced':bal['opposite_pair_projection3']['periodic_closure_balanced'],
  'd49_projected3_Tijdeman_rate_eligible':bal['opposite_pair_projection3']['Tijdeman_rate_eligible'],
  'guard':'rate eligibility does not imply the concrete Selling path word is balanced'
 },
 'candidate_diagram':{
  'formula':'Selling path word --pi_opp--> 3-letter word --regular/discrepancy observable--> centered scalar/vector --M_N--> T_N --sigma_N--> T0, N in {5,7,9}',
  'T5_T7_T9_to_T0':'SOURCE-PROVEN in ternary gauge addendum via ternary-algebra homomorphisms / observable families',
  'T7_T9_centered_antipody':'TARGET-PROVEN: J(s,t)=(6-s,8-t) sends nu_79 to -nu_79 and models residual antipody',
  'source_to_target_antivariance':'NT: no source involution has yet been shown to map through the discrepancy observable to the target antipody',
  'quotient_descent':'REFUTED-FOR-RAW-PATH-STATISTICS / PENDING-FOR-A-NEW-QUOTIENT-COMPATIBLE-OBSERVABLE',
  'reason':'continuation 20 produced explicit exact HIT counterexamples showing path length/rates/balance defects are not canonical-matrix quotient invariants',
  'scale_phase_calibration':'NT: no canonical phase/theta and no source-derived half-step scaling from balanced-word discrepancy to T5/T7/T9 margin levels has been frozen'
 },
 'cuboctahedral_dyadic_alignment':{
  'status':'COMPATIBLE-INCIDENCE-SHAPE / PENDING-EXPLICIT-CARRIER-MAP',
  'facts':['Selling wall alphabet is the six tetrahedral edges','pi_opp collapses them to the three opposite-edge perfect matchings','cuboctahedral formal corpus has centered T7/T9 no-bias gauge and residual antipody','no explicit representative map from Selling canonical classes to cuboctahedral sector pairs (s,t) is yet certified']
 },
 'selling_noether_pascal_alignment':{
  'status':'SEPARATED/PENDING-MORPHISM',
  'proven_available':['Pascal-Noether polynomial relation bridge/covariance lane is proven at its declared polynomial carrier','Selling wall relabelling pi_opp is S4->S3 equivariant'],
  'missing':['typed map from Selling conorm/wall/canonical-matrix carrier into Pascal-Noether coefficient/covariant carrier','proof that GL3 covariance intertwines the S4->S3 balanced-word projection','variance sign rule identifying covariance versus contravariance/anti-variance on the ternary discrepancy observable'],
  'guard':'coincidence of symmetry groups or counts is not a morphism'
 },
 'recommended_next_exact_tests':[
  'construct a quotient-compatible 3-channel observable from canonical conorm/matrix data, not path_from_C2 spelling, whose channel permutation is the induced S3 action',
  'test whether the observable admits a centered C2 sign involution compatible with the T7/T9 residual antipody',
  'calibrate monotone maps M5,M7,M9 only from source-native thresholds/invariants; require sigma_N o M_N to commute with the quotient/relabel action',
  'only then test a GL3-intertwining square to the proven Pascal-Noether polynomial carrier',
  'retain T5/T7/T9 as chain-gauge carriers; do not identify their cardinalities with routing alphabet size or with v55 five factor/order families'
 ]
}
raw=json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode();obj['sha256_without_self']=hashlib.sha256(raw).hexdigest()
json.dump(obj,open(OUT/'POSTV05_BALANCED_TERNARY_MORPHISM_AUDIT.json','w'),indent=2,sort_keys=True,ensure_ascii=False)
print(json.dumps({k:obj[k] for k in ['status','proven_source_projection','balanced_word_layer','candidate_diagram','selling_noether_pascal_alignment']},indent=2,ensure_ascii=False))
