import json, os, hashlib
from collections import Counter
ROOT='/mnt/data/post_v05'; OUT=ROOT+'/d49_gate'; os.makedirs(OUT,exist_ok=True)
idx=json.load(open(ROOT+'/d39_gate/POSTV05_REPRESENTATIVE_INDEX_AFTER_D39.json'))
reps=idx['representatives']; nodes=reps[8222:8454]
A6=('g','h','k','l','m','n')
pairmap={'g':'GL','l':'GL','h':'HM','m':'HM','k':'KN','n':'KN'}
A3=('GL','HM','KN')
def linear_defect(seq,alphabet):
 n=len(seq); best=0
 for L in range(1,n+1):
  for a in alphabet:
   pref=[0]
   for x in seq:pref.append(pref[-1]+(x==a))
   vals=[pref[i+L]-pref[i] for i in range(n-L+1)];best=max(best,max(vals)-min(vals))
 return best
def cyclic_defect(seq,alphabet):
 n=len(seq); best=0
 if n<=1:return 0
 ext=seq+seq
 for L in range(1,n):
  for a in alphabet:
   pref=[0]
   for x in ext:pref.append(pref[-1]+(x==a))
   vals=[pref[i+L]-pref[i] for i in range(n)];best=max(best,max(vals)-min(vals))
 return best
def constant_gap(seq,alphabet):
 n=len(seq)
 for a in alphabet:
  pos=[i for i,x in enumerate(seq) if x==a]
  if not pos:continue
  gaps=[(pos[(j+1)%len(pos)]-pos[j])%n for j in range(len(pos))]
  if len(pos)==1:gaps=[n]
  if len(set(gaps))!=1:return False
 return True
def tijdeman3_counts(counts):
 vals=sorted(counts.values(),reverse=True)
 if len(set(vals))<3:return True,'two-rates-equal'
 if vals[0]==4*vals[2] and vals[1]==2*vals[2]:return True,'4:2:1'
 return False,None
rows=[]
for n in nodes:
 w=list(n['path_from_C2']); w3=[pairmap[x] for x in w]; c6=Counter(w);c3=Counter(w3);N=len(w)
 ld6=linear_defect(w,A6);cd6=cyclic_defect(w,A6);ld3=linear_defect(w3,A3);cd3=cyclic_defect(w3,A3);elig,why=tijdeman3_counts({a:c3[a] for a in A3})
 rows.append({'id':n['id'],'length':N,'counts6':{a:c6[a] for a in A6},'finite_factor_defect6':ld6,'periodic_closure_defect6':cd6,'periodic_closure_balanced6':cd6<=1,'periodic_closure_constant_gap6':constant_gap(w,A6),'counts3':{a:c3[a] for a in A3},'finite_factor_defect3':ld3,'periodic_closure_defect3':cd3,'periodic_closure_balanced3':cd3<=1,'periodic_closure_constant_gap3':constant_gap(w3,A3),'tijdeman_rate_eligible3':elig,'tijdeman_reason3':why})
def dist(key):return dict(sorted(Counter(r[key] for r in rows).items(),key=lambda kv:str(kv[0])))
summary={'version':'post-v0.5-continuation-21','phase':'balanced-word diagnostic on d49 path_from_C2','status':'PASS-DIAGNOSTIC-SEPARATED','scope':{'ids':[8222,8453],'count':len(rows),'lengths':dict(Counter(r['length'] for r in rows))},'raw6':{'periodic_closure_balanced':sum(r['periodic_closure_balanced6'] for r in rows),'constant_gap':sum(r['periodic_closure_constant_gap6'] for r in rows),'periodic_defect_distribution':dist('periodic_closure_defect6')},'opposite_pair_projection3':{'periodic_closure_balanced':sum(r['periodic_closure_balanced3'] for r in rows),'constant_gap':sum(r['periodic_closure_constant_gap3'] for r in rows),'Tijdeman_rate_eligible':sum(r['tijdeman_rate_eligible3'] for r in rows),'Tijdeman_reasons':dict(Counter(r['tijdeman_reason3'] for r in rows if r['tijdeman_rate_eligible3'])),'periodic_defect_distribution':dist('periodic_closure_defect3')},'guard':'finite path spelling diagnostic; not quotient invariant and not a routing morphism'}
obj={'summary':summary,'rows':rows};raw=json.dumps(obj,sort_keys=True,separators=(',',':')).encode();obj['sha256_without_self']=hashlib.sha256(raw).hexdigest();json.dump(obj,open(OUT+'/POSTV05_D49_BALANCED_WORD_DIAGNOSTIC.json','w'),indent=2,sort_keys=True)
print(json.dumps(summary,indent=2,sort_keys=True))
