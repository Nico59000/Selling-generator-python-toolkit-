import json, sys, hashlib, time
from pathlib import Path
sys.path.insert(0,'/mnt/data/post_v05/cont25_work/toolkit_src')
from selling_seed2d.algebra import S,FIRST_MOVE,RELABEL,build_finite_group
from selling_seed2d.seed import seed_matrices
BASE=Path('/mnt/data/post_v05/cont25_work'); OUT=Path('/mnt/data/post_v05/d51_gate')
idx=json.load(open(BASE/'d41_bundle/POSTV05_REPRESENTATIVE_INDEX_AFTER_D41.json'))['representatives']
seed=json.load(open(BASE/'d41_bundle/inputs/synthetic_invariant_Qa.seed.json'))
cls=json.load(open(OUT/'POSTV05_DEPTH51_11755_12089_CLASSIFICATION.json'))['classifications']
q=json.load(open(OUT/'POSTV05_DEPTH51_11755_12089_QUOTIENT_TOOLKIT.json'))
_Q,_A,Qc,deck_named=seed_matrices(seed)
deck=[tuple(tuple(int(x) for x in row) for row in D.tolist()) for D in build_finite_group([g for _,g in deck_named],32)]
rels=[tuple(tuple(int(x) for x in row) for row in R.tolist()) for R in RELABEL]
Sm={w:tuple(tuple(int(x) for x in row) for row in S[FIRST_MOVE[w]-1].tolist()) for w in FIRST_MOVE}
Qc=tuple(tuple(int(x) for x in row) for row in Qc.tolist())

def mm(A,B):
 return tuple(tuple(sum(A[i][k]*B[k][j] for k in range(3)) for j in range(3)) for i in range(3))
def tr(A): return tuple(tuple(A[j][i] for j in range(3)) for i in range(3))
def flat(A): return tuple(x for row in A for x in row)
def negkey(k): return tuple(-x for x in k)
def canon(A):
 best=None
 for D in deck:
  DA=mm(D,A)
  for R in rels:
   k=flat(mm(DA,R)); nk=negkey(k)
   z=k if k<nk else nk
   if best is None or z<best: best=z
 return best

def j2_u(A):
 M=mm(mm(tr(A),Qc),A)
 c=(sum(M[0]),sum(M[1]),sum(M[2]),-M[0][1],-M[0][2],-M[1][2])
 j2=sum(x*x for x in c)
 U=tuple(sorted((c[0]+c[5],c[1]+c[4],c[2]+c[3])))
 return j2,c,U

def asmat(rows): return tuple(tuple(int(x) for x in row) for row in rows)

t0=time.time(); failures=[]
# canonical first-ID map for known index
cmap={}
for i,r in enumerate(idx):
 k=canon(asmat(r['A'])); cmap.setdefault(k,i)
 if (i+1)%2000==0: print('INDEX',i+1, 'elapsed', round(time.time()-t0,1), flush=True)
# sequential event replay
nmap={int(x['id']):x for x in idx[11755:12090]}
clmap={int(x['id']):x for x in cls}
new_by_target={int(x['id']):x for x in q['new_depth52_nodes']}
computed=[]; nextid=len(idx); u_fail=[]
for sid in range(11755,12090):
 A=asmat(nmap[sid]['A'])
 for wall in clmap[sid]['ordinary_walls']:
  An=mm(A,Sm[wall]); key=canon(An); j2,c,u=j2_u(An)
  target=cmap.get(key)
  if target is None:
   target=nextid; nextid+=1; cmap[key]=target
   nr=new_by_target.get(target)
   if nr is None or asmat(nr['A'])!=An: failures.append(['new-node',sid,wall,target])
   status='NEW'
  else: status='HIT'
  computed.append((sid,wall,status,target,str(j2)))
# compare exact event sequence
obs=[(int(e['source']),e['wall'],e['status'],int(e['target']),e['J2']) for e in q['events']]
if computed!=obs:
 failures.append(['event-sequence-mismatch', len(computed), len(obs)])
 # pinpoint first
 for a,b in zip(computed,obs):
  if a!=b: failures.append(['first-event-mismatch',a,b]); break
# U invariant across hits against target representative M/conorm
allreps=q['new_depth52_nodes']
rep_lookup={int(r['id']):r for r in idx}
rep_lookup.update({int(r['id']):r for r in allreps})
for e in q['events']:
 if e['status']!='HIT': continue
 s=nmap[int(e['source'])]; An=mm(asmat(s['A']),Sm[e['wall']]); _,_,u1=j2_u(An)
 t=rep_lookup[int(e['target'])]; _,_,u2=j2_u(asmat(t['A']))
 if u1!=u2: u_fail.append([e['source'],e['wall'],e['target'],u1,u2])
report={
 'version':'post-v0.5-continuation-25','status':'PASS' if not failures and not u_fail else 'FAIL',
 'classes':335,'ordinary_exits':len(computed),'hits':sum(x[2]=='HIT' for x in computed),'new':sum(x[2]=='NEW' for x in computed),
 'index_before_last':len(idx)-1,'index_after_last':nextid-1,'canonical_known_classes':len({canon(asmat(r['A'])) for r in idx}),
 'deck_size':len(deck),'relabel_size':len(rels),'variant_group_size_with_sign':len(deck)*len(rels)*2,
 'event_sequence_exact':computed==obs,'u_hits_checked':sum(e['status']=='HIT' for e in q['events']), 'u_failures':u_fail,
 'failures':failures,'elapsed_seconds':time.time()-t0,
 'method':'pure-Python arbitrary-precision integer 3x3 products; per-matrix orbit canonical minimum under deck x relabel x projective sign; no FastCanonicalIndex'
}
raw=json.dumps(report,sort_keys=True,separators=(',',':')).encode(); report['sha256_without_self']=hashlib.sha256(raw).hexdigest()
(OUT/'POSTV05_DEPTH51_INDEPENDENT_VERIFICATION_REPORT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps(report,indent=2), flush=True)
