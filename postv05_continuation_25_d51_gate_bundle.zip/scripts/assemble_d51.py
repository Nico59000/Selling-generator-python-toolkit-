import json, sys, time, hashlib
from pathlib import Path
sys.path.insert(0,'/mnt/data/post_v05/cont25_work/toolkit_src')
from selling_toolkit.fast_layers import quotient_layer_fast, FastHitRange
BASE=Path('/mnt/data/post_v05/cont25_work')
OUT=Path('/mnt/data/post_v05/d51_gate')
idx=json.load(open(BASE/'d41_bundle/POSTV05_REPRESENTATIVE_INDEX_AFTER_D41.json'))
reps=idx['representatives']
nodes=[reps[i] for i in range(11755,12090)]
class_obj=json.load(open(OUT/'POSTV05_DEPTH51_11755_12089_CLASSIFICATION.json'))
classifications=class_obj['classifications']
seed=json.load(open(BASE/'d41_bundle/inputs/synthetic_invariant_Qa.seed.json'))
ranges=[
 FastHitRange('older_0_8221',0,8221),
 FastHitRange('d49',8222,8453),
 FastHitRange('d40',8454,9822),
 FastHitRange('d50',9823,10103),
 FastHitRange('d41',10104,11754),
 FastHitRange('d51',11755,12089),
 FastHitRange('d42-index-only',12090,14087),
]
t=time.time()
q=quotient_layer_fast(seed=seed,global_representatives=reps,nodes=nodes,classifications=classifications,target_depth=52,kind='DEPTH52',layer_label='d52-post-v05-cont25',hit_ranges=ranges)
elapsed=time.time()-t
obj={
 'version':'post-v0.5-continuation-25','phase':'d51-quotient','status':'PASS-335/335-EXACT-QUOTIENTED',
 'engine':'selling-toolkit-0.5.0 FastCanonicalIndex int64 guarded',
 'processing_order':'id','known_index_before':'0..14087','counts':q['counts'],'hit_buckets':q['hit_buckets'],
 'events':q['events'],'multiwalls':q['multiwalls'],'new_depth52_nodes':q['new_nodes'],
 'elapsed_seconds':elapsed,
 'guards':['complete post-d41 global index 0..14087 used','d42 12090..14087 treated as known index-only/HIT-only and not classified','new representatives inserted immediately for deterministic same-pass collapse','multiwall components retained/not expanded','d52 classification not opened','public toolkit API/CLI/schema unchanged']
}
raw=json.dumps(obj,sort_keys=True,separators=(',',':')).encode(); obj['sha256_without_self']=hashlib.sha256(raw).hexdigest()
(OUT/'POSTV05_DEPTH51_11755_12089_QUOTIENT_TOOLKIT.json').write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
idxout={'version':'post-v0.5-continuation-25','status':'INDEX-AFTER-D51','representatives':q['representatives_after']}
raw=json.dumps(idxout,sort_keys=True,separators=(',',':')).encode(); idxout['sha256_without_self']=hashlib.sha256(raw).hexdigest()
(OUT/'POSTV05_REPRESENTATIVE_INDEX_AFTER_D51.json').write_text(json.dumps(idxout,indent=2,sort_keys=True)+'\n')
print(json.dumps({'counts':q['counts'],'hit_buckets':q['hit_buckets'],'new_range':[q['new_nodes'][0]['id'],q['new_nodes'][-1]['id']] if q['new_nodes'] else None,'index_last':len(q['representatives_after'])-1,'elapsed':elapsed},indent=2))
