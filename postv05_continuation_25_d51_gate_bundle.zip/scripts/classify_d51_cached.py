import os, json, sys, time, hashlib
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
sys.path.insert(0, '/mnt/data/post_v05/cont25_work/toolkit_src')
import sympy as sp
from selling_seed2d.seed import seed_matrices
from selling_seed2d.chart import build_chart
from selling_seed2d.classifier import ExactBoundaryClassifier

BASE=Path('/mnt/data/post_v05/cont25_work')
INDEX=BASE/'d41_bundle/POSTV05_REPRESENTATIVE_INDEX_AFTER_D41.json'
SEED=BASE/'d41_bundle/inputs/synthetic_invariant_Qa.seed.json'
OUT=Path('/mnt/data/post_v05/d51_gate')
RES=OUT/'class_results'
OUT.mkdir(parents=True, exist_ok=True); RES.mkdir(parents=True, exist_ok=True)

_G=None

def imat(rows): return sp.Matrix([[sp.Integer(v) for v in row] for row in rows])

def init_worker(seed):
    global _G
    chart=build_chart(seed)
    _G=ExactBoundaryClassifier(chart.q, chart.r, chart.wall_vector, chart.D0)

def worker(node):
    c=_G.classify_cell(imat(node['L']))
    return {
        'id':int(node['id']),
        'ordinary_walls':list(c['ordinary_walls']),
        'multiwall_components':[{'factor':z['factor'],'walls':list(z['walls'])} for z in c.get('multiwall_components',[])],
        'polynomials':c.get('polynomials',{}),
    }

def main():
    idx=json.load(open(INDEX)); reps=idx['representatives']
    nodes=[reps[i] for i in range(11755,12090)]
    seed=json.load(open(SEED))
    done={int(p.stem) for p in RES.glob('*.json') if p.stem.isdigit()}
    todo=[n for n in nodes if int(n['id']) not in done]
    print(f'START total={len(nodes)} done={len(done)} todo={len(todo)}', flush=True)
    t0=time.time(); completed=len(done)
    if todo:
        with ProcessPoolExecutor(max_workers=5, initializer=init_worker, initargs=(seed,)) as ex:
            futs={ex.submit(worker,n):int(n['id']) for n in todo}
            for fut in as_completed(futs):
                r=fut.result(); rid=r['id']
                tmp=RES/f'{rid}.json.tmp'; p=RES/f'{rid}.json'
                tmp.write_text(json.dumps(r,sort_keys=True,separators=(',',':'))+'\n')
                os.replace(tmp,p)
                completed+=1
                if completed%10==0 or completed==len(nodes):
                    rows=[]
                    for q in RES.glob('*.json'):
                        try: rows.append(json.load(open(q)))
                        except: pass
                    ordinary=sum(len(x['ordinary_walls']) for x in rows)
                    multi=sum(bool(x.get('multiwall_components')) for x in rows)
                    print(f'PROGRESS {completed}/{len(nodes)} ordinary={ordinary} multi={multi} elapsed={time.time()-t0:.1f}', flush=True)
    rows=[json.load(open(RES/f'{i}.json')) for i in range(11755,12090)]
    assert len(rows)==335 and [r['id'] for r in rows]==list(range(11755,12090))
    obj={'version':'post-v0.5-continuation-25','gate':'d51 11755..12089','status':'PASS-EXACT','counts':{
      'classes':335,'ordinary_exits':sum(len(r['ordinary_walls']) for r in rows),'multiwall_cells':sum(bool(r.get('multiwall_components')) for r in rows)},
      'classifications':rows}
    raw=json.dumps(obj,sort_keys=True,separators=(',',':')).encode(); obj['sha256_without_self']=hashlib.sha256(raw).hexdigest()
    out=OUT/'POSTV05_DEPTH51_11755_12089_CLASSIFICATION.json'; out.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
    print('DONE',obj['counts'],out, flush=True)

if __name__=='__main__': main()
