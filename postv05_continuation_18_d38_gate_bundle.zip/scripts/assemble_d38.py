import sys,json,glob,os,time,hashlib
sys.path.insert(0,'/mnt/data/post_v05/rel/src')
from selling_toolkit.fast_layers import quotient_layer_fast, FastHitRange
ROOT='/mnt/data/post_v05'; BASE=ROOT+'/rel'; OUT=ROOT+'/d38_gate'; os.makedirs(OUT,exist_ok=True)
def load(p):
    with open(p,'r',encoding='utf-8') as f:return json.load(f)
def write(name,obj):
    raw=json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode(); h=hashlib.sha256(raw).hexdigest(); obj=dict(obj);obj['sha256_without_self']=h
    path=os.path.join(OUT,name)
    with open(path,'w',encoding='utf-8') as f:json.dump(obj,f,indent=2,sort_keys=True,ensure_ascii=False);f.write('\n')
    return path,h
chunks=[]; rows=[]; elapsed=0.0
for fn in sorted(glob.glob(OUT+'/chunks/d38_scc*.json')):
    d=load(fn); chunks.append({'file':os.path.basename(fn),'source_scc':d['source_scc'],'offset':d['offset'],'id_range':d['id_range'],'count':d['count'],'sha256_without_self':d['sha256_without_self']}); rows+=d['results']; elapsed+=float(d['elapsed_seconds'])
rows.sort(key=lambda r:r['id'])
assert len(rows)==941 and [r['id'] for r in rows]==list(range(5946,6887)), (len(rows),rows[0]['id'],rows[-1]['id'])
multi=[r for r in rows if r.get('multiwall_components')]
classification={'version':'post-v0.5-continuation-18','phase':'d38-classification-scc-by-scc','status':'PASS-941/941-EXACT-SCC-BY-SCC','layer':'d38','id_range':[5946,6886],'class_count':941,'source_scc_counts':{'0':932,'1':9},'ordinary_exit_count':sum(len(r['ordinary_walls']) for r in rows),'multiwall_count':len(multi),'multiwall_ids':[r['id'] for r in multi],'chunk_count':len(chunks),'chunks':chunks,'elapsed_chunk_seconds_sum':elapsed,'results':rows,'guards':['SCC0 932/932 completed before SCC1 9/9','assembled only after all 941 exact classifications present','multiwall components retained and not expanded as ordinary exits','d48 not classified during d38 classification','public toolkit API/CLI/schema unchanged']}
p,ch=write('POSTV05_DEPTH38_5946_6886_CLASSIFICATION_SCC.json',classification)
print('CLASSIFICATION',classification['ordinary_exit_count'],classification['multiwall_count'],classification['multiwall_ids'],ch,flush=True)
idx=load(ROOT+'/d47_gate/POSTV05_REPRESENTATIVE_INDEX_AFTER_D47.json')['representatives']
assert len(idx)==7074 and [n['id'] for n in idx]==list(range(7074))
nodes=idx[5946:6887]
assert len(nodes)==941 and all(int(n['depth'])==38 for n in nodes)
seed=load(BASE+'/toolchain/synthetic_invariant_Qa.seed.json')
ranges=[
 FastHitRange('d48-index-only',6887,7073),FastHitRange('d38',5946,6886),FastHitRange('d47',5778,5945),
 FastHitRange('d37',4988,5777),FastHitRange('d46',4858,4987),FastHitRange('d36',4188,4857),FastHitRange('d45',4078,4187),
 FastHitRange('d35',3538,4077),FastHitRange('d44',3448,3537),FastHitRange('older',0,3447)]
t=time.time();q=quotient_layer_fast(seed=seed,global_representatives=idx,nodes=nodes,classifications=rows,target_depth=39,kind='DEPTH39',layer_label='d39-post-v05-cont18',hit_ranges=ranges);dt=time.time()-t
quot={'version':'post-v0.5-continuation-18','phase':'d38-quotient','status':'PASS-941/941-EXACT-QUOTIENTED','engine':'selling-toolkit-0.5.0 FastCanonicalIndex int64 guarded','known_index_before':'0..7073','processing_order':'id','elapsed_seconds':dt,'counts':q['counts'],'multiwalls':q['multiwalls'],'hit_buckets':q['hit_buckets'],'events':q['events'],'new_depth39_nodes':q['new_nodes'],'guards':['complete post-d47 global index 0..7073 used','d48 6887..7073 treated as known index-only and not classified','new representatives inserted immediately for deterministic same-pass collapse','multiwall components retained/not expanded','d48 classification not opened','public toolkit API/CLI/schema unchanged']}
qp,qh=write('POSTV05_DEPTH38_5946_6886_QUOTIENT_SCC_TOOLKIT.json',quot)
print('QUOTIENT',json.dumps(q['counts'],sort_keys=True),'BUCKETS',json.dumps(q['hit_buckets'],sort_keys=True),'sec',round(dt,3),qh,flush=True)
reps={'version':'post-v0.5-continuation-18','status':f"PASS-COMPLETE-GLOBAL-INDEX-0..{len(q['representatives_after'])-1}",'representative_count':len(q['representatives_after']),'representatives':q['representatives_after']}
rp,rh=write('POSTV05_REPRESENTATIVE_INDEX_AFTER_D38.json',reps)
print('INDEX',len(q['representatives_after']),len(q['representatives_after'])-1,rh,flush=True)
