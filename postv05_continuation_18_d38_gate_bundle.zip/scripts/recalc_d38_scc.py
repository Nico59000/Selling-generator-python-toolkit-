import sys,json,os,hashlib
sys.path.insert(0,'/mnt/data/post_v05/rel/src')
from selling_toolkit.layers import tarjan_scc
ROOT='/mnt/data/post_v05'; OUT=ROOT+'/d38_gate'
def load(p):
    with open(p,'r') as f:return json.load(f)
def write(name,obj):
    raw=json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode(); h=hashlib.sha256(raw).hexdigest(); obj=dict(obj); obj['sha256_without_self']=h
    with open(os.path.join(OUT,name),'w') as f:json.dump(obj,f,indent=2,sort_keys=True);f.write('\n')
    return h
old=load(ROOT+'/d37_gate/POSTV05_DEPTH37_SCC_RECALCULATION.json')
old_comps={c['scc']:c['ids'] for c in old['components']}
id2old={i:s for s,ids in old_comps.items() for i in ids}
assert len(id2old)==4500, len(id2old)
def ov(s):return -(s+1)
meta_vertices=[ov(s) for s in sorted(old_comps)] + list(range(5946,6887))
meta_edges=[]
for e in old.get('condensation_edges',[]): meta_edges.append((ov(e['from']),ov(e['to'])))
# d37 -> d38 edges from continuation 16 quotient
q37=load(ROOT+'/d37_gate/POSTV05_DEPTH37_4988_5777_QUOTIENT_SCC_TOOLKIT.json')
for e in q37['events']:
    t=int(e['target']); s=int(e['source'])
    if 5946<=t<=6886:
        assert s in id2old
        meta_edges.append((ov(id2old[s]),t))
# d38 -> old/d38 edges from current quotient. Exclude d46/d47/d48/d39 and anything outside old scope.
q38=load(OUT+'/POSTV05_DEPTH38_5946_6886_QUOTIENT_SCC_TOOLKIT.json')
for e in q38['events']:
    s=int(e['source']); t=int(e['target'])
    if t in id2old: meta_edges.append((s,ov(id2old[t])))
    elif 5946<=t<=6886: meta_edges.append((s,t))
meta=tarjan_scc(meta_vertices,meta_edges)
expanded=[]
for c in meta['components']:
    ids=[]
    for v in c['ids']:
        if v<0: ids.extend(old_comps[-v-1])
        else: ids.append(v)
    expanded.append(sorted(ids))
expanded.sort(key=lambda c:(-len(c),c[0]))
cid={v:i for i,c in enumerate(expanded) for v in c}
from collections import Counter
cond=Counter()
for a,b in meta_edges:
    aa=old_comps[-a-1][0] if a<0 else a
    bb=old_comps[-b-1][0] if b<0 else b
    if cid[aa]!=cid[bb]:cond[(cid[aa],cid[bb])]+=1
res={'version':'post-v0.5-continuation-18','phase':'d38-scc-recalculation','status':'PASS-EXACT-SCC-RECALC','scope':'d23..d38 only; d46/d47/d48/d39 excluded','method':'exact old d23..d37 SCC contraction + all d37->d38 and d38->(d23..d38) quotient edges','vertex_count':sum(map(len,expanded)),'count':len(expanded),'sizes':[len(c) for c in expanded],'components':[{'scc':i,'size':len(c),'ids':c} for i,c in enumerate(expanded)],'condensation_edges':[{'from':a,'to':b,'count':n} for (a,b),n in sorted(cond.items())],'edge_summary':{'old_condensation_edges':len(old.get('condensation_edges',[])),'d37_to_d38':sum(5946<=int(e['target'])<=6886 for e in q37['events']),'d38_to_old':sum(int(e['target']) in id2old for e in q38['events']),'d38_to_d38':sum(5946<=int(e['target'])<=6886 for e in q38['events'])},'guards':['old d23..d37 SCC partition taken from sealed exact recalculation','d46/d47/d48 and new d39 nodes excluded from d23..d38 SCC scope','all relevant quotient edges included; multiwalls not expanded']}
h=write('POSTV05_DEPTH38_SCC_RECALCULATION.json',res)
print(json.dumps({'status':res['status'],'vertex_count':res['vertex_count'],'count':res['count'],'sizes':res['sizes'],'edge_summary':res['edge_summary'],'sha256_without_self':h}))
