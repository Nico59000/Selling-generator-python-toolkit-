#!/usr/bin/env python3
import sys,json,zipfile,tempfile,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def load(p): return json.load(open(p))
bad=[];rows=[]
for p in sorted((R/'chunks').glob('d38_scc*.json')):
    d=load(p);x=dict(d);h=x.pop('sha256_without_self',None);raw=json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
    if hashlib.sha256(raw).hexdigest()!=h:bad.append('chunk_hash:'+p.name)
    rows+=d['results']
rows.sort(key=lambda r:r['id']);clf=load(R/'POSTV05_DEPTH38_5946_6886_CLASSIFICATION_SCC.json')
if rows!=clf['results']:bad.append('chunk_assembly_mismatch')
if [r['id'] for r in rows]!=list(range(5946,6887)):bad.append('coverage')
with tempfile.TemporaryDirectory() as td:
    zipfile.ZipFile(R/'inputs/selling_toolkit_v05_0_source.zip').extractall(td);sys.path.insert(0,td)
    from selling_toolkit.layers import classify_exact,tarjan_scc
    from selling_seed2d.algebra import S,FIRST_MOVE,WALL_ACTION,RELABEL,build_finite_group
    from selling_seed2d.seed import seed_matrices
    seed=load(R/'inputs/synthetic_invariant_Qa.seed.json');reps=load(R/'inputs/POSTV05_REPRESENTATIVE_INDEX_AFTER_D47.json')['representatives'];nodes=reps[5946:6887];cm={r['id']:r for r in rows}
    ids=list(range(5946,5956))+[6400,6402,6405,6425,6427,6772,6782,6871,6875]
    direct=classify_exact([reps[i] for i in ids],seed,workers=5)
    if direct!=[cm[i] for i in ids]:bad.append('direct_classifier_mismatch')
    quot=load(R/'POSTV05_DEPTH38_5946_6886_QUOTIENT_SCC_TOOLKIT.json')
    _Q,_A,Qc,deck_named=seed_matrices(seed);deck=build_finite_group([g for _,g in deck_named],32)
    def smat(M):return tuple(tuple(int(x) for x in row) for row in M.tolist())
    def mm(A,B):
        C=list(zip(*B));return tuple(tuple(sum(a*b for a,b in zip(row,col)) for col in C) for row in A)
    def tr(A):return tuple(zip(*A))
    def neg(A):return tuple(tuple(-x for x in row) for row in A)
    def key(A):return tuple(x for row in A for x in row)
    D=[smat(x) for x in deck];RR=[smat(x) for x in RELABEL];Sm={w:smat(S[FIRST_MOVE[w]-1]) for w in FIRST_MOVE};Wm={w:smat(WALL_ACTION[w]) for w in WALL_ACTION};Q=smat(Qc)
    variants={};current=[dict(x) for x in reps]
    def add(rid,A):
        for di,d in enumerate(D):
            DA=mm(d,A)
            for ri,r in enumerate(RR):
                X=mm(DA,r);variants.setdefault(key(X),(rid,di,ri,1));variants.setdefault(key(neg(X)),(rid,di,ri,-1))
    for x in current:add(int(x['id']),tuple(tuple(int(v) for v in row) for row in x['A']))
    got=[];new=[];next_id=len(current)
    for n in nodes:
        A=tuple(tuple(int(v) for v in row) for row in n['A']);L=tuple(tuple(int(v) for v in row) for row in n['L'])
        for wall in cm[n['id']]['ordinary_walls']:
            An=mm(A,Sm[wall]);Ln=mm(Wm[wall],L);M=mm(mm(tr(An),Q),An);con=[sum(M[i][j] for j in range(3)) for i in range(3)]+[-M[0][1],-M[0][2],-M[1][2]];j2=sum(v*v for v in con)
            e={'source':n['id'],'wall':wall,'J2':str(j2)};hit=variants.get(key(An))
            if hit is not None:
                target,di,ri,sign=hit;e.update(status='HIT',target=target,deck_index=di,relabel_index=ri,sign=sign)
            else:
                target=next_id;next_id+=1;e.update(status='NEW',target=target)
                nn={'id':target,'path_from_C2':n.get('path_from_C2','')+wall,'kind':'DEPTH39','depth':39,'source':n['id'],'arrival_wall':wall,'A':[[str(v) for v in row] for row in An],'L':[[str(v) for v in row] for row in Ln],'M':[[str(v) for v in row] for row in M],'J2':str(j2),'conorm6':[str(v) for v in con],'_layer':'d39-post-v05-cont18'}
                new.append(nn);current.append(nn);add(target,An)
            got.append(e)
    if got!=quot['events']:bad.append('event_replay_mismatch')
    if new!=quot['new_depth39_nodes']:bad.append('new_node_replay_mismatch')
    if len(current)!=8222:bad.append('final_index_size')
    # SCC recomputation through old contraction
    old=load(R/'inputs/POSTV05_DEPTH37_SCC_RECALCULATION.json');old_comps={c['scc']:c['ids'] for c in old['components']};id2old={i:s for s,ids0 in old_comps.items() for i in ids0}
    def ov(s):return -(s+1)
    verts=[ov(s) for s in sorted(old_comps)]+list(range(5946,6887));edges=[]
    for e0 in old.get('condensation_edges',[]):edges.append((ov(e0['from']),ov(e0['to'])))
    q37=load(R/'inputs/POSTV05_DEPTH37_4988_5777_QUOTIENT_SCC_TOOLKIT.json')
    for e0 in q37['events']:
        t=int(e0['target']);s=int(e0['source'])
        if 5946<=t<=6886:edges.append((ov(id2old[s]),t))
    for e0 in quot['events']:
        s=int(e0['source']);t=int(e0['target'])
        if t in id2old:edges.append((s,ov(id2old[t])))
        elif 5946<=t<=6886:edges.append((s,t))
    meta=tarjan_scc(verts,edges);expanded=[]
    for c in meta['components']:
        z=[]
        for v in c['ids']:z.extend(old_comps[-v-1] if v<0 else [v])
        expanded.append(sorted(z))
    expanded.sort(key=lambda c:(-len(c),c[0]))
    scc=load(R/'POSTV05_DEPTH38_SCC_RECALCULATION.json')
    if [len(c) for c in expanded]!=scc['sizes']:bad.append('scc_size_replay_mismatch')
    if expanded!=[c['ids'] for c in scc['components']]:bad.append('scc_component_replay_mismatch')
expected_multi=[(6400,'114*q + 379*r - 201',['k','m']),(6402,'114*q + 379*r - 201',['g','n']),(6405,'114*q + 379*r - 201',['m','n']),(6425,'2*q + 5*r - 3',['m','n']),(6427,'114*q + 379*r - 201',['g','k']),(6772,'362*q + 1389*r - 699',['k','l']),(6782,'362*q + 1389*r - 699',['l','n']),(6871,'98*q + 345*r - 179',['g','m']),(6875,'98*q + 345*r - 179',['h','k'])]
got_multi=[]
for r in rows:
    for c in r.get('multiwall_components',[]):got_multi.append((r['id'],c['factor'],c['walls']))
if got_multi!=expected_multi:bad.append('multiwall_list')
q=load(R/'POSTV05_DEPTH38_5946_6886_QUOTIENT_SCC_TOOLKIT.json')
if q['counts']!={'classes':941,'ordinary_exits':3468,'hits':2320,'new':1148,'multiwall_cells':9}:bad.append('quotient_counts')
if q['hit_buckets']!={'d37':1167,'d38':896,'same-pass':257}:bad.append('hit_buckets')
audit=load(R/'POSTV05_CONTINUATION_18_TOOLKIT_FREEZE_AUDIT.json')
if audit['status']!='PASS-TOOLKIT-0.5.0-FROZEN-UNCHANGED':bad.append('toolkit_freeze')
hyp=load(R/'POSTV05_FACTOR345_TRIANGLE345_HYPOTHESIS_REGISTRY.json')
if hyp['status']!='CONTEXT/PENDING-MORPHISM':bad.append('345_guard')
print(json.dumps({'status':'PASS' if not bad else 'FAIL','failed':bad,'classification':len(rows),'events':len(q['events']),'new':len(q['new_depth39_nodes']),'index_last':8221,'scc_sizes':load(R/'POSTV05_DEPTH38_SCC_RECALCULATION.json')['sizes']},sort_keys=True))
raise SystemExit(1 if bad else 0)
