import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'toolkit_src'))
from selling_toolkit.fast_layers import quotient_layer_fast,FastHitRange
seed=json.load(open(ROOT/'inputs/synthetic_invariant_Qa.seed.json'));reps=json.load(open(ROOT/'POSTV05_REPRESENTATIVE_INDEX_AFTER_D54.json'))['representatives'];rows=[json.load(open(ROOT/'replay_results'/f'{i}.json')) for i in range(20815,24256)];nodes=[reps[i] for i in range(20815,24256)]
ranges=[FastHitRange('older_0_8221',0,8221),FastHitRange('d49',8222,8453),FastHitRange('d40',8454,9822),FastHitRange('d50',9823,10103),FastHitRange('d41',10104,11754),FastHitRange('d51',11755,12089),FastHitRange('d42',12090,14087),FastHitRange('d52',14088,14477),FastHitRange('d43',14478,16874),FastHitRange('d53',16875,17361),FastHitRange('d44',17362,20236),FastHitRange('d54',20237,20814),FastHitRange('d45',20815,24255),FastHitRange('d55-index-only',24256,24952)]
q=quotient_layer_fast(seed=seed,global_representatives=reps,nodes=nodes,classifications=rows,target_depth=46,kind='DEPTH46',layer_label='d46-post-v05-cont32',hit_ranges=ranges)
orig=json.load(open(ROOT/'POSTV05_DEPTH45_20815_24255_QUOTIENT_TOOLKIT.json'))
def evs(x):return [(e['source'],e['wall'],e['status'],e['target'],e['J2']) for e in x['events']]
def nodesig(x):return [(n['id'],n['source'],n.get('via_wall',n.get('arrival_wall')),n['A'],n['L'],n['J2']) for n in x]
rep={'version':'post-v0.5-continuation-32','status':'PASS' if q['counts']==orig['counts'] and evs(q)==evs(orig) and nodesig(q['new_nodes'])==nodesig(orig['new_depth46_nodes']) else 'FAIL','counts':q['counts'],'original_counts':orig['counts'],'event_sequence_exact':evs(q)==evs(orig),'new_nodes_exact':nodesig(q['new_nodes'])==nodesig(orig['new_depth46_nodes']),'hit_buckets':q['hit_buckets']}
(ROOT/'D45_QUOTIENT_FRESH_REPLAY_REPORT.json').write_text(json.dumps(rep,indent=2,sort_keys=True)+'\n');print(json.dumps(rep,indent=2))
