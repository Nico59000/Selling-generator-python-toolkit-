import sys,json,hashlib
from pathlib import Path
from collections import Counter
BASE=Path('/mnt/data/cont32');sys.path.insert(0,str(BASE/'toolkit_src'))
from selling_toolkit.layers import tarjan_scc
def load(p):return json.load(open(p))
def write(name,obj):
 raw=json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode();h=hashlib.sha256(raw).hexdigest();obj=dict(obj);obj['sha256_without_self']=h;(BASE/name).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n');return h
old=load('/mnt/data/cont30/POSTV05_DEPTH44_SCC_RECALCULATION.json');old_comps={c['scc']:c['ids'] for c in old['components']};id2old={i:s for s,ids in old_comps.items() for i in ids}
def ov(s):return -(s+1)
meta_vertices=[ov(s) for s in sorted(old_comps)]+list(range(20815,24256));meta_edges=[]
for e in old.get('condensation_edges',[]):meta_edges.append((ov(e['from']),ov(e['to'])))
q44=load('/mnt/data/cont30/POSTV05_DEPTH44_17362_20236_QUOTIENT_TOOLKIT.json')
for e in q44['events']:
 t=int(e['target']);s=int(e['source'])
 if 20815<=t<=24255:
  assert s in id2old;meta_edges.append((ov(id2old[s]),t))
q45=load(BASE/'POSTV05_DEPTH45_20815_24255_QUOTIENT_TOOLKIT.json')
for e in q45['events']:
 s=int(e['source']);t=int(e['target'])
 if t in id2old:meta_edges.append((s,ov(id2old[t])))
 elif 20815<=t<=24255:meta_edges.append((s,t))
meta=tarjan_scc(meta_vertices,meta_edges);expanded=[]
for c in meta['components']:
 ids=[]
 for v in c['ids']:
  if v<0:ids.extend(old_comps[-v-1])
  else:ids.append(v)
 expanded.append(sorted(ids))
expanded.sort(key=lambda c:(-len(c),c[0]));cid={v:i for i,c in enumerate(expanded) for v in c};cond=Counter()
for a,b in meta_edges:
 aa=old_comps[-a-1][0] if a<0 else a;bb=old_comps[-b-1][0] if b<0 else b
 if cid[aa]!=cid[bb]:cond[(cid[aa],cid[bb])]+=1
res={'version':'post-v0.5-continuation-32','phase':'d45-scc-recalculation','status':'PASS-EXACT-SCC-RECALC','scope':'d23..d45 only; side layers and new d46 excluded','method':'exact old d23..d44 SCC contraction + all d44->d45 and d45->(d23..d45) quotient edges','vertex_count':sum(map(len,expanded)),'count':len(expanded),'sizes':[len(c) for c in expanded],'components':[{'scc':i,'size':len(c),'ids':c} for i,c in enumerate(expanded)],'condensation_edges':[{'from':a,'to':b,'count':n} for (a,b),n in sorted(cond.items())],'edge_summary':{'old_condensation_edges':len(old.get('condensation_edges',[])),'d44_to_d45':sum(20815<=int(e['target'])<=24255 for e in q44['events']),'d45_to_old':sum(int(e['target']) in id2old for e in q45['events']),'d45_to_d45':sum(20815<=int(e['target'])<=24255 for e in q45['events'])},'guards':['old d23..d44 SCC partition from sealed continuation 30','side layers d51,d52,d53,d54,d55 and new d46 excluded','all relevant quotient edges included; multiwalls not expanded','overlays excluded']}
h=write('POSTV05_DEPTH45_SCC_RECALCULATION.json',res);print(json.dumps({'status':res['status'],'vertex_count':res['vertex_count'],'count':res['count'],'sizes':res['sizes'],'edge_summary':res['edge_summary'],'sha256_without_self':h},indent=2));id2new={i:c['scc'] for c in res['components'] for i in c['ids']};cnt=Counter(id2new[int(n['source'])] for n in q45['new_depth46_nodes']);print('D46_SOURCE_SCC',dict(sorted(cnt.items())))
