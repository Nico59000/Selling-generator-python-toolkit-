import os,json,sys,time
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import sympy as sp
from sympy.core.cache import clear_cache
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'toolkit_src'))
from selling_seed2d.chart import build_chart
from selling_seed2d.classifier import ExactBoundaryClassifier
IDX=json.load(open(ROOT/'POSTV05_REPRESENTATIVE_INDEX_AFTER_D54.json'))['representatives'];SEED=json.load(open(ROOT/'inputs/synthetic_invariant_Qa.seed.json'));_G=None
class FastSignMixin:
 def root_sign(self,poly_r,root_poly,iv):
  r=self.r;G=sp.Poly(poly_r,r,domain=sp.QQ);F=sp.Poly(root_poly,r,domain=sp.QQ)
  if G.is_zero:return 0
  R=G.rem(F)
  if R.is_zero:return 0
  if R.degree()<=0:
   v=R.LC();return 1 if v>0 else -1
  if R.degree()==1:
   a,b=R.all_coeffs();t=-b/a
   if F.eval(t)==0:return 0
   lo,hi=iv
   for _ in range(40):
    if hi<t:return -1 if a>0 else 1
    if t<lo:return 1 if a>0 else -1
    if lo==hi:return 1 if a*(lo-t)>0 else -1
    lo,hi=sp.refine_root(F,lo,hi,eps=(hi-lo)/10)
  return super().root_sign(poly_r,root_poly,iv)
class FastExact(FastSignMixin,ExactBoundaryClassifier):pass
def init():
 global _G
 c=build_chart(SEED);_G=FastExact(c.q,c.r,c.wall_vector,c.D0)
def work(i):
 try:
  n=IDX[i];L=sp.Matrix([[sp.Integer(v) for v in row] for row in n['L']]);c=_G.classify_cell(L)
  return {'id':i,'ordinary_walls':list(c['ordinary_walls']),'multiwall_components':[{'factor':z['factor'],'walls':list(z['walls'])} for z in c.get('multiwall_components',[])],'polynomials':c.get('polynomials',{})}
 finally:clear_cache()
def main():
 out=ROOT/'replay_results';out.mkdir(exist_ok=True);todo=[i for i in range(20815,24256) if not (out/f'{i}.json').exists()];t=time.time();done=0;print('START',len(todo),flush=True)
 with ProcessPoolExecutor(max_workers=5,initializer=init) as ex:
  fs={ex.submit(work,i):i for i in todo}
  for f in as_completed(fs):
   x=f.result();p=out/f"{x['id']}.json";tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(x,sort_keys=True,separators=(',',':'))+'\n');os.replace(tmp,p);done+=1
   if done%100==0 or done==len(todo):print('P',done,'/',len(todo),'sec',round(time.time()-t,2),flush=True)
 mism=[]
 for i in range(20815,24256):
  a=json.load(open(out/f'{i}.json'));b=json.load(open(ROOT/'chunks'/f'{i}.json'))
  if a!=b:mism.append(i)
 rep={'version':'post-v0.5-continuation-32','status':'PASS' if not mism else 'FAIL','fresh_reclassification':3441,'mismatches':mism,'elapsed_seconds':time.time()-t,'method':'fresh extraction selling-toolkit 0.5.0 + exact polynomial sign acceleration cross-validated'}
 (ROOT/'FAST_EXACT_D45_REPLAY_REPORT.json').write_text(json.dumps(rep,indent=2,sort_keys=True)+'\n');print('END',json.dumps(rep),flush=True)
if __name__=='__main__':main()
