import json,sys
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import sympy as sp
from sympy.core.cache import clear_cache
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'toolkit_src'))
from selling_seed2d.chart import build_chart
from selling_seed2d.classifier import ExactBoundaryClassifier
IDX=json.load(open(ROOT/'POSTV05_REPRESENTATIVE_INDEX_AFTER_D54.json'))['representatives'];SEED=json.load(open(ROOT/'inputs/synthetic_invariant_Qa.seed.json'));_G=None
mw=[20815,20816,21187,21188,21492,21850,21914,22062,22063,22125,22147,22232,22242,22521,22522,22538,22546,22564,22741,22746,23137,23139,23157,23756,23762,23765,23831,23849,24230,24235,24242]
# 50 distributed, union with multiwalls
samples=sorted(set(round(20815+i*(24255-20815)/49) for i in range(50))|set(mw))
def init():
 global _G;c=build_chart(SEED);_G=ExactBoundaryClassifier(c.q,c.r,c.wall_vector,c.D0)
def work(i):
 try:
  n=IDX[i];L=sp.Matrix([[sp.Integer(v) for v in row] for row in n['L']]);c=_G.classify_cell(L)
  return {'id':i,'ordinary_walls':list(c['ordinary_walls']),'multiwall_components':[{'factor':z['factor'],'walls':list(z['walls'])} for z in c.get('multiwall_components',[])],'polynomials':c.get('polynomials',{})}
 finally:clear_cache()
with ProcessPoolExecutor(max_workers=5,initializer=init) as ex: vals=list(ex.map(work,samples))
m=[]
for a in vals:
 b=json.load(open(ROOT/'chunks'/f"{a['id']}.json"))
 if a!=b:m.append(a['id'])
rep={'version':'post-v0.5-continuation-32','status':'PASS' if not m else 'FAIL','checked':len(samples),'multiwalls_checked':len(mw),'mismatches':m,'ids':samples}
(ROOT/'DIRECT_TOOLKIT_D45_CROSSCHECK.json').write_text(json.dumps(rep,indent=2,sort_keys=True)+'\n');print(json.dumps(rep,indent=2))
