#!/usr/bin/env python3
import json,hashlib,zipfile,tempfile,subprocess,sys,os,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parent
N=0

def ck(cond,msg):
 global N
 if not cond: raise AssertionError(msg)
 N+=1

def load(name): return json.loads((ROOT/name).read_text())
def selfless(d):
 got=d.get('sha256_without_self');x=dict(d);x.pop('sha256_without_self',None)
 raw=json.dumps(x,sort_keys=True,separators=(',',':')).encode();return got,hashlib.sha256(raw).hexdigest()
def verify_self(name):
 d=load(name);a,b=selfless(d);ck(a==b,f'selfhash {name}');return d
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

cp=verify_self('V04_SAFE_FRONTIER_CONTINUATION_13_CHECKPOINT.json')
ck(cp['version']=='v0.4-continuation-13','checkpoint version')
ck(cp['status']=='RESEARCH-CHECKPOINT / APPEND-ONLY-CONTINUATION','checkpoint status')
ck(cp['numeric_frontier']['global_index']=={'range':[0,4857],'count':4858,'status':'PASS-COMPLETE-GLOBAL-INDEX-0..4857'},'checkpoint index')
ck(cp['numeric_frontier']['enlarged_scc']['sizes']==[2974,60,2,1,1,1,1],'checkpoint scc sizes')
ck(cp['v05_release']['rc_readiness']=='PASS-V05-RC-READY-CANDIDATE/NOT-RC/NOT-RELEASED','rc readiness checkpoint')

# d44 classification/chunks
c44=verify_self('V04_DEPTH44_3448_3537_CLASSIFICATION.json'); rows44=c44['results']
ck(c44['status']=='PASS-90/90-EXACT','d44 class status');ck([r['id'] for r in rows44]==list(range(3448,3538)),'d44 ids')
ck(c44['ordinary_exit_count']==334,'d44 exits');ck(c44['multiwall_ids']==[],'d44 no multi')
chunks=[]
files=sorted((ROOT/'d44_chunks').glob('*.json'));ck(len(files)==9,'d44 chunk count')
for p in files:
 d=json.loads(p.read_text());a,b=selfless(d);ck(a==b,f'd44 chunk hash {p.name}');ck(d['status']=='NONPUBLISHABLE-CHUNK',f'd44 chunk status {p.name}');chunks+=d['results']
ck(sorted(r['id'] for r in chunks)==list(range(3448,3538)),'d44 chunks cover');ck(len({r['id'] for r in chunks})==90,'d44 chunks unique')
for r in rows44:ck(set(r['ordinary_walls'])<=set('ghklmn'),f'd44 walls {r["id"]}');ck(not r.get('multiwall_components'),'d44 no multi row')
q44=verify_self('V04_DEPTH44_3448_3537_QUOTIENT_TOOLKIT.json')
ck(q44['counts']=={'classes':90,'ordinary_exits':334,'hits':224,'new':110,'multiwall_cells':0},'q44 counts')
ck(q44['hit_buckets']=={'d43':109,'d44':93,'same-pass':21,'d35':1},'q44 buckets')
ck([n['id'] for n in q44['new_depth45_nodes']]==list(range(4078,4188)),'d45 ids')
for e in q44['events']:ck(e['status'] in ('HIT','NEW'),'q44 event status')
idx44=verify_self('V04_REPRESENTATIVE_INDEX_AFTER_D44.json');ck(idx44['representative_count']==4188,'idx44 count');ck([r['id'] for r in idx44['representatives']]==list(range(4188)),'idx44 contiguous')

# d35 classification/chunks
c35=verify_self('V04_DEPTH35_3538_4077_CLASSIFICATION_SCC.json');rows35=c35['results']
ck(c35['status']=='PASS-540/540-EXACT-SCC-BY-SCC','d35 class status');ck([r['id'] for r in rows35]==list(range(3538,4078)),'d35 ids')
ck(c35['counts']=={'classes':540,'ordinary_exits':1982,'multiwall_cells':5},'d35 counts')
ck(c35['source_scc_group_sizes']=={'0':532,'1':8},'d35 source sizes');ck(c35['multiwall_ids']==[4013,4017,4065,4068,4077],'d35 multi ids')
expect={
 4013:[{'factor':'362*q + 1389*r - 699','walls':['h','n']}],
 4017:[{'factor':'362*q + 1389*r - 699','walls':['h','n']}],
 4065:[{'factor':'98*q + 345*r - 179','walls':['m','n']}],
 4068:[{'factor':'98*q + 345*r - 179','walls':['h','l']}],
 4077:[{'factor':'2*q + 5*r - 3','walls':['l','m']}],
}
for r in rows35:
 ck(set(r['ordinary_walls'])<=set('ghklmn'),f'd35 walls {r["id"]}');ck(r['enlarged_source_scc'] in (0,1),f'd35 source {r["id"]}')
 if r['id'] in expect:ck(r['multiwall_components']==expect[r['id']],f'd35 multi {r["id"]}')
chunks=[];files=sorted((ROOT/'d35_chunks').glob('*.json'));ck(len(files)==26,'d35 chunk count')
for p in files:
 d=json.loads(p.read_text());a,b=selfless(d);ck(a==b,f'd35 chunk hash {p.name}');ck(d['status']=='NONPUBLISHABLE-CHUNK',f'd35 chunk status {p.name}');chunks+=d['results']
ck(sorted(r['id'] for r in chunks)==list(range(3538,4078)),'d35 chunks cover');ck(len({r['id'] for r in chunks})==540,'d35 chunks unique')
q35=verify_self('V04_DEPTH35_3538_4077_QUOTIENT_SCC_TOOLKIT.json')
ck(q35['counts']=={'classes':540,'ordinary_exits':1982,'hits':1312,'new':670,'multiwall_cells':5},'q35 counts')
ck(q35['hit_buckets']=={'d34':666,'d35':505,'same-pass':140,'d44':1},'q35 buckets')
ck(q35['source_scc_counts']=={'0':{'exits':1954,'hits':1295,'new':659},'1':{'exits':28,'hits':17,'new':11}},'q35 source counts')
ck([n['id'] for n in q35['new_depth36_nodes']]==list(range(4188,4858)),'d36 ids')
ck(q35['d35_internal_scc']['count']==288,'d35 internal scc');ck(q35['enlarged_d23_to_d35_scc']['vertex_count']==3040,'enlarged vertex count');ck(q35['enlarged_d23_to_d35_scc']['sizes']==[2974,60,2,1,1,1,1],'enlarged sizes')
for e in q35['events']:ck(e['status'] in ('HIT','NEW'),'q35 event status');ck(e['enlarged_source_scc'] in (0,1),'q35 event source scc')
idx35=verify_self('V04_REPRESENTATIVE_INDEX_AFTER_D35.json');ck(idx35['representative_count']==4858,'idx35 count');ck([r['id'] for r in idx35['representatives']]==list(range(4858)),'idx35 contiguous')

# freeze/release boundary
scope=verify_self('V04_V05_5D_SCOPE_FREEZE_DECISION.json');ck(scope['status']=='PASS-V05-5D-SCOPE-FROZEN-CANDIDATE/RC-PENDING','scope freeze')
codef=verify_self('V04_V05_CODE_FREEZE_DECISION.json');ck(codef['status']=='PASS-V05-CODE-FREEZE-CANDIDATE/RC-PENDING','code freeze')
rc=verify_self('V04_V05_RC_READINESS.json');ck(rc['status']=='PASS-V05-RC-READY-CANDIDATE/NOT-RC/NOT-RELEASED','rc ready')
est=verify_self('V04_TO_V05_RELEASE_ESTIMATE_CONT13.json');ck(est['estimate']['additional_passes_after_continuation_13']=={'range':[1,2],'most_likely':1},'estimate')
trep=verify_self('V04_SELLING_TOOLKIT_046_CONT13_FREEZE_TEST_REPORT.json');ck(trep['pytest']=='17/17 PASS','freeze pytest');ck(trep['clean_wheel_install']=='PASS','freeze install');ck(trep['source_tree_byte_identical_to_cont12'],'freeze source identical');ck(sha(ROOT/trep['wheel'])==trep['wheel_sha256'],'wheel hash');ck(sha(ROOT/trep['source_zip'])==trep['source_zip_sha256'],'source zip hash')
hlin=verify_self('V04_SELLING_3D5D_DET_SWAP_H1_ZERO_NO_GO.json')['certificate'];ck(hlin['H1_dimension']==0,'linear H1')
haff=verify_self('V04_GOLDEN_RESIDUAL_AFFINE_H1_ZERO_NO_GO.json')['certificate'];ck(haff['H1_dimension']==0,'affine H1')
rank2=verify_self('V04_BASE_MODULE_RANK2_FIBRE_NO_GO.json')['certificate'];ck(rank2['generated_algebra_dimension']==9 and rank2['commutant_dimension']==1,'rank2 no-go')
r7=verify_self('V04_R7_SOURCE_RHO_MARKED_SCREEN_EXTENDED.json');ck(r7['unrecycled_candidate_count']==0,'R7 zero');ck(r7['HTNT']['Qa_infinitude']=='NT','Qa NT')

# Dynamic replay from bundled frozen source
with tempfile.TemporaryDirectory() as td:
 td=Path(td);src=td/'src';src.mkdir()
 with zipfile.ZipFile(ROOT/'selling_toolkit_v04_6_source.zip') as z:z.extractall(src)
 env=dict(os.environ);env['PYTHONPATH']=str(src)
 pv=subprocess.run([sys.executable,'-c','import selling_toolkit;print(selling_toolkit.__version__)'],capture_output=True,text=True,env=env);ck(pv.returncode==0 and pv.stdout.strip()=='0.4.6','source version')
 pt=subprocess.run([sys.executable,'-m','pytest','-q',str(src/'tests'/'test_toolkit.py')],capture_output=True,text=True,env=env);ck(pt.returncode==0 and '17 passed' in pt.stdout,'dynamic pytest')
 target=td/'wheel';target.mkdir();pi=subprocess.run([sys.executable,'-m','pip','install','--no-deps','--target',str(target),str(ROOT/'selling_toolkit-0.4.6-py3-none-any.whl')],capture_output=True,text=True);ck(pi.returncode==0,'wheel install');pv2=subprocess.run([sys.executable,'-c',f"import sys;sys.path.insert(0,{str(target)!r});import selling_toolkit;print(selling_toolkit.__version__)"],capture_output=True,text=True);ck(pv2.returncode==0 and pv2.stdout.strip()=='0.4.6','wheel version')
 sys.path.insert(0,str(src))
 from selling_toolkit.layers import classify_exact,tarjan_scc
 from selling_toolkit.fast_layers import quotient_layer_fast,FastHitRange
 from selling_toolkit.cohomology import DeterminantSwapH1NoGo,GoldenResidualAffineH1NoGo
 from selling_toolkit.fibre_representations import BaseModuleRank2FibreNoGo
 seed=load('toolchain/synthetic_invariant_Qa.seed.json');q43=load('V04_DEPTH43_2909_2979_QUOTIENT_TOOLKIT.json');q34=load('V04_DEPTH34_2980_3447_QUOTIENT_SCC_TOOLKIT.json');idx34=load('V04_REPRESENTATIVE_INDEX_AFTER_D34.json')['representatives']
 # selected exact classification incl all d35 multiwalls
 ids={3448,3490,3537};rr=classify_exact([n for n in q43['new_depth44_nodes'] if n['id'] in ids],seed,workers=3);sm={r['id']:r for r in rows44}
 for r in rr:ck(r['ordinary_walls']==sm[r['id']]['ordinary_walls'],f'reclass d44 {r["id"]}');ck(r.get('multiwall_components',[])==sm[r['id']].get('multiwall_components',[]),f'reclass d44 multi {r["id"]}')
 ids={3538,4013,4017,4065,4068,4077};rr=classify_exact([n for n in q34['new_depth35_nodes'] if n['id'] in ids],seed,workers=6);sm={r['id']:r for r in rows35}
 for r in rr:ck(r['ordinary_walls']==sm[r['id']]['ordinary_walls'],f'reclass d35 {r["id"]}');ck(r.get('multiwall_components',[])==sm[r['id']].get('multiwall_components',[]),f'reclass d35 multi {r["id"]}')
 # replay q44
 ranges=[FastHitRange('d32',2131,2450),FastHitRange('d42',2451,2523),FastHitRange('d33',2524,2908),FastHitRange('d43',2909,2979),FastHitRange('d34',2980,3447),FastHitRange('d44',3448,3537),FastHitRange('d35',3538,4077)]
 qr=quotient_layer_fast(seed=seed,global_representatives=idx34,nodes=q43['new_depth44_nodes'],classifications=rows44,target_depth=45,kind='DEPTH45',layer_label='d45',hit_ranges=ranges);ck(qr['events']==q44['events'],'q44 replay events');ck(qr['new_nodes']==q44['new_depth45_nodes'],'q44 replay new')
 # replay q35
 source_scc={i:c['scc'] for c in q34['enlarged_d23_to_d34_scc']['components'] for i in c['ids']}
 ranges2=[FastHitRange('d32',2131,2450),FastHitRange('d42',2451,2523),FastHitRange('d33',2524,2908),FastHitRange('d43',2909,2979),FastHitRange('d34',2980,3447),FastHitRange('d44',3448,3537),FastHitRange('d35',3538,4077),FastHitRange('d45',4078,4187)]
 qr2=quotient_layer_fast(seed=seed,global_representatives=idx44['representatives'],nodes=q34['new_depth35_nodes'],classifications=rows35,target_depth=36,kind='DEPTH36',layer_label='d36',hit_ranges=ranges2,source_scc=source_scc);ck(qr2['events']==q35['events'],'q35 replay events');ck(qr2['new_nodes']==q35['new_depth36_nodes'],'q35 replay new')
 # exact SCC recompute
 lo,hi=3538,4077;iedges=[(e['source'],e['target']) for e in qr2['events'] if lo<=e['target']<=hi];internal=tarjan_scc(range(lo,hi+1),iedges);ck(internal['count']==288,'dynamic d35 internal scc')
 gprev=q34['enlarged_d23_to_d34_scc'];SBASE=30_000_000;syn={c['scc']:SBASE+c['scc'] for c in gprev['components']};vertices=list(syn.values())+list(range(lo,hi+1));edges=[]
 for e in gprev.get('condensation_edges',[]):edges.extend([(syn[e['from']],syn[e['to']])]*int(e.get('count',1)))
 for e in q34['events']:
  targ=e['target']
  if lo<=targ<=hi and e['source'] in source_scc:edges.append((syn[source_scc[e['source']]],targ))
 for e in qr2['events']:
  targ=e['target']
  if targ in source_scc:edges.append((e['source'],syn[source_scc[targ]]))
  elif lo<=targ<=hi:edges.append((e['source'],targ))
 contracted=tarjan_scc(vertices,edges);oldcomp={syn[c['scc']]:c['ids'] for c in gprev['components']};expanded=[]
 for comp in contracted['components']:
  ids=[]
  for x in comp['ids']:ids.extend(oldcomp[x] if x in oldcomp else [x])
  expanded.append(sorted(ids))
 expanded.sort(key=lambda c:(-len(c),c[0]));ck([len(c) for c in expanded]==[2974,60,2,1,1,1,1],'dynamic enlarged scc')
 ck(DeterminantSwapH1NoGo.certificate()['H1_dimension']==0,'dynamic linear H1');ck(GoldenResidualAffineH1NoGo.certificate()['H1_dimension']==0,'dynamic affine H1');nc=BaseModuleRank2FibreNoGo.certificate();ck(nc['generated_algebra_dimension']==9 and nc['commutant_dimension']==1,'dynamic rank2')
print(json.dumps({'status':'PASS','checks':N,'version':'v0.4-continuation-13'},indent=2))
