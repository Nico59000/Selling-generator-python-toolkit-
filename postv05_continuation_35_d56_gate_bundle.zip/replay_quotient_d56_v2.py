import json,sys,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent; sys.path.insert(0,str(ROOT/'toolkit_src_extracted/build/lib'))
from selling_toolkit.fast_layers import quotient_layer_fast,FastHitRange
mism=[]
for i in range(29079,29934):
 a=json.load(open(ROOT/'replay_chunks_v2'/f'{i}.json')); b=json.load(open(ROOT/'chunks'/f'{i}.json'))
 if a!=b: mism.append(i)
if mism: raise SystemExit(f'classification mismatches {mism[:20]} total={len(mism)}')
seed=json.load(open(ROOT/'inputs/synthetic_invariant_Qa.seed.json')); reps=json.load(open(ROOT/'POSTV05_REPRESENTATIVE_INDEX_AFTER_D46.json'))['representatives']
rows=[json.load(open(ROOT/'replay_chunks_v2'/f'{i}.json')) for i in range(29079,29934)]; nodes=[reps[i] for i in range(29079,29934)]
ranges=[FastHitRange('older_0_8221',0,8221),FastHitRange('d49',8222,8453),FastHitRange('d40',8454,9822),FastHitRange('d50',9823,10103),FastHitRange('d41',10104,11754),FastHitRange('d51',11755,12089),FastHitRange('d42',12090,14087),FastHitRange('d52',14088,14477),FastHitRange('d43',14478,16874),FastHitRange('d53',16875,17361),FastHitRange('d44',17362,20236),FastHitRange('d54',20237,20814),FastHitRange('d45',20815,24255),FastHitRange('d55',24256,24952),FastHitRange('d46',24953,29078),FastHitRange('d56',29079,29933),FastHitRange('d47-index-only',29934,34884)]
t=time.time(); q=quotient_layer_fast(seed=seed,global_representatives=reps,nodes=nodes,classifications=rows,target_depth=57,kind='DEPTH57',layer_label='d57-post-v05-cont35',hit_ranges=ranges);elapsed=time.time()-t
orig=json.load(open(ROOT/'POSTV05_DEPTH56_29079_29933_QUOTIENT_TOOLKIT.json')); fields=('source','wall','status','target','J2')
computed=[tuple(e[k] for k in fields) for e in q['events']]; observed=[tuple(e[k] for k in fields) for e in orig['events']]; new_exact=q['new_nodes']==orig['new_depth57_nodes']
rep={'version':'post-v0.5-continuation-35','status':'PASS' if not mism and computed==observed and new_exact and q['counts']==orig['counts'] and q['hit_buckets']==orig['hit_buckets'] else 'FAIL','classification_replay':{'classes':855,'mismatches':mism,'exact':not mism},'counts':q['counts'],'hit_buckets':q['hit_buckets'],'event_sequence_exact':computed==observed,'new_nodes_exact':new_exact,'elapsed_seconds':elapsed}
raw=json.dumps(rep,sort_keys=True,separators=(',',':')).encode(); rep['sha256_without_self']=hashlib.sha256(raw).hexdigest(); (ROOT/'D56_QUOTIENT_FRESH_REPLAY_REPORT.json').write_text(json.dumps(rep,indent=2,sort_keys=True)+'\n')
cross=json.load(open(ROOT/'DIRECT_TOOLKIT_D56_CROSSCHECK_V2.json'))
post={'version':'post-v0.5-continuation-35','status':'PASS' if rep['status']=='PASS' and cross['status']=='PASS' else 'FAIL','fresh_extraction':'postseal_fresh_extract_v2','fresh_reclassification':855,'classification_failures':mism,'accelerated_exact_replay':'PASS-855/855' if not mism else 'FAIL','direct_frozen_toolkit_crosscheck':f"{cross['checked']}/{cross['checked']} PASS" if cross['status']=='PASS' else 'FAIL','direct_multiwall_crosscheck':f"{cross['multiwalls_checked']}/{cross['multiwalls_checked']} PASS" if cross['status']=='PASS' else 'FAIL','ordinary_exits':orig['counts']['ordinary_exits'],'hits':orig['counts']['hits'],'new':orig['counts']['new'],'hit_buckets':orig['hit_buckets'],'event_sequence_exact':rep['event_sequence_exact'],'new_nodes_exact':rep['new_nodes_exact'],'quotient_fresh_status':rep['status'],'toolkit_version':'0.5.0','notes':['Fresh replay v2 uses exact polynomial-remainder sign optimization over frozen ExactBoundaryClassifier semantics.','Direct crosscheck uses unmodified frozen ExactBoundaryClassifier on distributed IDs including all d56 multiwalls.']}
raw=json.dumps(post,sort_keys=True,separators=(',',':')).encode(); post['sha256_without_self']=hashlib.sha256(raw).hexdigest(); (ROOT/'POSTV05_CONTINUATION_35_POSTSEAL_REPLAY_REPORT.json').write_text(json.dumps(post,indent=2,sort_keys=True)+'\n')
print(json.dumps(rep,indent=2,sort_keys=True)); print(json.dumps(post,indent=2,sort_keys=True))
