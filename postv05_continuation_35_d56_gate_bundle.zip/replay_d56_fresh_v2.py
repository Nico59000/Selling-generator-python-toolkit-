import os,json,sys,time
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import sympy as sp
from sympy.core.cache import clear_cache
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'toolkit_src_extracted/build/lib'))
from selling_seed2d.chart import build_chart
from selling_seed2d.classifier import ExactBoundaryClassifier
INDEX=BASE/'POSTV05_REPRESENTATIVE_INDEX_AFTER_D46.json'; SEED=BASE/'inputs/synthetic_invariant_Qa.seed.json'; OUT=BASE/'replay_chunks_v2'; _G=None
class FastSignMixin:
 def root_sign(self, poly_r, root_poly, iv):
  r=self.r; G=sp.Poly(poly_r,r,domain=sp.QQ); F=sp.Poly(root_poly,r,domain=sp.QQ)
  if G.is_zero:return 0
  Rr=G.rem(F)
  if Rr.is_zero:return 0
  d=Rr.degree()
  if d<=0:
   v=Rr.LC(); return 1 if v>0 else -1
  if d==1:
   a,b=Rr.all_coeffs(); t=-b/a
   if F.eval(t)==0:return 0
   lo,hi=iv
   for _ in range(40):
    if hi<t:return -1 if a>0 else 1
    if t<lo:return 1 if a>0 else -1
    if lo==hi:return 1 if a*(lo-t)>0 else -1
    lo,hi=sp.refine_root(F,lo,hi,eps=(hi-lo)/10)
  return super().root_sign(poly_r,root_poly,iv)
class FastExactBoundaryClassifier(FastSignMixin,ExactBoundaryClassifier):pass
def load(p): return json.load(open(p,encoding='utf-8'))
def imat(rows):return sp.Matrix([[sp.Integer(v) for v in row] for row in rows])
def init_worker(seed):
 global _G
 c=build_chart(seed); _G=FastExactBoundaryClassifier(c.q,c.r,c.wall_vector,c.D0)
def worker(node):
 try:
  c=_G.classify_cell(imat(node['L']))
  return {'id':int(node['id']),'ordinary_walls':list(c['ordinary_walls']),'multiwall_components':[{'factor':z['factor'],'walls':list(z['walls'])} for z in c.get('multiwall_components',[])],'polynomials':c.get('polynomials',{})}
 finally:clear_cache()
def main():
 idx=load(INDEX); seed=load(SEED); OUT.mkdir(exist_ok=True)
 nodes=[idx['representatives'][i] for i in range(29079,29934) if not (OUT/f'{i}.json').exists()]
 print('START',len(nodes),flush=True);t=time.time();ok=0
 with ProcessPoolExecutor(max_workers=5,initializer=init_worker,initargs=(seed,)) as ex:
  fs={ex.submit(worker,n):n for n in nodes}
  for f in as_completed(fs):
   x=f.result(); p=OUT/f"{x['id']}.json"; tmp=p.with_suffix('.tmp'); tmp.write_text(json.dumps(x,sort_keys=True,separators=(',',':'))+'\n'); os.replace(tmp,p); ok+=1
   if ok%50==0 or ok==len(nodes): print('P',ok,'/',len(nodes),'saved',len(list(OUT.glob('*.json'))),'sec',round(time.time()-t,2),flush=True)
 print('END',ok,'saved',len(list(OUT.glob('*.json'))),'sec',round(time.time()-t,2),flush=True)
if __name__=='__main__':main()
