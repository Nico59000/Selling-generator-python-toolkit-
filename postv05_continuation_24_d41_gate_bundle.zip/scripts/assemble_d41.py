import sys,json,glob,os,time,hashlib
sys.path.insert(0,'/mnt/data/post_v05/rel/src')
from selling_toolkit.fast_layers import quotient_layer_fast, FastHitRange
ROOT='/mnt/data/post_v05'; BASE=ROOT+'/rel'; OUT=ROOT+'/d41_gate'; os.makedirs(OUT,exist_ok=True)
def load(p):
    with open(p,'r',encoding='utf-8') as f:return json.load(f)
def write(name,obj):
    raw=json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode(); h=hashlib.sha256(raw).hexdigest(); obj=dict(obj);obj['sha256_without_self']=h
    path=os.path.join(OUT,name)
    with open(path,'w',encoding='utf-8') as f:json.dump(obj,f,indent=2,sort_keys=True,ensure_ascii=False);f.write('\n')
    return path,h
chunks=[]; rows=[]; elapsed=0.0
for fn in sorted(glob.glob(OUT+'/chunks/d41_scc*.json')):
    d=load(fn); chunks.append({'file':os.path.basename(fn),'source_scc':d['source_scc'],'offset':d['offset'],'id_range':d['id_range'],'count':d['count'],'sha256_without_self':d['sha256_without_self']}); rows+=d['results']; elapsed+=float(d['elapsed_seconds'])
rows.sort(key=lambda r:r['id'])
assert len(rows)==1651 and [r['id'] for r in rows]==list(range(10104,11755)), (len(rows),rows[0]['id'] if rows else None,rows[-1]['id'] if rows else None)
multi=[r for r in rows if r.get('multiwall_components')]
classification={'version':'post-v0.5-continuation-24','phase':'d41-classification-scc-by-scc','status':'PASS-1651/1651-EXACT-SCC-BY-SCC','layer':'d41','id_range':[10104,11754],'class_count':1651,'source_scc_counts':{'0':1640,'1':11},'ordinary_exit_count':sum(len(r['ordinary_walls']) for r in rows),'multiwall_count':len(multi),'multiwall_ids':[r['id'] for r in multi],'multiwalls':[{'id':r['id'],'ordinary_walls':r['ordinary_walls'],'components':r['multiwall_components']} for r in multi],'chunk_count':len(chunks),'chunks':chunks,'elapsed_chunk_seconds_sum':elapsed,'results':rows,'guards':['SCC0 1640/1640 completed before SCC1 11/11 in source-SCC order','assembled only after all 1651 exact classifications present','multiwall components retained and not expanded as ordinary exits','d51 11755..12089 treated as index-only/HIT-only and not classified during d41 gate','no d52 opened','public toolkit 0.5.0 API/CLI/schema unchanged','Ucirc/chi/OEIS overlays observational and do not mutate classification']}
p,ch=write('POSTV05_DEPTH41_10104_11754_CLASSIFICATION_SCC.json',classification)
print('CLASSIFICATION',classification['ordinary_exit_count'],classification['multiwall_count'],classification['multiwall_ids'],ch,flush=True)
idx=load(ROOT+'/d50_gate/POSTV05_REPRESENTATIVE_INDEX_AFTER_D50.json')['representatives']
assert len(idx)==12090 and [n['id'] for n in idx]==list(range(12090))
nodes=idx[10104:11755]
assert len(nodes)==1651 and all(int(n['depth'])==41 for n in nodes)
seed=load(BASE+'/toolchain/synthetic_invariant_Qa.seed.json')
ranges=[
 FastHitRange('d51-index-only',11755,12089), FastHitRange('d41',10104,11754), FastHitRange('d50',9823,10103),
 FastHitRange('d40',8454,9822), FastHitRange('d49',8222,8453), FastHitRange('d39',7074,8221),
 FastHitRange('d48',6887,7073), FastHitRange('d38',5946,6886), FastHitRange('d47',5778,5945),
 FastHitRange('d37',4988,5777), FastHitRange('d46',4858,4987), FastHitRange('d36',4188,4857),
 FastHitRange('d45',4078,4187), FastHitRange('older',0,4077)]
t=time.time();q=quotient_layer_fast(seed=seed,global_representatives=idx,nodes=nodes,classifications=rows,target_depth=42,kind='DEPTH42',layer_label='d42-post-v05-cont24',hit_ranges=ranges);dt=time.time()-t
quot={'version':'post-v0.5-continuation-24','phase':'d41-quotient','status':'PASS-1651/1651-EXACT-QUOTIENTED','engine':'selling-toolkit-0.5.0 FastCanonicalIndex int64 guarded','known_index_before':'0..12089','processing_order':'id / source-SCC0 then source-SCC1','elapsed_seconds':dt,'counts':q['counts'],'multiwalls':q['multiwalls'],'hit_buckets':q['hit_buckets'],'events':q['events'],'new_depth42_nodes':q['new_nodes'],'guards':['complete post-d50 global index 0..12089 used','d51 11755..12089 treated as known index-only and not classified','new representatives inserted immediately for deterministic same-pass collapse','multiwall components retained/not expanded','d51/d52 classification not opened','public toolkit API/CLI/schema unchanged','Ucirc/chi/OEIS overlays do not mutate quotient']}
qp,qh=write('POSTV05_DEPTH41_10104_11754_QUOTIENT_SCC_TOOLKIT.json',quot)
print('QUOTIENT',json.dumps(q['counts'],sort_keys=True),'BUCKETS',json.dumps(q['hit_buckets'],sort_keys=True),'sec',round(dt,3),qh,flush=True)
reps={'version':'post-v0.5-continuation-24','status':f"PASS-COMPLETE-GLOBAL-INDEX-0..{len(q['representatives_after'])-1}",'representative_count':len(q['representatives_after']),'representatives':q['representatives_after']}
rp,rh=write('POSTV05_REPRESENTATIVE_INDEX_AFTER_D41.json',reps)
print('INDEX',len(q['representatives_after']),len(q['representatives_after'])-1,rh,flush=True)
