import json,hashlib,collections,os
ROOT='/mnt/data/post_v05'; OUT=ROOT+'/d41_gate'
old=json.load(open(ROOT+'/d50_gate/POSTV05_MULTIWALL_RECURRENCE_AUDIT_AFTER_D50.json'))
clf=json.load(open(OUT+'/POSTV05_DEPTH41_10104_11754_CLASSIFICATION_SCC.json'))
events=[dict(x) for x in old['events']]
for r in clf['results']:
    for c in r.get('multiwall_components',[]): events.append({'depth':41,'factor':c['factor'],'id':r['id'],'layer':'d41-post-v0.5-cont24','source':'post-v0.5 continuation 24 exact SCC classification','walls':list(c['walls'])})
seen=set();uniq=[]
for e in events:
    k=(e['id'],e['factor'],tuple(e['walls']))
    if k not in seen:seen.add(k);uniq.append(e)
events=uniq;by=collections.defaultdict(list)
for e in events:by[e['factor']].append(e)
families=[]
for f,es in by.items():
    pc=collections.Counter('/'.join(sorted(e['walls'])) for e in es)
    families.append({'factor':f,'event_count':len(es),'ids':sorted(e['id'] for e in es),'depths':sorted(set(e['depth'] for e in es)),'wall_pair_counts':dict(sorted(pc.items()))})
families.sort(key=lambda x:(-x['event_count'],x['factor']))
walls='ghklmn'; allpairs=[''.join((walls[i],walls[j])) for i in range(6) for j in range(i+1,6)]; pc=collections.Counter(''.join(sorted(e['walls'])) for e in events); op={'gl','hm','kn'};adj=[p for p in allpairs if p not in op]
pair_inc={'counts':dict(sorted(pc.items())),'opposite_pairs_observed':sum(pc[p]>0 for p in op),'adjacent_pairs_observed':sum(pc[p]>0 for p in adj)}
f345=next((x for x in families if x['factor']=='98*q + 345*r - 179'),None)
res={'version':'post-v0.5-continuation-24','status':'PASS-EXACT-APPEND-ONLY-MULTIWALL-CENSUS-AFTER-D41','event_count':len(events),'factor_family_count':len(families),'events':events,'families':families,'factor345':({'factor':f345['factor'],'event_count':f345['event_count'],'depths':f345['depths'],'status':'CONTEXT/PENDING-MORPHISM for 345 <-> (3,4,5); recurrence exact, interpretation not promoted'} if f345 else None),'pair_incidence':pair_inc,'scope_guard':'append-only exact census through d41; no future extrapolation','typing_guards':['factor recurrence is exact equality, not yet a common source-native carrier','345 <-> 3-4-5 remains CONTEXT/PENDING-MORPHISM','Ucirc/chi/OEIS overlays remain typed and non-mutating']}
raw=json.dumps(res,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode();res['sha256_without_self']=hashlib.sha256(raw).hexdigest();p=OUT+'/POSTV05_MULTIWALL_RECURRENCE_AUDIT_AFTER_D41.json';json.dump(res,open(p,'w'),indent=2,sort_keys=True,ensure_ascii=False);open(p,'a').write('\n')
print(json.dumps({'status':res['status'],'events':res['event_count'],'families':res['factor_family_count'],'factor345':res['factor345'],'pair_incidence':res['pair_incidence'],'family_summary':[(x['factor'],x['event_count'],x['depths']) for x in families]},indent=2))
