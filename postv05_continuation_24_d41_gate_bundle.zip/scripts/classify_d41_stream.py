import sys,json,time,hashlib,os,argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
sys.path.insert(0,'/mnt/data/post_v05/rel/src')
from selling_toolkit.layers import imat
from selling_seed2d.chart import build_chart
from selling_seed2d.classifier import ExactBoundaryClassifier
ROOT='/mnt/data/post_v05'; OUT=ROOT+'/d41_gate/chunks'; os.makedirs(OUT,exist_ok=True)
_CLF=None

def init_worker(seed):
    global _CLF
    chart=build_chart(seed); _CLF=ExactBoundaryClassifier(chart.q,chart.r,chart.wall_vector,chart.D0)

def classify_task(task):
    off,nodes=task; t=time.time(); out=[]
    for node in nodes:
        c=_CLF.classify_cell(imat(node['L']))
        out.append({'id':int(node['id']),'ordinary_walls':list(c['ordinary_walls']),
                    'multiwall_components':[{'factor':z['factor'],'walls':list(z['walls'])} for z in c.get('multiwall_components',[])],
                    'polynomials':c.get('polynomials',{})})
    return off,out,time.time()-t

def load(p):
    with open(p,'r',encoding='utf-8') as f:return json.load(f)

def dump_chunk(scc,off,rows,dt):
    rows=sorted(rows,key=lambda r:r['id']); fn=f'd41_scc{scc}_{off:04d}_{off+len(rows)-1:04d}.json'; path=os.path.join(OUT,fn)
    obj={'version':'post-v0.5-continuation-24','phase':'d41-classification-chunk','engine':'research cached-worker harness over frozen selling-toolkit 0.5.0 ExactBoundaryClassifier','layer':'d41','source_scc':scc,'offset':[off,off+len(rows)-1],'id_range':[rows[0]['id'],rows[-1]['id']],'count':len(rows),'elapsed_seconds':dt,'results':rows}
    raw=json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode(); obj['sha256_without_self']=hashlib.sha256(raw).hexdigest()
    with open(path,'w',encoding='utf-8') as f:json.dump(obj,f,indent=2,sort_keys=True,ensure_ascii=False);f.write('\n')
    return fn,obj

def validate_existing(path, expected_nodes):
    try:
        d=load(path); rows=d['results']; return len(rows)==len(expected_nodes) and [r['id'] for r in rows]==[n['id'] for n in expected_nodes]
    except Exception:return False

def run_scc(scc,chunk=10,workers=5):
    seed=load(ROOT+'/rel/toolchain/synthetic_invariant_Qa.seed.json')
    reps=load(ROOT+'/d50_gate/POSTV05_REPRESENTATIVE_INDEX_AFTER_D50.json')['representatives']
    allnodes=reps[10104:11755]
    prev=load(ROOT+'/d40_gate/POSTV05_DEPTH40_SCC_RECALCULATION.json')
    src_scc={i:c['scc'] for c in prev['components'] for i in c['ids']}
    nodes=[x for x in allnodes if src_scc.get(int(x.get('source',-1)))==scc]
    expected=1640 if scc==0 else 11
    assert len(nodes)==expected,(scc,len(nodes),expected)
    tasks=[]; done=ordinary=0; multi=[]
    for off in range(0,len(nodes),chunk):
        sub=nodes[off:off+chunk]; fn=f'd41_scc{scc}_{off:04d}_{off+len(sub)-1:04d}.json'; path=os.path.join(OUT,fn)
        if validate_existing(path,sub):
            d=load(path); done+=len(sub); ordinary+=sum(len(r['ordinary_walls']) for r in d['results']); multi += [r['id'] for r in d['results'] if r.get('multiwall_components')]
        else: tasks.append((off,sub))
    print(json.dumps({'event':'START_SCC','scc':scc,'expected':expected,'already_done':done,'remaining':sum(len(x[1]) for x in tasks),'task_count':len(tasks)}),flush=True)
    t0=time.time()
    with ProcessPoolExecutor(max_workers=min(workers,5),initializer=init_worker,initargs=(seed,)) as ex:
        futs={ex.submit(classify_task,t):t for t in tasks}
        for fut in as_completed(futs):
            off,sub=futs[fut]; roff,rows,dt=fut.result(); assert roff==off
            fn,obj=dump_chunk(scc,off,rows,dt); done+=len(rows); ordinary+=sum(len(r['ordinary_walls']) for r in rows); mids=[r['id'] for r in rows if r.get('multiwall_components')]; multi+=mids
            print(json.dumps({'event':'CHUNK','scc':scc,'offset':obj['offset'],'ids':obj['id_range'],'count':len(rows),'done':done,'expected':expected,'ordinary_cum':ordinary,'multi_new':mids,'elapsed_wall':round(time.time()-t0,2),'task_sec':round(dt,2),'file':fn}),flush=True)
    print(json.dumps({'event':'DONE_SCC','scc':scc,'done':done,'ordinary':ordinary,'multi_ids':sorted(multi),'elapsed_wall':round(time.time()-t0,2)}),flush=True)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--scc',type=int,choices=[0,1],required=True); ap.add_argument('--chunk',type=int,default=10); ap.add_argument('--workers',type=int,default=5); a=ap.parse_args(); run_scc(a.scc,a.chunk,a.workers)
if __name__=='__main__': main()
