import sys,json,os,hashlib
sys.path.insert(0,'/mnt/data/post_v05/rel/src')
from selling_toolkit.layers import tarjan_scc
ROOT='/mnt/data/post_v05'; OUT=ROOT+'/d41_gate'
def load(p):
    with open(p,'r') as f:return json.load(f)
def write(name,obj):
    raw=json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode(); h=hashlib.sha256(raw).hexdigest(); obj=dict(obj);obj['sha256_without_self']=h
    with open(os.path.join(OUT,name),'w') as f:json.dump(obj,f,indent=2,sort_keys=True);f.write('\n')
    return h
old=load(ROOT+'/d40_gate/POSTV05_DEPTH40_SCC_RECALCULATION.json')
old_comps={c['scc']:c['ids'] for c in old['components']}; id2old={i:s for s,ids in old_comps.items() for i in ids}
assert len(id2old)==7958,len(id2old)
def ov(s):return -(s+1)
meta_vertices=[ov(s) for s in sorted(old_comps)] + list(range(10104,11755)); meta_edges=[]
for e in old.get('condensation_edges',[]):meta_edges.append((ov(e['from']),ov(e['to'])))
q40=load(ROOT+'/d40_gate/POSTV05_DEPTH40_8454_9822_QUOTIENT_SCC_TOOLKIT.json')
for e in q40['events']:
    t=int(e['target']);s=int(e['source'])
    if 10104<=t<=11754:
        assert s in id2old; meta_edges.append((ov(id2old[s]),t))
q41=load(OUT+'/POSTV05_DEPTH41_10104_11754_QUOTIENT_SCC_TOOLKIT.json')
for e in q41['events']:
    s=int(e['source']);t=int(e['target'])
    if t in id2old: meta_edges.append((s,ov(id2old[t])))
    elif 10104<=t<=11754: meta_edges.append((s,t))
meta=tarjan_scc(meta_vertices,meta_edges)
expanded=[]
for c in meta['components']:
    ids=[]
    for v in c['ids']:
        if v<0:ids.extend(old_comps[-v-1])
        else:ids.append(v)
    expanded.append(sorted(ids))
expanded.sort(key=lambda c:(-len(c),c[0])); cid={v:i for i,c in enumerate(expanded) for v in c}
from collections import Counter
cond=Counter()
for a,b in meta_edges:
    aa=old_comps[-a-1][0] if a<0 else a; bb=old_comps[-b-1][0] if b<0 else b
    if cid[aa]!=cid[bb]:cond[(cid[aa],cid[bb])]+=1
res={'version':'post-v0.5-continuation-24','phase':'d41-scc-recalculation','status':'PASS-EXACT-SCC-RECALC','scope':'d23..d41 only; side layers d46-d51 and new d42 excluded','method':'exact old d23..d40 SCC contraction + all d40->d41 and d41->(d23..d41) quotient edges','vertex_count':sum(map(len,expanded)),'count':len(expanded),'sizes':[len(c) for c in expanded],'components':[{'scc':i,'size':len(c),'ids':c} for i,c in enumerate(expanded)],'condensation_edges':[{'from':a,'to':b,'count':n} for (a,b),n in sorted(cond.items())],'edge_summary':{'old_condensation_edges':len(old.get('condensation_edges',[])),'d40_to_d41':sum(10104<=int(e['target'])<=11754 for e in q40['events']),'d41_to_old':sum(int(e['target']) in id2old for e in q41['events']),'d41_to_d41':sum(10104<=int(e['target'])<=11754 for e in q41['events'])},'guards':['old d23..d40 SCC partition taken from sealed exact recalculation','side layers and new d42 nodes excluded from d23..d41 SCC scope','all relevant quotient edges included; multiwalls not expanded','Ucirc/chi/OEIS overlays excluded from graph edges']}
h=write('POSTV05_DEPTH41_SCC_RECALCULATION.json',res)
print(json.dumps({'status':res['status'],'vertex_count':res['vertex_count'],'count':res['count'],'sizes':res['sizes'],'edge_summary':res['edge_summary'],'sha256_without_self':h}))
id2new={i:c['scc'] for c in res['components'] for i in c['ids']}; new=q41['new_depth42_nodes']; cnt=Counter(id2new[int(n['source'])] for n in new); print('D42_SOURCE_SCC',dict(sorted(cnt.items())))
