import sys,json,hashlib
from pathlib import Path
import sympy as sp
sys.path.insert(0,'/mnt/data/post_v05/rel/src')
from selling_seed2d.algebra import RELABEL, build_finite_group
from selling_seed2d.seed import seed_matrices
ROOT=Path('/mnt/data/post_v05'); G=ROOT/'d41_gate'
seed=json.load(open(ROOT/'rel/toolchain/synthetic_invariant_Qa.seed.json'))
_Q,_A,Q,deck_named=seed_matrices(seed); D=build_finite_group([g for _,g in deck_named],32)
# U from M entries / conorm order p01,p02,p03,p12,p13,p23
def U_from_M(rows):
 M=[[int(x) for x in r] for r in rows]
 p01=sum(M[0]); p02=sum(M[1]); p03=sum(M[2]); p12=-M[0][1]; p13=-M[0][2]; p23=-M[1][2]
 return (p01+p23,p02+p13,p03+p12)
def sortedU(rows): return tuple(sorted(U_from_M(rows)))
# symbolic relabel test
a,b,c,g,h,k=sp.symbols('a b c g h k'); M=sp.Matrix([[a,k,h],[k,b,g],[h,g,c]])
def U_sym(X):
 return (sp.expand(sum(X[0,j] for j in range(3))-X[1,2]), sp.expand(sum(X[1,j] for j in range(3))-X[0,2]), sp.expand(sum(X[2,j] for j in range(3))-X[0,1]))
u0=U_sym(M)
from itertools import permutations
perms=[]; bad_rel=[]
for i,R in enumerate(RELABEL):
 u=U_sym(R.T*M*R); f=None
 for p in permutations(range(3)):
  if all(sp.expand(u[j]-u0[p[j]])==0 for j in range(3)): f=p; break
 if f is None: bad_rel.append(i)
 else: perms.append(f)
deck_ok=[]
for i,d in enumerate(D): deck_ok.append(sp.Matrix(d).T*Q*sp.Matrix(d)==Q)
# all d41 HITs compare source/target sorted U using updated index (new IDs include d50, but hits target old/current)
idx=json.load(open(G/'POSTV05_REPRESENTATIVE_INDEX_AFTER_D41.json'))['representatives']; by={x['id']:x for x in idx}
q=json.load(open(G/'POSTV05_DEPTH41_10104_11754_QUOTIENT_SCC_TOOLKIT.json'))
from selling_seed2d.algebra import S,FIRST_MOVE
def mm(A,B):
 B=list(zip(*B)); return tuple(tuple(sum(a*b for a,b in zip(row,col)) for col in B) for row in A)
def tr(A): return tuple(zip(*A))
def smat(X): return tuple(tuple(int(v) for v in row) for row in X.tolist())
Sm={w:smat(S[FIRST_MOVE[w]-1]) for w in FIRST_MOVE}
bad_hits=[]; hit_count=0
for e in q['events']:
 if e['status']!='HIT': continue
 hit_count+=1; src=by[e['source']]; A=tuple(tuple(int(v) for v in row) for row in src['A']); An=mm(A,Sm[e['wall']]); Mn=mm(mm(tr(An),smat(Q)),An); us=tuple(sorted(U_from_M(Mn))); ut=sortedU(by[e['target']]['M'])
 if us!=ut: bad_hits.append({'event':e,'source_sorted_U':us,'target_sorted_U':ut})
# centered numerator vector C=3U-sumU*1 avoids fractions; sorted C invariant too
def centered_num(rows):
 u=U_from_M(rows); s=sum(u); return tuple(3*x-s for x in u)
report={
 'version':'post-v0.5-continuation-24','phase':'quotient-compatible opposite-pair conorm observable',
 'status':'PROVEN-EXACT-QUOTIENT-INVARIANT-UNORDERED / S4-to-S3-EQUIVARIANT-ORDERED',
 'definition':{'U':['p01+p23','p02+p13','p03+p12'],'centered_numerator':'C_i=3*U_i-(U1+U2+U3); sum C_i=0'},
 'deck_Q_preservation':{'checked':len(D),'pass':all(deck_ok)},
 'relabel_S4_to_S3':{'checked':len(RELABEL),'pass':not bad_rel,'unique_induced_permutations':len(set(perms)),'kernel_size':sum(p==(0,1,2) for p in perms),'image_size':len(set(perms)),'bad':bad_rel},
 'projective_sign':'A->-A leaves M=A^T Q A unchanged',
 'd41_hit_regression':{'hits_checked':hit_count,'sorted_U_equal':hit_count-len(bad_hits),'failures':bad_hits[:5]},
 'consequence':'The unordered perfect-matching conorm triple descends to the full canonical quotient. The ordered centered triple is an S3-covariant 2D standard-module observable. This replaces path-frequency discrepancy as the preferred candidate input to T5/T7/T9 quantizers.',
 'guard':'No canonical scale/phase quantizer M_N, no source involution -> target antipody intertwiner, and no Selling -> Pascal-Noether coefficient-carrier map are certified yet.'
}
raw=json.dumps(report,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode(); report['sha256_without_self']=hashlib.sha256(raw).hexdigest()
with open(G/'POSTV05_OPPOSITE_PAIR_CONORM_OBSERVABLE_CERTIFICATE.json','w') as f: json.dump(report,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps(report,indent=2,sort_keys=True))
