import json,hashlib,zipfile,os,subprocess,sys
from pathlib import Path
ROOT=Path('/mnt/data/post_v05'); REL=ROOT/'rel'; OUT=ROOT/'d41_gate'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.load(open(p))
source=REL/'selling_toolkit_v05_0_source.zip'; wheel=REL/'selling_toolkit-0.5.0-py3-none-any.whl'
expected_source='d5e35f99cdb556a5f1d6c52355196aa592022527581f468bee1987c28384961b'; expected_wheel='17d61dec03024c6392cf4ce2362e13e7b37facb06314e37ab2c7a65ac3681e88'
mism=[];zip_only=[];compared=0
with zipfile.ZipFile(source) as z:
    names=[n for n in z.namelist() if not n.endswith('/') and not n.startswith('build/')]
    for n in names:
        parts=Path(n).parts; rel=Path(*parts[1:]) if parts and parts[0] in ('selling_toolkit_v05_0_source','selling_toolkit-0.5.0') else Path(n)
        if (rel.parts and rel.parts[0] in ('selling_toolkit','selling_seed2d','tests')) or str(rel) in ('README.md','pyproject.toml'):
            p=REL/'src'/rel
            if not p.exists():zip_only.append(str(rel));continue
            compared+=1
            if hashlib.sha256(z.read(n)).hexdigest()!=sha(p):mism.append(str(rel))
sys.path.insert(0,str(REL/'src'))
from selling_toolkit.layers import classify_exact
idx=load(ROOT/'d50_gate/POSTV05_REPRESENTATIVE_INDEX_AFTER_D50.json')['representatives']; rows=load(OUT/'POSTV05_DEPTH41_10104_11754_CLASSIFICATION_SCC.json')['results']; cm={r['id']:r for r in rows}; seed=load(REL/'toolchain/synthetic_invariant_Qa.seed.json')
multis=[r['id'] for r in rows if r.get('multiwall_components')]; spread=[10104,10105,10106,10107,10108,10929,11754]; sel=sorted(set(spread+multis))
direct=classify_exact([idx[i] for i in sel],seed,workers=5);ok=True
for r in direct:
    e=cm[r['id']]; norm={'id':r['id'],'ordinary_walls':r['ordinary_walls'],'multiwall_components':r.get('multiwall_components',[]),'polynomials':r.get('polynomials',{})}
    if norm!=e:ok=False;print('MISMATCH',r['id'])
pt=subprocess.run(['python','-m','pytest','-q'],cwd=REL/'src',env={**os.environ,'PYTHONPATH':str(REL/'src')},stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(OUT/'toolkit_pytest.log').write_text(pt.stdout)
vr=subprocess.run(['python',str(REL/'verify_v05_release.py')],cwd=REL,env={**os.environ,'PYTHONPATH':str(REL/'src')},stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(OUT/'v05_release_replay.log').write_text(vr.stdout)
pytest_pass=('17 passed' in pt.stdout)
obj={'version':'post-v0.5-continuation-24','status':'PASS-TOOLKIT-0.5.0-FROZEN-UNCHANGED' if all([sha(source)==expected_source,sha(wheel)==expected_wheel,not mism,not zip_only,ok,pytest_pass,vr.returncode==0]) else 'FAIL','source_zip_sha256':sha(source),'wheel_sha256':sha(wheel),'source_tree_compared_files':compared,'source_tree_mismatches':mism,'source_tree_zip_only':zip_only,'direct_classify_selected_ids':sel,'direct_classify_equivalence':f'{len(sel)}/{len(sel)} PASS' if ok else 'FAIL','toolkit_tests':'17/17 PASS' if pytest_pass else f'FAIL rc={pt.returncode}','base_release_replay':'PASS rc=0' if vr.returncode==0 else f'FAIL rc={vr.returncode}'}
raw=json.dumps(obj,sort_keys=True,separators=(',',':')).encode();obj['sha256_without_self']=hashlib.sha256(raw).hexdigest();json.dump(obj,open(OUT/'POSTV05_CONTINUATION_24_TOOLKIT_FREEZE_AUDIT.json','w'),indent=2,sort_keys=True);open(OUT/'POSTV05_CONTINUATION_24_TOOLKIT_FREEZE_AUDIT.json','a').write('\n');print(json.dumps(obj,indent=2,sort_keys=True));raise SystemExit(0 if obj['status'].startswith('PASS') else 1)
