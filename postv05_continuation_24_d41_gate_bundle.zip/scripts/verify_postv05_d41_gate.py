import os,sys,json,zipfile,shutil,hashlib,time
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
ROOT=Path('/mnt/data/post_v05'); BUNDLE=ROOT/'postv05_continuation_24_d41_gate_bundle.zip'; EXT=ROOT/'postseal_d41_extract'; FRESH=EXT/'fresh_toolkit'
if EXT.exists(): shutil.rmtree(EXT)
EXT.mkdir()
with zipfile.ZipFile(BUNDLE) as z:
    bad=z.testzip()
    if bad: raise SystemExit('CRC_FAIL:'+bad)
    z.extractall(EXT)
with zipfile.ZipFile(EXT/'inputs/selling_toolkit_v05_0_source.zip') as z: z.extractall(FRESH)
sys.path.insert(0,str(FRESH))
from selling_toolkit.layers import imat
from selling_seed2d.chart import build_chart
from selling_seed2d.classifier import ExactBoundaryClassifier
from selling_seed2d.algebra import S,FIRST_MOVE,WALL_ACTION,RELABEL,build_finite_group
from selling_seed2d.seed import seed_matrices
seed=json.load(open(EXT/'inputs/synthetic_invariant_Qa.seed.json'))
old=json.load(open(EXT/'inputs/POSTV05_REPRESENTATIVE_INDEX_AFTER_D50.json'))['representatives']; nodes=old[10104:11755]
expected_clf=json.load(open(EXT/'POSTV05_DEPTH41_10104_11754_CLASSIFICATION_SCC.json'))['results']; expected_q=json.load(open(EXT/'POSTV05_DEPTH41_10104_11754_QUOTIENT_SCC_TOOLKIT.json'))
_CLF=None
def init_worker(seed):
 global _CLF
 c=build_chart(seed); _CLF=ExactBoundaryClassifier(c.q,c.r,c.wall_vector,c.D0)
def work(group):
 out=[]
 for n in group:
  c=_CLF.classify_cell(imat(n['L']))
  out.append({'id':int(n['id']),'ordinary_walls':list(c['ordinary_walls']),'multiwall_components':[{'factor':z['factor'],'walls':list(z['walls'])} for z in c.get('multiwall_components',[])],'polynomials':c.get('polynomials',{})})
 return out
w=5;groups=[nodes[i::w] for i in range(w)];t=time.time();rows=[]
with ProcessPoolExecutor(max_workers=w,initializer=init_worker,initargs=(seed,)) as ex:
 for f in as_completed([ex.submit(work,g) for g in groups]):rows.extend(f.result())
rows.sort(key=lambda x:x['id']);class_sec=time.time()-t;fail=[]
if rows!=expected_clf:fail.append('fresh_classification_mismatch')
_Q,_A,Qc,deck_named=seed_matrices(seed);deck=build_finite_group([g for _,g in deck_named],32)
def mm(A,B):B=list(zip(*B));return tuple(tuple(sum(a*b for a,b in zip(row,col)) for col in B) for row in A)
def tr(A):return tuple(zip(*A))
def neg(A):return tuple(tuple(-x for x in r) for r in A)
def key(A):return tuple(x for r in A for x in r)
def smat(M):return tuple(tuple(int(x) for x in row) for row in M.tolist())
D=[smat(x) for x in deck];R=[smat(x) for x in RELABEL];Sm={w:smat(S[FIRST_MOVE[w]-1]) for w in FIRST_MOVE};Q=smat(Qc)
variants={};current=[dict(x) for x in old]
def add(rid,A):
 for di,d in enumerate(D):
  DA=mm(d,A)
  for ri,r in enumerate(R):
   X=mm(DA,r);variants.setdefault(key(X),(rid,di,ri,1));variants.setdefault(key(neg(X)),(rid,di,ri,-1))
for x in current:add(int(x['id']),tuple(tuple(int(v) for v in row) for row in x['A']))
cm={r['id']:r for r in rows};got=[];new=[];next_id=len(current)
for n in nodes:
 i=n['id'];A=tuple(tuple(int(v) for v in row) for row in n['A']);L=tuple(tuple(int(v) for v in row) for row in n['L'])
 for wall in cm[i]['ordinary_walls']:
  An=mm(A,Sm[wall]);
  # L/M only needed for new representative bytes
  Wm=smat(WALL_ACTION[wall]);Ln=mm(Wm,L);M=mm(mm(tr(An),Q),An)
  con=[sum(M[ii][j] for j in range(3)) for ii in range(3)]+[-M[0][1],-M[0][2],-M[1][2]];j2=sum(v*v for v in con);e={'source':i,'wall':wall,'J2':str(j2)};hit=variants.get(key(An))
  if hit is not None:
   target,di,ri,sign=hit;e.update(status='HIT',target=target,deck_index=di,relabel_index=ri,sign=sign)
  else:
   target=next_id;next_id+=1;e.update(status='NEW',target=target);nn={'id':target,'path_from_C2':n.get('path_from_C2','')+wall,'kind':'DEPTH42','depth':42,'source':i,'arrival_wall':wall,'A':[[str(v) for v in row] for row in An],'L':[[str(v) for v in row] for row in Ln],'M':[[str(v) for v in row] for row in M],'J2':str(j2),'conorm6':[str(v) for v in con],'_layer':'d42-post-v05-cont24'};new.append(nn);current.append(nn);add(target,An)
  got.append(e)
if got!=expected_q['events']:fail.append('event_sequence_mismatch')
if new!=expected_q['new_depth42_nodes']:fail.append('new_nodes_mismatch')
counts=expected_q['counts']
if len(got)!=counts['ordinary_exits']:fail.append('exit_count')
if len(new)!=counts['new']:fail.append('new_count')
if next_id!=len(expected_q.get('representatives_after',current)): pass
man=json.load(open(EXT/'POSTV05_CONTINUATION_24_MANIFEST.json'));mism=[]
for e in man['entries']:
 p=EXT/e['path'];h=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
 if (not p.exists()) or p.stat().st_size!=e['size'] or h!=e['sha256']:mism.append(e['path'])
if mism:fail.append('manifest_mismatch')
srcsha=hashlib.sha256((EXT/'inputs/selling_toolkit_v05_0_source.zip').read_bytes()).hexdigest();whlsha=hashlib.sha256((EXT/'inputs/selling_toolkit-0.5.0-py3-none-any.whl').read_bytes()).hexdigest()
if srcsha!='d5e35f99cdb556a5f1d6c52355196aa592022527581f468bee1987c28384961b':fail.append('source_hash')
if whlsha!='17d61dec03024c6392cf4ce2362e13e7b37facb06314e37ab2c7a65ac3681e88':fail.append('wheel_hash')
cert=json.load(open(EXT/'POSTV05_OPPOSITE_PAIR_CONORM_OBSERVABLE_CERTIFICATE.json'));reg=cert['d41_hit_regression']
if reg['sorted_U_equal']!=reg['hits_checked'] or reg['failures']:fail.append('conorm_regression')
report={'version':'post-v0.5-continuation-24','status':'PASS' if not fail else 'FAIL','failed':fail,'fresh_reclassification':len(rows),'fresh_reclassification_seconds':class_sec,'ordinary_exits':len(got),'hits':sum(e['status']=='HIT' for e in got),'new':len(new),'index_last':next_id-1,'multiwall_count':sum(bool(r['multiwall_components']) for r in rows),'manifest_verified':f"{len(man['entries'])-len(mism)}/{len(man['entries'])}",'toolkit_source_sha256':srcsha,'toolkit_wheel_sha256':whlsha,'conorm_observable_d41_hits':f"{reg['sorted_U_equal']}/{reg['hits_checked']} PASS"}
raw=json.dumps(report,sort_keys=True,separators=(',',':')).encode();report['sha256_without_self']=hashlib.sha256(raw).hexdigest();json.dump(report,open(ROOT/'POSTV05_CONTINUATION_24_POSTSEAL_REPLAY_REPORT.json','w'),indent=2,sort_keys=True);open(ROOT/'POSTV05_CONTINUATION_24_POSTSEAL_REPLAY_REPORT.json','a').write('\n');print(json.dumps(report,indent=2,sort_keys=True));raise SystemExit(0 if not fail else 2)
