import sys,json,os,hashlib
from pathlib import Path
from collections import Counter
BASE=Path('/mnt/data/cont26/work'); sys.path.insert(0,str(BASE/'toolkit_src'))
from selling_toolkit.layers import tarjan_scc
OUT=BASE/'d42_gate'
def load(p):return json.load(open(p))
def write(name,obj):
 raw=json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode();h=hashlib.sha256(raw).hexdigest();obj=dict(obj);obj['sha256_without_self']=h;(OUT/name).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n');return h
old=load(BASE/'c24/POSTV05_DEPTH41_SCC_RECALCULATION.json');old_comps={c['scc']:c['ids'] for c in old['components']};id2old={i:s for s,ids in old_comps.items() for i in ids}
def ov(s):return -(s+1)
meta_vertices=[ov(s) for s in sorted(old_comps)]+list(range(12090,14088));meta_edges=[]
for e in old.get('condensation_edges',[]):meta_edges.append((ov(e['from']),ov(e['to'])))
q41=load(BASE/'c24/POSTV05_DEPTH41_10104_11754_QUOTIENT_SCC_TOOLKIT.json')
for e in q41['events']:
 t=int(e['target']);s=int(e['source'])
 if 12090<=t<=14087:
  assert s in id2old;meta_edges.append((ov(id2old[s]),t))
q42=load(OUT/'POSTV05_DEPTH42_12090_14087_QUOTIENT_TOOLKIT.json')
for e in q42['events']:
 s=int(e['source']);t=int(e['target'])
 if t in id2old:meta_edges.append((s,ov(id2old[t])))
 elif 12090<=t<=14087:meta_edges.append((s,t))
meta=tarjan_scc(meta_vertices,meta_edges);expanded=[]
for c in meta['components']:
 ids=[]
 for v in c['ids']:
  if v<0:ids.extend(old_comps[-v-1])
  else:ids.append(v)
 expanded.append(sorted(ids))
expanded.sort(key=lambda c:(-len(c),c[0]));cid={v:i for i,c in enumerate(expanded) for v in c};cond=Counter()
for a,b in meta_edges:
 aa=old_comps[-a-1][0] if a<0 else a;bb=old_comps[-b-1][0] if b<0 else b
 if cid[aa]!=cid[bb]:cond[(cid[aa],cid[bb])]+=1
res={'version':'post-v0.5-continuation-26','phase':'d42-scc-recalculation','status':'PASS-EXACT-SCC-RECALC','scope':'d23..d42 only; side layers d46-d52 and new d43 excluded','method':'exact old d23..d41 SCC contraction + all d41->d42 and d42->(d23..d42) quotient edges','vertex_count':sum(map(len,expanded)),'count':len(expanded),'sizes':[len(c) for c in expanded],'components':[{'scc':i,'size':len(c),'ids':c} for i,c in enumerate(expanded)],'condensation_edges':[{'from':a,'to':b,'count':n} for (a,b),n in sorted(cond.items())],'edge_summary':{'old_condensation_edges':len(old.get('condensation_edges',[])),'d41_to_d42':sum(12090<=int(e['target'])<=14087 for e in q41['events']),'d42_to_old':sum(int(e['target']) in id2old for e in q42['events']),'d42_to_d42':sum(12090<=int(e['target'])<=14087 for e in q42['events'])},'guards':['old d23..d41 SCC partition taken from sealed exact recalculation','side layers d51,d52 and new d43 nodes excluded from d23..d42 SCC scope','all relevant quotient edges included; multiwalls not expanded','Ucirc/chi/OEIS/v55 overlays excluded from graph edges']}
h=write('POSTV05_DEPTH42_SCC_RECALCULATION.json',res);print(json.dumps({'status':res['status'],'vertex_count':res['vertex_count'],'count':res['count'],'sizes':res['sizes'],'edge_summary':res['edge_summary'],'sha256_without_self':h},indent=2))
id2new={i:c['scc'] for c in res['components'] for i in c['ids']};cnt=Counter(id2new[int(n['source'])] for n in q42['new_depth43_nodes']);print('D43_SOURCE_SCC',dict(sorted(cnt.items())))
