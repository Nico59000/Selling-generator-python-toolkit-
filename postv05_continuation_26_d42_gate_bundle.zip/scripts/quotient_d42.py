import json,sys,time,hashlib
from pathlib import Path
BASE=Path('/mnt/data/cont26/work'); sys.path.insert(0,str(BASE/'toolkit_src'))
from selling_toolkit.fast_layers import quotient_layer_fast, FastHitRange
OUT=BASE/'d42_gate'
idx=json.load(open(BASE/'c25/POSTV05_REPRESENTATIVE_INDEX_AFTER_D51.json'))
reps=idx['representatives']; nodes=[reps[i] for i in range(12090,14088)]
cls=json.load(open(OUT/'POSTV05_DEPTH42_12090_14087_CLASSIFICATION.json'))['classifications']
seed=json.load(open(BASE/'c24/inputs/synthetic_invariant_Qa.seed.json'))
ranges=[
 FastHitRange('older_0_8221',0,8221), FastHitRange('d49',8222,8453), FastHitRange('d40',8454,9822),
 FastHitRange('d50',9823,10103), FastHitRange('d41',10104,11754), FastHitRange('d51',11755,12089),
 FastHitRange('d42',12090,14087), FastHitRange('d52-index-only',14088,14477),
]
t=time.time(); q=quotient_layer_fast(seed=seed,global_representatives=reps,nodes=nodes,classifications=cls,target_depth=43,kind='DEPTH43',layer_label='d43-post-v05-cont26',hit_ranges=ranges); elapsed=time.time()-t
obj={'version':'post-v0.5-continuation-26','phase':'d42-quotient','status':'PASS-1998/1998-EXACT-QUOTIENTED','engine':'selling-toolkit-0.5.0 FastCanonicalIndex int64 guarded','processing_order':'id','known_index_before':'0..14477','counts':q['counts'],'hit_buckets':q['hit_buckets'],'events':q['events'],'multiwalls':q['multiwalls'],'new_depth43_nodes':q['new_nodes'],'elapsed_seconds':elapsed,'guards':['complete post-d51 global index 0..14477 used','d52 14088..14477 treated as known index-only/HIT-only and not classified','new representatives inserted immediately for deterministic same-pass collapse','multiwall components retained/not expanded','next lateral layer classification not opened','public toolkit API/CLI/schema unchanged']}
raw=json.dumps(obj,sort_keys=True,separators=(',',':')).encode();obj['sha256_without_self']=hashlib.sha256(raw).hexdigest();(OUT/'POSTV05_DEPTH42_12090_14087_QUOTIENT_TOOLKIT.json').write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
idxout={'version':'post-v0.5-continuation-26','status':'INDEX-AFTER-D42','representatives':q['representatives_after']};raw=json.dumps(idxout,sort_keys=True,separators=(',',':')).encode();idxout['sha256_without_self']=hashlib.sha256(raw).hexdigest();(OUT/'POSTV05_REPRESENTATIVE_INDEX_AFTER_D42.json').write_text(json.dumps(idxout,indent=2,sort_keys=True)+'\n')
print(json.dumps({'counts':q['counts'],'hit_buckets':q['hit_buckets'],'new_range':[q['new_nodes'][0]['id'],q['new_nodes'][-1]['id']] if q['new_nodes'] else None,'index_last':len(q['representatives_after'])-1,'elapsed':elapsed},indent=2))
