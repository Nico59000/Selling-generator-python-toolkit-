import json,hashlib
from pathlib import Path
from collections import Counter,defaultdict
B=Path('/mnt/data/cont26/work'); OUT=B/'d42_gate'; R=OUT/'class_results'
reps=json.load(open(B/'c25/POSTV05_REPRESENTATIVE_INDEX_AFTER_D51.json'))['representatives']; comps=json.load(open(B/'c24/POSTV05_DEPTH41_SCC_RECALCULATION.json'))['components']; src={i:c['scc'] for c in comps for i in c['ids']}
s0=[i for i in range(12090,14088) if src.get(int(reps[i]['source']))==0]; assert len(s0)==1982
rows=[json.load(open(R/f'{i}.json')) for i in s0]; assert len(rows)==1982
s1=json.load(open(B/'reentry_extract/POSTV05_DEPTH42_SCC1_CLASSIFICATION.json'))['results']; assert len(s1)==16
# normalize SCC1 to same surface
rows += [{k:x[k] for k in ('id','ordinary_walls','multiwall_components','polynomials')} for x in s1]
rows.sort(key=lambda x:x['id']); assert [x['id'] for x in rows]==list(range(12090,14088))
ordinary=sum(len(x['ordinary_walls']) for x in rows); multis=[x for x in rows if x.get('multiwall_components')]
obj={'version':'post-v0.5-continuation-26','status':'PASS-EXACT-SCC-BY-SCC','gate':'d42 12090..14087','source_scc_counts':{'0':1982,'1':16},'classifications':rows,'counts':{'classes':1998,'ordinary_exits':ordinary,'multiwall_cells':len(multis),'multiwall_ids':[x['id'] for x in multis]}}
raw=json.dumps(obj,sort_keys=True,separators=(',',':')).encode();obj['sha256_without_self']=hashlib.sha256(raw).hexdigest();(OUT/'POSTV05_DEPTH42_12090_14087_CLASSIFICATION.json').write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
# append audit to prior 75 events
old=json.load(open(B/'c24/POSTV05_MULTIWALL_RECURRENCE_AUDIT_AFTER_D41.json')); events=list(old['events'])
for x in multis:
 for c in x['multiwall_components']:
  events.append({'depth':42,'factor':c['factor'],'id':x['id'],'layer':'d42-post-v0.5-cont26','source':'post-v0.5 continuation 26 exact SCC classification','walls':c['walls']})
fams=defaultdict(list)
for e in events:fams[e['factor']].append(e)
pair=Counter('/'.join(sorted(e['walls'])) for e in events)
family_rows=[]
for f,es in fams.items():
 family_rows.append({'factor':f,'event_count':len(es),'depths':sorted(set(e['depth'] for e in es)),'ids':[e['id'] for e in es],'wall_pair_counts':dict(sorted(Counter('/'.join(sorted(e['walls'])) for e in es).items()))})
family_rows.sort(key=lambda z:(min(z['depths']),z['factor']))
# opposite pairs from tetrahedral wall convention are gl, hm, kn; all other 12 adjacent
opp={'g/l','h/m','k/n'}
aud={'version':'post-v0.5-continuation-26','status':'PASS-EXACT-APPEND-ONLY-MULTIWALL-CENSUS-AFTER-D42','event_count':len(events),'events':events,'factor_family_count':len(family_rows),'families':family_rows,'pair_incidence':{'counts':dict(sorted((k.replace('/',''),v) for k,v in pair.items())),'adjacent_pairs_observed':len([k for k in pair if k not in opp]),'opposite_pairs_observed':len([k for k in pair if k in opp]),'opposite_pairs':sorted(k for k in pair if k in opp)},'new_d42':{'event_count':sum(len(x['multiwall_components']) for x in multis),'cell_count':len(multis),'ids':[x['id'] for x in multis]},'scope_guard':'append-only exact census through d42; no future extrapolation'}
raw=json.dumps(aud,sort_keys=True,separators=(',',':')).encode();aud['sha256_without_self']=hashlib.sha256(raw).hexdigest();(OUT/'POSTV05_MULTIWALL_RECURRENCE_AUDIT_AFTER_D42.json').write_text(json.dumps(aud,indent=2,sort_keys=True)+'\n')
print(json.dumps({'classes':1998,'ordinary':ordinary,'multi_cells':len(multis),'multi_ids':[x['id'] for x in multis],'events':len(events),'families':len(family_rows),'pairs':aud['pair_incidence'],'new_family_factors':[f['factor'] for f in family_rows if f['factor'] not in {z['factor'] for z in old['families']}]},indent=2))
