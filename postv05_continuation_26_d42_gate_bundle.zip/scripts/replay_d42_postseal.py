#!/usr/bin/env python3
import argparse,json,os,sys,zipfile,shutil,hashlib,time
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import sympy as sp
_G=None
def load(p):return json.load(open(p,encoding='utf-8'))
def init_worker(toolkit_dir,seed_path):
 global _G
 sys.path.insert(0,str(toolkit_dir));from selling_seed2d.chart import build_chart;from selling_seed2d.classifier import ExactBoundaryClassifier
 c=build_chart(load(seed_path));_G=ExactBoundaryClassifier(c.q,c.r,c.wall_vector,c.D0)
def worker(node):
 from sympy.core.cache import clear_cache
 try:
  L=sp.Matrix([[sp.Integer(v) for v in row] for row in node['L']]);c=_G.classify_cell(L)
  return {'id':int(node['id']),'ordinary_walls':list(c['ordinary_walls']),'multiwall_components':[{'factor':z['factor'],'walls':list(z['walls'])} for z in c.get('multiwall_components',[])],'polynomials':c.get('polynomials',{})}
 finally:clear_cache()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('root');ap.add_argument('--work',default='postseal_replay_work');ap.add_argument('--max-tasks',type=int,default=120);ap.add_argument('--workers',type=int,default=5);ap.add_argument('--finalize',action='store_true');a=ap.parse_args()
 root=Path(a.root).resolve();work=root/a.work;work.mkdir(exist_ok=True);res=work/'class_results';res.mkdir(exist_ok=True);tk=work/'toolkit_src'
 if not tk.exists():
  with zipfile.ZipFile(root/'inputs/selling_toolkit_v05_0_source.zip') as z:z.extractall(tk)
  # source zip has one top-level directory in some builds; locate package root
  cand=[p for p in [tk,*tk.iterdir()] if (p/'selling_seed2d').exists() and (p/'selling_toolkit').exists()]; assert cand; tk=cand[0]
 else:
  cand=[p for p in [tk,*tk.iterdir()] if p.is_dir() and (p/'selling_seed2d').exists() and (p/'selling_toolkit').exists()];tk=cand[0]
 idx=load(root/'POSTV05_REPRESENTATIVE_INDEX_AFTER_D42.json')['representatives'];nodes=idx[12090:14088];expected=load(root/'POSTV05_DEPTH42_12090_14087_CLASSIFICATION.json')['classifications']
 if not a.finalize:
  todo=[n for n in nodes if not (res/f"{n['id']}.json").exists()][:a.max_tasks];t=time.time()
  with ProcessPoolExecutor(max_workers=a.workers,initializer=init_worker,initargs=(tk,root/'inputs/synthetic_invariant_Qa.seed.json')) as ex:
   fs={ex.submit(worker,n):n for n in todo}
   for f in as_completed(fs):
    r=f.result();p=res/f"{r['id']}.json";tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(r,sort_keys=True,separators=(',',':'))+'\n');os.replace(tmp,p)
  done=sum((res/f"{n['id']}.json").exists() for n in nodes);print(json.dumps({'classified_this_call':len(todo),'done':done,'required':1998,'elapsed':time.time()-t}));return
 got=[]
 for n in nodes:
  p=res/f"{n['id']}.json";assert p.exists(),('missing',n['id']);got.append(load(p))
 expmap={x['id']:x for x in expected};fail=[]
 for x in got:
  e=expmap[x['id']]
  if x!=e:fail.append(x['id'])
 sys.path.insert(0,str(tk));from selling_toolkit.fast_layers import quotient_layer_fast,FastHitRange
 before=idx[:14478];seed=load(root/'inputs/synthetic_invariant_Qa.seed.json');ranges=[FastHitRange('older_0_8221',0,8221),FastHitRange('d49',8222,8453),FastHitRange('d40',8454,9822),FastHitRange('d50',9823,10103),FastHitRange('d41',10104,11754),FastHitRange('d51',11755,12089),FastHitRange('d42',12090,14087),FastHitRange('d52-index-only',14088,14477)]
 q=quotient_layer_fast(seed=seed,global_representatives=before,nodes=before[12090:14088],classifications=got,target_depth=43,kind='DEPTH43',layer_label='d43-post-v05-cont26',hit_ranges=ranges);expq=load(root/'POSTV05_DEPTH42_12090_14087_QUOTIENT_TOOLKIT.json')
 event_ok=q['events']==expq['events'];new_ok=q['new_nodes']==expq['new_depth43_nodes'];counts_ok=q['counts']==expq['counts']
 report={'status':'PASS' if not fail and event_ok and new_ok and counts_ok else 'FAIL','fresh_reclassification':len(got),'classification_failures':fail,'ordinary_exits':sum(len(x['ordinary_walls']) for x in got),'multiwall_count':sum(bool(x['multiwall_components']) for x in got),'quotient_counts':q['counts'],'event_sequence_exact':event_ok,'new_nodes_exact':new_ok,'counts_exact':counts_ok}
 (work/'POSTV05_CONTINUATION_26_POSTSEAL_REPLAY_REPORT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
