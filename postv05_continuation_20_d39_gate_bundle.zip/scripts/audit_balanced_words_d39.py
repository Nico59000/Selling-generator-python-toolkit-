import json, os, hashlib
from collections import Counter,defaultdict
from fractions import Fraction
ROOT='/mnt/data/post_v05'; OUT=ROOT+'/d39_gate'; os.makedirs(OUT,exist_ok=True)
idx=json.load(open(ROOT+'/d48_gate/POSTV05_REPRESENTATIVE_INDEX_AFTER_D48.json'))
reps=idx['representatives']; nodes=reps[7074:8222]
prev=json.load(open(ROOT+'/d38_gate/POSTV05_DEPTH38_SCC_RECALCULATION.json'))
src_scc={i:c['scc'] for c in prev['components'] for i in c['ids']}
A6=('g','h','k','l','m','n')
pairmap={'g':'GL','l':'GL','h':'HM','m':'HM','k':'KN','n':'KN'}
A3=('GL','HM','KN')

def linear_defect(seq,alphabet):
    n=len(seq); best=0; witness=None
    # all same-length factors entirely inside finite word
    for L in range(1,n+1):
        # prefix counters per letter
        for a in alphabet:
            vals=[]
            c=0
            pref=[0]
            for x in seq:
                c += (x==a); pref.append(c)
            vals=[pref[i+L]-pref[i] for i in range(0,n-L+1)]
            d=max(vals)-min(vals)
            if d>best:
                best=d; witness={'length':L,'letter':a,'min':min(vals),'max':max(vals)}
    return best,witness

def cyclic_defect(seq,alphabet):
    n=len(seq); best=0; witness=None
    if n<=1:return 0,None
    ext=seq+seq
    for L in range(1,n):
        for a in alphabet:
            pref=[0]
            c=0
            for x in ext:
                c+=(x==a);pref.append(c)
            vals=[pref[i+L]-pref[i] for i in range(n)]
            d=max(vals)-min(vals)
            if d>best:
                best=d; witness={'length':L,'letter':a,'min':min(vals),'max':max(vals)}
    return best,witness

def constant_gap(seq,alphabet):
    n=len(seq); detail={}; ok=True
    for a in alphabet:
        pos=[i for i,x in enumerate(seq) if x==a]
        if not pos:
            detail[a]={'count':0,'status':'absent'};continue
        gaps=[(pos[(j+1)%len(pos)]-pos[j])%n for j in range(len(pos))]
        # if one occurrence, modulo gives 0 but cyclic spacing should n
        if len(pos)==1:gaps=[n]
        good=len(set(gaps))==1
        detail[a]={'count':len(pos),'gaps':sorted(set(gaps)),'constant':good}
        ok &= good
    return ok,detail

def tijdeman3_counts(counts):
    vals=sorted(counts.values(),reverse=True)
    if len(vals)!=3:return False,None
    if len(set(vals))<3:return True,'two-rates-equal'
    # 4:2:1 exact proportionality
    if vals[0]==4*vals[2] and vals[1]==2*vals[2]:return True,'4:2:1'
    return False,None

rows=[]
for n in nodes:
    w=list(n['path_from_C2']); w3=[pairmap[x] for x in w]
    c6=Counter(w);c3=Counter(w3);N=len(w)
    ld6,lw6=linear_defect(w,A6);cd6,cw6=cyclic_defect(w,A6);cg6,cgd6=constant_gap(w,A6)
    ld3,lw3=linear_defect(w3,A3);cd3,cw3=cyclic_defect(w3,A3);cg3,cgd3=constant_gap(w3,A3)
    elig,why=tijdeman3_counts({a:c3[a] for a in A3})
    rows.append({
      'id':n['id'],'source':n.get('source'),'source_scc':src_scc.get(n.get('source')),'length':N,
      'word':n['path_from_C2'],
      'counts6':{a:c6[a] for a in A6},'rates6':{a:f'{c6[a]}/{N}' for a in A6},
      'finite_factor_defect6':ld6,'finite_factor_witness6':lw6,
      'periodic_closure_defect6':cd6,'periodic_closure_witness6':cw6,
      'periodic_closure_balanced6':cd6<=1,'periodic_closure_constant_gap6':cg6,
      'opposite_pair_projection':''.join({'GL':'A','HM':'B','KN':'C'}[x] for x in w3),
      'counts3':{a:c3[a] for a in A3},'rates3':{a:f'{c3[a]}/{N}' for a in A3},
      'finite_factor_defect3':ld3,'finite_factor_witness3':lw3,
      'periodic_closure_defect3':cd3,'periodic_closure_witness3':cw3,
      'periodic_closure_balanced3':cd3<=1,'periodic_closure_constant_gap3':cg3,
      'tijdeman_rate_eligible3':elig,'tijdeman_reason3':why,
    })

def dist(key):return dict(sorted(Counter(r[key] for r in rows).items(),key=lambda kv:str(kv[0])))
summary={
 'version':'post-v0.5-continuation-20','phase':'balanced-word applicability audit on d39 path_from_C2','status':'PASS-DIAGNOSTIC-SEPARATED','source_document':'Altman-Gaujal-Hordijk, Balanced Sequences and Optimal Routing, INRIA RR-3180 (1997)',
 'scope':{'ids':[7074,8221],'count':len(rows),'source_scc_counts':dict(Counter(r['source_scc'] for r in rows)),'word_lengths':dict(Counter(r['length'] for r in rows))},
 'typing_guards':[
   'path_from_C2 is a finite Selling-generator word, not an infinite routing sequence',
   'finite_factor_defect is a local factor diagnostic only',
   'periodic_closure w^infinity is an explicit diagnostic construction, not a source-native identification',
   'Tijdeman N=3 theorem is applied only to the 3-letter opposite-edge-pair projection rate tuple',
   'routing optimality is NOT imported: no queue/event-graph/multimodular cost morphism is currently certified',
   'general distinct-rate N-letter characterization in the paper is conjectural beyond its proved special cases'
 ],
 'six_letter':{
   'finite_factor_balanced_count':sum(r['finite_factor_defect6']<=1 for r in rows),
   'periodic_closure_balanced_count':sum(r['periodic_closure_balanced6'] for r in rows),
   'periodic_closure_constant_gap_count':sum(r['periodic_closure_constant_gap6'] for r in rows),
   'finite_defect_distribution':dist('finite_factor_defect6'),
   'periodic_defect_distribution':dist('periodic_closure_defect6'),
   'min_periodic_defect':min(r['periodic_closure_defect6'] for r in rows),
   'min_periodic_defect_ids':[r['id'] for r in rows if r['periodic_closure_defect6']==min(x['periodic_closure_defect6'] for x in rows)]
 },
 'opposite_pair_projection_GL_HM_KN':{
   'finite_factor_balanced_count':sum(r['finite_factor_defect3']<=1 for r in rows),
   'periodic_closure_balanced_count':sum(r['periodic_closure_balanced3'] for r in rows),
   'periodic_closure_constant_gap_count':sum(r['periodic_closure_constant_gap3'] for r in rows),
   'tijdeman_rate_eligible_count':sum(r['tijdeman_rate_eligible3'] for r in rows),
   'tijdeman_rate_reason_counts':dict(Counter(r['tijdeman_reason3'] for r in rows if r['tijdeman_rate_eligible3'])),
   'finite_defect_distribution':dist('finite_factor_defect3'),
   'periodic_defect_distribution':dist('periodic_closure_defect3'),
   'min_periodic_defect':min(r['periodic_closure_defect3'] for r in rows),
   'min_periodic_defect_ids':[r['id'] for r in rows if r['periodic_closure_defect3']==min(x['periodic_closure_defect3'] for x in rows)]
 }
}
# Cross counts SCC
for sec,key in [('six_letter','periodic_closure_balanced6'),('opposite_pair_projection_GL_HM_KN','periodic_closure_balanced3')]:
 summary[sec]['balanced_by_source_scc']={str(s):sum(r[key] for r in rows if r['source_scc']==s) for s in [0,1]}
obj={'summary':summary,'rows':rows}
raw=json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode();obj['sha256_without_self']=hashlib.sha256(raw).hexdigest()
with open(OUT+'/POSTV05_D39_BALANCED_WORD_APPLICABILITY_AUDIT.json','w') as f:json.dump(obj,f,indent=2,sort_keys=True);f.write('\n')
# compact text
with open(OUT+'/POSTV05_D39_BALANCED_WORD_APPLICABILITY_AUDIT.txt','w') as f:
 f.write(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary,indent=2,sort_keys=True))
