import json,hashlib
from collections import Counter,defaultdict
P='/mnt/data/post_v05/d39_gate/POSTV05_D39_BALANCED_WORD_APPLICABILITY_AUDIT.json'
d=json.load(open(P)); rows=d['rows']
A6='ghklmn'; pairmap={'g':'A','l':'A','h':'B','m':'B','k':'C','n':'C'}

def cyc_letter_def(seq,a):
 n=len(seq); ext=seq+seq; pref=[0]
 c=0
 for x in ext:
  c+=(x==a);pref.append(c)
 best=0
 for L in range(1,n):
  vals=[pref[i+L]-pref[i] for i in range(n)]
  best=max(best,max(vals)-min(vals))
 return best

def finite_letter_def(seq,a):
 n=len(seq); pref=[0];c=0
 for x in seq:c+=(x==a);pref.append(c)
 best=0
 for L in range(1,n+1):
  vals=[pref[i+L]-pref[i] for i in range(n-L+1)]
  best=max(best,max(vals)-min(vals))
 return best

def prefix_disc_num(seq,a):
 n=len(seq); total=seq.count(a); c=0;best=0;where=0;sgn=0
 for k,x in enumerate(seq,1):
  c+=(x==a); val=n*c-k*total
  if abs(val)>best:best=abs(val);where=k;sgn=1 if val>0 else -1
 return best,where,sgn,total,n

def w3_occurrences(seq3):
 # pattern X Y X Z X Y X with X,Y,Z distinct; count cyclic and linear
 n=len(seq3)
 def good(s):return len(s)==7 and s[0]==s[2]==s[4]==s[6] and s[1]==s[5] and len({s[0],s[1],s[3]})==3
 lin=sum(good(seq3[i:i+7]) for i in range(max(0,n-6)))
 ext=seq3+seq3[:6];cyc=sum(good(ext[i:i+7]) for i in range(n))
 return lin,cyc
for r in rows:
 w=r['word']; w3=''.join(pairmap[x] for x in w)
 d6={a:cyc_letter_def(w,a) for a in A6}; f6={a:finite_letter_def(w,a) for a in A6}
 d3={a:cyc_letter_def(w3,a) for a in 'ABC'}; f3={a:finite_letter_def(w3,a) for a in 'ABC'}
 r['support_cyclic_defects6']=d6;r['support_finite_defects6']=f6
 r['regular_support_count6_periodic']=sum(x<=1 for x in d6.values())
 r['regular_support_count6_finite']=sum(x<=1 for x in f6.values())
 r['support_cyclic_defects3']=d3;r['support_finite_defects3']=f3
 r['regular_support_count3_periodic']=sum(x<=1 for x in d3.values())
 r['regular_support_count3_finite']=sum(x<=1 for x in f3.values())
 r['prefix_discrepancy6']={a:{'numerator':prefix_disc_num(w,a)[0],'denominator':len(w),'prefix':prefix_disc_num(w,a)[1]} for a in A6}
 r['max_prefix_discrepancy6_num']=max(v['numerator'] for v in r['prefix_discrepancy6'].values())
 lin,cyc=w3_occurrences(w3);r['W3_abacaba_isomorphic_linear_occurrences']=lin;r['W3_abacaba_isomorphic_cyclic_occurrences']=cyc
s=d['summary']
s['six_letter']['regular_support_count_periodic_distribution']=dict(sorted(Counter(r['regular_support_count6_periodic'] for r in rows).items()))
s['six_letter']['regular_support_count_finite_distribution']=dict(sorted(Counter(r['regular_support_count6_finite'] for r in rows).items()))
s['six_letter']['per_letter_periodic_regular_counts']={a:sum(r['support_cyclic_defects6'][a]<=1 for r in rows) for a in A6}
s['six_letter']['max_prefix_discrepancy_num_distribution']=dict(sorted(Counter(r['max_prefix_discrepancy6_num'] for r in rows).items()))
s['opposite_pair_projection_GL_HM_KN']['regular_support_count_periodic_distribution']=dict(sorted(Counter(r['regular_support_count3_periodic'] for r in rows).items()))
s['opposite_pair_projection_GL_HM_KN']['regular_support_count_finite_distribution']=dict(sorted(Counter(r['regular_support_count3_finite'] for r in rows).items()))
s['opposite_pair_projection_GL_HM_KN']['per_pair_periodic_regular_counts']={a:sum(r['support_cyclic_defects3'][a]<=1 for r in rows) for a in 'ABC'}
s['opposite_pair_projection_GL_HM_KN']['W3_template_words_with_linear_occurrence']=sum(r['W3_abacaba_isomorphic_linear_occurrences']>0 for r in rows)
s['opposite_pair_projection_GL_HM_KN']['W3_template_words_with_cyclic_occurrence']=sum(r['W3_abacaba_isomorphic_cyclic_occurrences']>0 for r in rows)
s['opposite_pair_projection_GL_HM_KN']['W3_template_total_linear_occurrences']=sum(r['W3_abacaba_isomorphic_linear_occurrences'] for r in rows)
s['opposite_pair_projection_GL_HM_KN']['W3_template_total_cyclic_occurrences']=sum(r['W3_abacaba_isomorphic_cyclic_occurrences'] for r in rows)
d['summary']=s
d.pop('sha256_without_self',None);raw=json.dumps(d,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode();d['sha256_without_self']=hashlib.sha256(raw).hexdigest()
with open(P,'w') as f:json.dump(d,f,indent=2,sort_keys=True);f.write('\n')
with open('/mnt/data/post_v05/d39_gate/POSTV05_D39_BALANCED_WORD_APPLICABILITY_AUDIT.txt','w') as f:f.write(json.dumps(s,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:s[k] for k in ['six_letter','opposite_pair_projection_GL_HM_KN']},indent=2,sort_keys=True))
