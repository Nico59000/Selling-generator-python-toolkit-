import json,itertools,hashlib
from collections import Counter,defaultdict
P='/mnt/data/post_v05/d39_gate/POSTV05_D39_BALANCED_WORD_APPLICABILITY_AUDIT.json'
O='/mnt/data/post_v05/d39_gate/POSTV05_D39_HUBERT_PARTITION_DIAGNOSTIC.json'
d=json.load(open(P)); rows=d['rows']; alphabet='ghklmn'

def cyclic_bal(seq):
    L=len(seq)
    if L<=1:return True,0
    arr=[1 if x=='1' else 0 for x in seq]
    arr2=arr+arr
    pref=[0]
    for x in arr2: pref.append(pref[-1]+x)
    worst=0
    for m in range(1,L+1):
        vals=[pref[i+m]-pref[i] for i in range(L)]
        z=max(vals)-min(vals); worst=max(worst,z)
        if worst>1:return False,worst
    return True,worst

def constgap_subseq(sub):
    # periodic closure of subsequence; each letter has constant cyclic gaps
    L=len(sub)
    if L<=1:return True
    for a in sorted(set(sub)):
        pos=[i for i,x in enumerate(sub) if x==a]
        if len(pos)<=1: continue
        gaps=[(pos[(j+1)%len(pos)]-pos[j])%L for j in range(len(pos))]
        if len(set(gaps))!=1:return False
    return True
parts=[]
# canonical by requiring g in A; exclude all
for mask in range(1,1<<len(alphabet)):
    A={alphabet[i] for i in range(len(alphabet)) if mask>>i&1}
    if 'g' not in A or len(A)==6: continue
    B=set(alphabet)-A
    parts.append((''.join(sorted(A)),''.join(sorted(B))))
assert len(parts)==31
part_counts=Counter(); full_hubert=Counter(); any_bin=0; any_full=0; rows_out=[]
for r in rows:
    w=r['word']; cands=[]; full=[]
    for A_s,B_s in parts:
        A=set(A_s); b=''.join('1' if x in A else '0' for x in w)
        ok,defect=cyclic_bal(b)
        if ok:
            cands.append((A_s,B_s)); part_counts[(A_s,B_s)]+=1
            sa=''.join(x for x in w if x in A); sb=''.join(x for x in w if x not in A)
            if constgap_subseq(sa) and constgap_subseq(sb):
                full.append((A_s,B_s)); full_hubert[(A_s,B_s)]+=1
    if cands:any_bin+=1
    if full:any_full+=1
    rows_out.append({'id':r['id'],'source_scc':r['source_scc'],'balanced_binary_partitions':cands,'hubert_form_partitions':full})
out={
 'version':'post-v0.5-continuation-20','phase':'Hubert decomposition diagnostic on periodic closures of d39 finite words',
 'scope':{'words':len(rows),'alphabet':list(alphabet),'canonical_nontrivial_bipartitions':31},
 'typing_guard':['Theorem 2.15 concerns balanced nonperiodic infinite sequences; d39 words are finite.','Here w^infinity and all alphabet bipartitions are diagnostic constructions only.','A Hubert-form hit does not imply the original finite Selling word is balanced or source-native periodic.'],
 'summary':{
   'words_with_any_balanced_binary_partition':any_bin,
   'words_with_any_Hubert_form_partition':any_full,
   'partition_hit_counts':[{'A':a,'B':b,'balanced_binary_count':part_counts[(a,b)],'hubert_form_count':full_hubert[(a,b)]} for a,b in parts if part_counts[(a,b)] or full_hubert[(a,b)]]
 },
 'rows':rows_out
}
raw=json.dumps(out,sort_keys=True,separators=(',',':')).encode();out['sha256_without_self']=hashlib.sha256(raw).hexdigest()
json.dump(out,open(O,'w'),indent=2,sort_keys=True)
print(json.dumps(out['summary'],indent=2))
