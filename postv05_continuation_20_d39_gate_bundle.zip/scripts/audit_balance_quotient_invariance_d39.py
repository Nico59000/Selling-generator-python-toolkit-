import json,collections,hashlib
Q='/mnt/data/post_v05/d39_gate/POSTV05_DEPTH39_7074_8221_QUOTIENT_SCC_TOOLKIT.json'
I='/mnt/data/post_v05/d39_gate/POSTV05_REPRESENTATIVE_INDEX_AFTER_D39.json'
A='/mnt/data/post_v05/d39_gate/POSTV05_D39_BALANCED_WORD_APPLICABILITY_AUDIT.json'
O='/mnt/data/post_v05/d39_gate/POSTV05_D39_BALANCE_QUOTIENT_INVARIANCE_AUDIT.json'
q=json.load(open(Q)); idx=json.load(open(I))['representatives']; aud={r['id']:r for r in json.load(open(A))['rows']}; mp={n['id']:n for n in idx}; letters='ghklmn'; pair={'g':'A','l':'A','h':'B','m':'B','k':'C','n':'C'}

def cyclic_def(word,alphabet):
 L=len(word)
 if not L:return 0
 s=word+word; worst=0
 for a in alphabet:
  arr=[1 if x==a else 0 for x in s];pref=[0]
  for x in arr:pref.append(pref[-1]+x)
  for m in range(1,L+1):
   vals=[pref[i+m]-pref[i] for i in range(L)]; worst=max(worst,max(vals)-min(vals))
 return worst
memo={}
def metrics(id):
 if id in memo:return memo[id]
 if id in aud:
  r=aud[id]; z={'length':r['length'],'rates6':tuple(r['counts6'][x] for x in letters),'rates3':tuple(r['counts3'][x] for x in ('GL','HM','KN')),'defect6':r['periodic_closure_defect6'],'defect3':r['periodic_closure_defect3']};memo[id]=z;return z
 w=mp[id].get('path_from_C2',''); p=''.join(pair[x] for x in w); z={'length':len(w),'rates6':tuple(w.count(x) for x in letters),'rates3':tuple(p.count(x) for x in 'ABC'),'defect6':cyclic_def(w,letters),'defect3':cyclic_def(p,'ABC')};memo[id]=z;return z
hits=[e for e in q['events'] if e['status']=='HIT']; stats=collections.Counter(); examples={}
for e in hits:
 s=metrics(e['source']); t=metrics(e['target'])
 comps={'length':s['length']==t['length'],'rates6':s['rates6']==t['rates6'],'rates3':s['rates3']==t['rates3'],'defect6':s['defect6']==t['defect6'],'defect3':s['defect3']==t['defect3']}
 for k,v in comps.items():stats[k+'_equal' if v else k+'_different']+=1
 for k,v in comps.items():
  if not v and k not in examples: examples[k]={'event':e,'source_metrics':s,'target_metrics':t}
out={'version':'post-v0.5-continuation-20','phase':'balance diagnostics under exact canonical quotient hits','hit_event_count':len(hits),'comparisons':dict(stats),'first_counterexamples':examples,'decision':'BALANCE-WORD-STATISTICS-ARE-PATH-DEPENDENT/NOT-QUOTIENT-INVARIANTS' if any(stats[k]>0 for k in stats if k.endswith('_different')) else 'NO-COUNTEREXAMPLE-IN-AUDITED-HITS','guard':'This tests path_from_C2 combinatorial diagnostics only. Matrix-class quotient equivalence is not asserted to preserve path spelling.'}
raw=json.dumps(out,sort_keys=True,separators=(',',':')).encode();out['sha256_without_self']=hashlib.sha256(raw).hexdigest();json.dump(out,open(O,'w'),indent=2,sort_keys=True);print(json.dumps(out,indent=2)[:12000])
