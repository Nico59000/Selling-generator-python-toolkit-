import json,hashlib,collections
R='/mnt/data/post_v05/d39_gate/POSTV05_MULTIWALL_RECURRENCE_AUDIT_AFTER_D39.json'; I='/mnt/data/post_v05/d39_gate/POSTV05_REPRESENTATIVE_INDEX_AFTER_D39.json'; O='/mnt/data/post_v05/d39_gate/POSTV05_MULTIWALL_BALANCED_WORD_CROSS_AUDIT.json'
r=json.load(open(R)); idx={n['id']:n for n in json.load(open(I))['representatives']}; pair={'g':'A','l':'A','h':'B','m':'B','k':'C','n':'C'}
def cyclic_def(seq,alph):
 n=len(seq)
 if n<2:return 0
 s=seq+seq; worst=0
 for a in alph:
  pref=[0]
  for x in s:pref.append(pref[-1]+(x==a))
  for L in range(1,n+1):
   vals=[pref[i+L]-pref[i] for i in range(n)];worst=max(worst,max(vals)-min(vals))
 return worst
def tijd(c):
 vals=list(c.values());
 if len(set(vals))<3:return True,'two-rates-equal'
 s=sum(vals); sv=sorted(vals)
 if s%7==0 and sv==[s//7,2*s//7,4*s//7]:return True,'4:2:1'
 return False,None
def w3(seq):
 n=len(seq);ext=seq+seq[:6]
 def good(s):return len(s)==7 and s[0]==s[2]==s[4]==s[6] and s[1]==s[5] and len({s[0],s[1],s[3]})==3
 return sum(good(seq[i:i+7]) for i in range(max(0,n-6))),sum(good(ext[i:i+7]) for i in range(n))
rows=[]
for e in r['events']:
 n=idx[e['id']]; word=n.get('path_from_C2',''); p=''.join(pair[x] for x in word); c3={a:p.count(a) for a in 'ABC'};el,why=tijd(c3);lin,cyc=w3(p)
 rows.append({'id':e['id'],'depth':e['depth'],'factor':e['factor'],'walls':e['walls'],'length':len(word),'defect6_periodic':cyclic_def(word,'ghklmn'),'defect3_periodic':cyclic_def(p,'ABC'),'counts3':c3,'tijdeman_rate_eligible3':el,'tijdeman_reason3':why,'W3_linear':lin,'W3_cyclic':cyc})
by=[]
for f in sorted(set(x['factor'] for x in rows)):
 z=[x for x in rows if x['factor']==f]
 by.append({'factor':f,'events':len(z),'depths':sorted(set(x['depth'] for x in z)),'lengths':dict(collections.Counter(x['length'] for x in z)),'defect6_distribution':dict(collections.Counter(x['defect6_periodic'] for x in z)),'defect3_distribution':dict(collections.Counter(x['defect3_periodic'] for x in z)),'tijdeman_rate_eligible3':sum(x['tijdeman_rate_eligible3'] for x in z),'W3_linear_positive':sum(x['W3_linear']>0 for x in z),'W3_cyclic_positive':sum(x['W3_cyclic']>0 for x in z)})
out={'version':'post-v0.5-continuation-20','phase':'balanced-word diagnostics cross-audited on exact multiwall recurrence registry','status':'PASS-EXACT-PATH-DIAGNOSTIC/SEPARATED','event_count':len(rows),'factor_family_count':len(by),'rows':rows,'by_factor':by,'decision':'NO-BALANCED-WORD-IDENTIFICATION-PROMOTED','guard':'Metrics are computed on path_from_C2 spellings and periodic diagnostic closures; they are path-dependent and not quotient invariants.'};raw=json.dumps(out,sort_keys=True,separators=(',',':')).encode();out['sha256_without_self']=hashlib.sha256(raw).hexdigest();json.dump(out,open(O,'w'),indent=2,sort_keys=True)
print(json.dumps(by,indent=2))
