import json,hashlib,collections
src='/mnt/data/post_v05/d48_gate/POSTV05_MULTIWALL_RECURRENCE_AUDIT_D23_D48.json'
clf='/mnt/data/post_v05/d39_gate/POSTV05_DEPTH39_7074_8221_CLASSIFICATION_SCC.json'
out='/mnt/data/post_v05/d39_gate/POSTV05_MULTIWALL_RECURRENCE_AUDIT_AFTER_D39.json'
d=json.load(open(src)); c=json.load(open(clf)); events=list(d['events'])
for r in c['results']:
 for z in r.get('multiwall_components',[]):
  events.append({'depth':39,'factor':z['factor'],'id':r['id'],'layer':'d39-post-v0.5-cont20','source':'post-v0.5 continuation 20 exact SCC classification','walls':z['walls']})
# sort canonical by depth/id/factor
# keep side depth48 later naturally by depth sort
events=sorted(events,key=lambda e:(e['depth'],e['id'],e['factor'],tuple(e['walls'])))
fam=collections.defaultdict(list)
for e in events:fam[e['factor']].append(e)
families=[]
for f,evs in sorted(fam.items(),key=lambda kv:(-len(kv[1]),kv[0])):
 pc=collections.Counter('/'.join(sorted(e['walls'])) for e in evs)
 families.append({'factor':f,'event_count':len(evs),'depths':sorted(set(e['depth'] for e in evs)),'layers':sorted(set(e['layer'] for e in evs)),'ids':[e['id'] for e in evs],'wall_pair_counts':dict(sorted(pc.items()))})
allpairs=collections.Counter('/'.join(sorted(e['walls'])) for e in events)
letters='ghklmn'; pairs=[''.join(p) for p in __import__('itertools').combinations(letters,2)]
opp={'gl','hm','kn'}
pairrows=[(p,allpairs['/'.join(p)]) for p in pairs]
adj_obs=sum(1 for p,n in pairrows if p not in opp and n)
opp_obs=sum(1 for p,n in pairrows if p in opp and n)
outd={
 'version':'post-v0.5-continuation-20','status':'PASS-PROVEN-EXACT-INCIDENCE-CENSUS-WITHIN-AUDITED-CORPUS-THROUGH-D39-CURRENT-AND-SIDE-D48',
 'event_count':len(events),'factor_family_count':len(families),'events':events,'families':families,
 'factor345':next({'factor':x['factor'],'event_count':x['event_count'],'depths':x['depths'],'status':'CONTEXT/PENDING-MORPHISM for 345 <-> (3,4,5); recurrence exact, geometric interpretation not promoted'} for x in families if '345*r' in x['factor']),
 'pair_incidence':{'all_15_wall_pairs':pairrows,'observed_distinct_pairs':sum(bool(n) for _,n in pairrows),'adjacent_pairs_total':12,'adjacent_pairs_observed':adj_obs,'opposite_pairs':[x for x in pairrows if x[0] in opp],'opposite_pairs_observed':opp_obs,'verdict':f'{adj_obs}/12 tetrahedral-adjacent edge pairs observed; {opp_obs}/3 opposite edge pairs observed'},
 'tetrahedral_wall_edge_map':d['tetrahedral_wall_edge_map'],
 'null_multiwall_scopes':d['null_multiwall_scopes'],
 'typing_guards':d['typing_guards']+['new d39 events are appended; earlier sealed events are not rewritten'],
 'scope_guard':'Exact append-only census over all previously audited sealed/classified representatives plus current d39 7074..8221; side d48 remains included. This is not an extrapolation theorem for future depths.'
}
raw=json.dumps(outd,sort_keys=True,separators=(',',':')).encode();outd['sha256_without_self']=hashlib.sha256(raw).hexdigest()
json.dump(outd,open(out,'w'),indent=2,sort_keys=True);print(json.dumps({'events':outd['event_count'],'families':[(x['factor'],x['event_count'],x['depths']) for x in families],'pairs':outd['pair_incidence']},indent=2))
