#!/usr/bin/env python3
import json,hashlib,tempfile,zipfile,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def load(p):return json.load(open(p,encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
bad=[]; rows=[]
for p in sorted((R/'chunks').glob('d39_scc*.json')):
 d=load(p);x=dict(d);h=x.pop('sha256_without_self',None); raw=json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
 if hashlib.sha256(raw).hexdigest()!=h:bad.append('chunk_hash:'+p.name)
 rows+=d['results']
rows.sort(key=lambda x:x['id']);clf=load(R/'POSTV05_DEPTH39_7074_8221_CLASSIFICATION_SCC.json')
if rows!=clf['results']:bad.append('chunk_assembly')
if [x['id'] for x in rows]!=list(range(7074,8222)):bad.append('coverage')
# destructive fresh source extraction and complete exact reclassification
with tempfile.TemporaryDirectory() as td:
 zipfile.ZipFile(R/'inputs/selling_toolkit_v05_0_source.zip').extractall(td); base=Path(td); src=base/'src' if (base/'src').exists() else base;sys.path.insert(0,str(src))
 from selling_toolkit.layers import classify_exact
 seed=load(R/'inputs/synthetic_invariant_Qa.seed.json'); reps=load(R/'inputs/POSTV05_REPRESENTATIVE_INDEX_AFTER_D48.json')['representatives']; nodes=reps[7074:8222]
 direct=classify_exact(nodes,seed,workers=5)
 if direct!=rows:bad.append('full_reclassification_mismatch')
q=load(R/'POSTV05_DEPTH39_7074_8221_QUOTIENT_SCC_TOOLKIT.json');ind=load(R/'POSTV05_DEPTH39_INDEPENDENT_VERIFICATION_REPORT.json');scc=load(R/'POSTV05_DEPTH39_SCC_RECALCULATION.json');bal=load(R/'POSTV05_BALANCED_SEQUENCES_DOCUMENT_APPLICABILITY_REGISTRY.json');rec=load(R/'POSTV05_MULTIWALL_RECURRENCE_AUDIT_AFTER_D39.json');tool=load(R/'POSTV05_CONTINUATION_20_TOOLKIT_FREEZE_AUDIT.json')
if q['counts']!={'classes':1148,'ordinary_exits':4222,'hits':2853,'new':1369,'multiwall_cells':3}:bad.append('quotient_counts')
if q['hit_buckets']!={'d38':1405,'d39':1121,'d48':1,'same-pass':326}:bad.append('hit_buckets')
if ind['status']!='PASS' or not ind['checks']['event_sequence_matches_fast'] or not ind['checks']['new_nodes_match_fast']:bad.append('independent_oracle')
if scc['sizes']!=[6485,98,2,1,1,1,1]:bad.append('scc_sizes')
if rec['event_count']!=57 or rec['factor_family_count']!=5 or rec['pair_incidence']['adjacent_pairs_observed']!=12 or rec['pair_incidence']['opposite_pairs_observed']!=0:bad.append('recurrence')
if bal['d39_results']['raw6']['periodic_closure_balanced']!=0 or bal['d39_results']['opposite_pair_projection3']['periodic_closure_balanced']!=0 or bal['d39_results']['opposite_pair_projection3']['Tijdeman_rate_eligible']!=481:bad.append('balanced_overlay')
if bal['d39_results']['Hubert_partition_diagnostic']['words_with_any_Hubert_form_partition']!=0:bad.append('hubert_diag')
if bal['d39_results']['quotient_invariance_audit']['decision']!='BALANCE-WORD-STATISTICS-ARE-PATH-DEPENDENT/NOT-QUOTIENT-INVARIANTS':bad.append('balance_quotient_guard')
mx=load(R/'POSTV05_MULTIWALL_BALANCED_WORD_CROSS_AUDIT.json')
if mx['event_count']!=57 or mx['factor_family_count']!=5:bad.append('multiwall_balance_cross')
if tool['status']!='PASS-TOOLKIT-0.5.0-FROZEN-UNCHANGED':bad.append('toolkit_freeze')
if sha(R/'external_sources/Balanced_sequences_and_optimal_routing_1997.pdf')!='2b667dae6d8f3b308cb7cce73ed22502e6a78bb918782bac0223f7830cbe278c':bad.append('external_pdf_hash')
print(json.dumps({'status':'PASS' if not bad else 'FAIL','failed':bad,'reclassification':len(rows),'ordinary_exits':4222,'hits':2853,'new':1369,'index_last':9822,'scc_sizes':[6485,98,2,1,1,1,1],'multiwall_events_registry':57,'factor_families':5,'balanced_raw6':0,'balanced_pair3':0,'Tijdeman_rate_eligible':481,'Hubert_form_hits':0},sort_keys=True));raise SystemExit(1 if bad else 0)
