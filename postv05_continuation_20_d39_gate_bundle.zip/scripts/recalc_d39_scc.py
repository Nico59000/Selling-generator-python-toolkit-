import sys,json,os,hashlib
sys.path.insert(0,'/mnt/data/post_v05/rel/src')
from selling_toolkit.layers import tarjan_scc
ROOT='/mnt/data/post_v05'; OUT=ROOT+'/d39_gate'
def load(p):
    with open(p,'r') as f:return json.load(f)
def write(name,obj):
    raw=json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode(); h=hashlib.sha256(raw).hexdigest(); obj=dict(obj); obj['sha256_without_self']=h
    with open(os.path.join(OUT,name),'w') as f:json.dump(obj,f,indent=2,sort_keys=True);f.write('\n')
    return h
old=load(ROOT+'/d38_gate/POSTV05_DEPTH38_SCC_RECALCULATION.json')
old_comps={c['scc']:c['ids'] for c in old['components']}
id2old={i:s for s,ids in old_comps.items() for i in ids}
assert len(id2old)==5441,len(id2old)
def ov(s):return -(s+1)
meta_vertices=[ov(s) for s in sorted(old_comps)] + list(range(7074,8222))
meta_edges=[]
for e in old.get('condensation_edges',[]):meta_edges.append((ov(e['from']),ov(e['to'])))
# d38 -> d39 incoming edges
q38=load(ROOT+'/d38_gate/POSTV05_DEPTH38_5946_6886_QUOTIENT_SCC_TOOLKIT.json')
for e in q38['events']:
    t=int(e['target']);s=int(e['source'])
    if 7074<=t<=8221:
        assert s in id2old
        meta_edges.append((ov(id2old[s]),t))
# d39 -> old/d39 edges. Exclude d46/d47/d48/d49 and new d40 outside scope.
q39=load(OUT+'/POSTV05_DEPTH39_7074_8221_QUOTIENT_SCC_TOOLKIT.json')
for e in q39['events']:
    s=int(e['source']);t=int(e['target'])
    if t in id2old:meta_edges.append((s,ov(id2old[t])))
    elif 7074<=t<=8221:meta_edges.append((s,t))
meta=tarjan_scc(meta_vertices,meta_edges)
expanded=[]
for c in meta['components']:
    ids=[]
    for v in c['ids']:
        if v<0:ids.extend(old_comps[-v-1])
        else:ids.append(v)
    expanded.append(sorted(ids))
expanded.sort(key=lambda c:(-len(c),c[0]))
cid={v:i for i,c in enumerate(expanded) for v in c}
from collections import Counter
cond=Counter()
for a,b in meta_edges:
    aa=old_comps[-a-1][0] if a<0 else a
    bb=old_comps[-b-1][0] if b<0 else b
    if cid[aa]!=cid[bb]:cond[(cid[aa],cid[bb])]+=1
res={'version':'post-v0.5-continuation-20','phase':'d39-scc-recalculation','status':'PASS-EXACT-SCC-RECALC','scope':'d23..d39 only; d46/d47/d48/d49/d40 excluded','method':'exact old d23..d38 SCC contraction + all d38->d39 and d39->(d23..d39) quotient edges','vertex_count':sum(map(len,expanded)),'count':len(expanded),'sizes':[len(c) for c in expanded],'components':[{'scc':i,'size':len(c),'ids':c} for i,c in enumerate(expanded)],'condensation_edges':[{'from':a,'to':b,'count':n} for (a,b),n in sorted(cond.items())],'edge_summary':{'old_condensation_edges':len(old.get('condensation_edges',[])),'d38_to_d39':sum(7074<=int(e['target'])<=8221 for e in q38['events']),'d39_to_old':sum(int(e['target']) in id2old for e in q39['events']),'d39_to_d39':sum(7074<=int(e['target'])<=8221 for e in q39['events'])},'guards':['old d23..d38 SCC partition taken from sealed exact recalculation','d46/d47/d48/d49 and new d40 nodes excluded from d23..d39 SCC scope','all relevant quotient edges included; multiwalls not expanded','balanced-word audit excluded from graph edges']}
h=write('POSTV05_DEPTH39_SCC_RECALCULATION.json',res)
print(json.dumps({'status':res['status'],'vertex_count':res['vertex_count'],'count':res['count'],'sizes':res['sizes'],'edge_summary':res['edge_summary'],'sha256_without_self':h}))
