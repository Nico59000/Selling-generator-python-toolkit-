import sys,json,time,hashlib,os,argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
sys.path.insert(0,'/mnt/data/post_v05/rel/src')
from selling_toolkit.layers import imat
from selling_seed2d.chart import build_chart
from selling_seed2d.classifier import ExactBoundaryClassifier

_CLF=None

def init_worker(seed):
    global _CLF
    chart=build_chart(seed)
    _CLF=ExactBoundaryClassifier(chart.q,chart.r,chart.wall_vector,chart.D0)

def classify_group(nodes):
    out=[]
    for node in nodes:
        c=_CLF.classify_cell(imat(node['L']))
        out.append({'id':int(node['id']),'ordinary_walls':list(c['ordinary_walls']),
                    'multiwall_components':[{'factor':z['factor'],'walls':list(z['walls'])} for z in c.get('multiwall_components',[])],
                    'polynomials':c.get('polynomials',{})})
    return out

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('start',type=int); ap.add_argument('count',type=int); ap.add_argument('--workers',type=int,default=8); ap.add_argument('--scc',type=int,choices=[0,1],default=0); ap.add_argument('--verify-existing',action='store_true'); a=ap.parse_args()
    ROOT='/mnt/data/post_v05'; BASE=ROOT+'/rel'; OUT=ROOT+'/d39_gate/chunks'; os.makedirs(OUT,exist_ok=True)
    seed=json.load(open(BASE+'/toolchain/synthetic_invariant_Qa.seed.json'))
    reps=json.load(open(ROOT+'/d48_gate/POSTV05_REPRESENTATIVE_INDEX_AFTER_D48.json'))['representatives']
    allnodes=reps[7074:8222]
    prev=json.load(open(ROOT+'/d38_gate/POSTV05_DEPTH38_SCC_RECALCULATION.json'))
    src_scc={i:c['scc'] for c in prev['components'] for i in c['ids']}
    nodes=[x for x in allnodes if src_scc.get(int(x.get('source',-1)))==a.scc]
    expected=1139 if a.scc==0 else 9
    assert len(nodes)==expected,(len(nodes),expected)
    sub=nodes[a.start:a.start+a.count]
    if not sub: raise SystemExit('empty')
    w=min(a.workers,len(sub)); groups=[sub[i::w] for i in range(w)]
    t=time.time(); rows=[]
    with ProcessPoolExecutor(max_workers=w, initializer=init_worker, initargs=(seed,)) as ex:
        futs=[ex.submit(classify_group,g) for g in groups if g]
        for fut in as_completed(futs): rows.extend(fut.result())
    rows.sort(key=lambda r:r['id']); dt=time.time()-t
    fn=f'd39_scc{a.scc}_{a.start:04d}_{a.start+len(sub)-1:04d}.json'; path=os.path.join(OUT,fn)
    if a.verify_existing and os.path.exists(path):
        old=json.load(open(path))['results']
        if old!=rows:
            print(json.dumps({'status':'REFUTED-MISMATCH','file':fn})); raise SystemExit(2)
        print(json.dumps({'status':'PASS-BYTE-EQUIVALENT-RESULTS','file':fn,'seconds_cached':round(dt,3),'count':len(rows)})); return
    obj={'version':'post-v0.5-continuation-20','phase':'d39-classification-chunk','engine':'research cached-worker harness over frozen selling-toolkit 0.5.0 ExactBoundaryClassifier','layer':'d39','source_scc':a.scc,'offset':[a.start,a.start+len(sub)-1],'id_range':[sub[0]['id'],sub[-1]['id']],'count':len(rows),'elapsed_seconds':dt,'results':rows}
    raw=json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode(); h=hashlib.sha256(raw).hexdigest(); obj['sha256_without_self']=h
    with open(path,'w') as f: json.dump(obj,f,indent=2,sort_keys=True); f.write('\n')
    print(json.dumps({'file':fn,'scc':a.scc,'offset':obj['offset'],'ids':obj['id_range'],'count':len(rows),'seconds':round(dt,3),'ordinary':sum(len(r['ordinary_walls']) for r in rows),'multi_ids':[r['id'] for r in rows if r.get('multiwall_components')],'sha256_without_self':h}))
if __name__=='__main__': main()
