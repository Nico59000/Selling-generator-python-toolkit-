import sys,json,glob,os,time,hashlib
sys.path.insert(0,'/mnt/data/post_v05/rel/src')
from selling_toolkit.fast_layers import quotient_layer_fast, FastHitRange
ROOT='/mnt/data/post_v05'; BASE=ROOT+'/rel'; OUT=ROOT+'/d39_gate'; os.makedirs(OUT,exist_ok=True)
def load(p):
    with open(p,'r',encoding='utf-8') as f:return json.load(f)
def write(name,obj):
    raw=json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode(); h=hashlib.sha256(raw).hexdigest(); obj=dict(obj);obj['sha256_without_self']=h
    path=os.path.join(OUT,name)
    with open(path,'w',encoding='utf-8') as f:json.dump(obj,f,indent=2,sort_keys=True,ensure_ascii=False);f.write('\n')
    return path,h
chunks=[]; rows=[]; elapsed=0.0
for fn in sorted(glob.glob(OUT+'/chunks/d39_scc*.json')):
    d=load(fn); chunks.append({'file':os.path.basename(fn),'source_scc':d['source_scc'],'offset':d['offset'],'id_range':d['id_range'],'count':d['count'],'sha256_without_self':d['sha256_without_self']}); rows+=d['results']; elapsed+=float(d['elapsed_seconds'])
rows.sort(key=lambda r:r['id'])
assert len(rows)==1148 and [r['id'] for r in rows]==list(range(7074,8222)), (len(rows), rows[0]['id'] if rows else None, rows[-1]['id'] if rows else None)
multi=[r for r in rows if r.get('multiwall_components')]
classification={'version':'post-v0.5-continuation-20','phase':'d39-classification-scc-by-scc','status':'PASS-1148/1148-EXACT-SCC-BY-SCC','layer':'d39','id_range':[7074,8221],'class_count':1148,'source_scc_counts':{'0':1139,'1':9},'ordinary_exit_count':sum(len(r['ordinary_walls']) for r in rows),'multiwall_count':len(multi),'multiwall_ids':[r['id'] for r in multi],'multiwalls':[{'id':r['id'],'ordinary_walls':r['ordinary_walls'],'components':r['multiwall_components']} for r in multi],'chunk_count':len(chunks),'chunks':chunks,'elapsed_chunk_seconds_sum':elapsed,'results':rows,'guards':['SCC0 1139/1139 completed before SCC1 9/9 in source-SCC order; IDs of SCC1 are 8213..8221','assembled only after all 1148 exact classifications present','multiwall components retained and not expanded as ordinary exits','d49 8222..8453 not classified during d39 gate','public toolkit API/CLI/schema unchanged','balanced-word audit is observational/separated and does not affect classification']}
p,ch=write('POSTV05_DEPTH39_7074_8221_CLASSIFICATION_SCC.json',classification)
print('CLASSIFICATION',classification['ordinary_exit_count'],classification['multiwall_count'],classification['multiwall_ids'],ch,flush=True)
idx=load(ROOT+'/d48_gate/POSTV05_REPRESENTATIVE_INDEX_AFTER_D48.json')['representatives']
assert len(idx)==8454 and [n['id'] for n in idx]==list(range(8454))
nodes=idx[7074:8222]
assert len(nodes)==1148 and all(int(n['depth'])==39 for n in nodes)
seed=load(BASE+'/toolchain/synthetic_invariant_Qa.seed.json')
ranges=[
 FastHitRange('d49-index-only',8222,8453), FastHitRange('d39',7074,8221), FastHitRange('d48',6887,7073),
 FastHitRange('d38',5946,6886), FastHitRange('d47',5778,5945), FastHitRange('d37',4988,5777),
 FastHitRange('d46',4858,4987), FastHitRange('d36',4188,4857), FastHitRange('d45',4078,4187),
 FastHitRange('d35',3538,4077), FastHitRange('d44',3448,3537), FastHitRange('older',0,3447)]
t=time.time();q=quotient_layer_fast(seed=seed,global_representatives=idx,nodes=nodes,classifications=rows,target_depth=40,kind='DEPTH40',layer_label='d40-post-v05-cont20',hit_ranges=ranges);dt=time.time()-t
quot={'version':'post-v0.5-continuation-20','phase':'d39-quotient','status':'PASS-1148/1148-EXACT-QUOTIENTED','engine':'selling-toolkit-0.5.0 FastCanonicalIndex int64 guarded','known_index_before':'0..8453','processing_order':'id / source-SCC0 then source-SCC1','elapsed_seconds':dt,'counts':q['counts'],'multiwalls':q['multiwalls'],'hit_buckets':q['hit_buckets'],'events':q['events'],'new_depth40_nodes':q['new_nodes'],'guards':['complete post-d48 global index 0..8453 used','d49 8222..8453 treated as known index-only and not classified','new representatives inserted immediately for deterministic same-pass collapse','multiwall components retained/not expanded','d49 classification not opened','public toolkit API/CLI/schema unchanged','balanced-word audit does not mutate quotient']}
qp,qh=write('POSTV05_DEPTH39_7074_8221_QUOTIENT_SCC_TOOLKIT.json',quot)
print('QUOTIENT',json.dumps(q['counts'],sort_keys=True),'BUCKETS',json.dumps(q['hit_buckets'],sort_keys=True),'sec',round(dt,3),qh,flush=True)
reps={'version':'post-v0.5-continuation-20','status':f"PASS-COMPLETE-GLOBAL-INDEX-0..{len(q['representatives_after'])-1}",'representative_count':len(q['representatives_after']),'representatives':q['representatives_after']}
rp,rh=write('POSTV05_REPRESENTATIVE_INDEX_AFTER_D39.json',reps)
print('INDEX',len(q['representatives_after']),len(q['representatives_after'])-1,rh,flush=True)
