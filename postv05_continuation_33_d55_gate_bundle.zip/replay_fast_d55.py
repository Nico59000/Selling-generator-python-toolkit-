import os,json,sys,time,hashlib
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import sympy as sp
from sympy.core.cache import clear_cache
R=Path('/mnt/data/cont33/postseal_fresh_extract'); sys.path.insert(0,str(R/'toolkit_src_extracted'))
from selling_seed2d.chart import build_chart
from selling_seed2d.classifier import ExactBoundaryClassifier
INDEX=R/'POSTV05_REPRESENTATIVE_INDEX_AFTER_D45.json'; SEED=R/'inputs/synthetic_invariant_Qa.seed.json'; OUT=R/'fresh_replay_results'; OUT.mkdir(exist_ok=True); _G=None
class FastSignMixin:
 def root_sign(self, poly_r, root_poly, iv):
  r=self.r; G=sp.Poly(poly_r,r,domain=sp.QQ); F=sp.Poly(root_poly,r,domain=sp.QQ)
  if G.is_zero:return 0
  Rr=G.rem(F)
  if Rr.is_zero:return 0
  d=Rr.degree()
  if d<=0:
   v=Rr.LC(); return 1 if v>0 else -1
  if d==1:
   a,b=Rr.all_coeffs(); t=-b/a
   if F.eval(t)==0:return 0
   lo,hi=iv
   for _ in range(40):
    if hi<t:return -1 if a>0 else 1
    if t<lo:return 1 if a>0 else -1
    if lo==hi:return 1 if a*(lo-t)>0 else -1
    lo,hi=sp.refine_root(F,lo,hi,eps=(hi-lo)/10)
  return super().root_sign(poly_r,root_poly,iv)
class FastExactBoundaryClassifier(FastSignMixin,ExactBoundaryClassifier):pass
def imat(rows):return sp.Matrix([[sp.Integer(v) for v in row] for row in rows])
def init_worker(seed):
 global _G
 c=build_chart(seed); _G=FastExactBoundaryClassifier(c.q,c.r,c.wall_vector,c.D0)
def worker(node):
 try:
  c=_G.classify_cell(imat(node['L']))
  return {'id':int(node['id']),'ordinary_walls':list(c['ordinary_walls']),'multiwall_components':[{'factor':z['factor'],'walls':list(z['walls'])} for z in c.get('multiwall_components',[])],'polynomials':c.get('polynomials',{})}
 finally: clear_cache()
idx=json.load(open(INDEX)); seed=json.load(open(SEED)); nodes=[n for n in idx['representatives'][24256:24953] if not (OUT/f"{n['id']}.json").exists()]; t=time.time(); mism=[]
with ProcessPoolExecutor(max_workers=5,initializer=init_worker,initargs=(seed,)) as ex:
 fs={ex.submit(worker,n):n for n in nodes}
 for i,f in enumerate(as_completed(fs),1):
  x=f.result(); (OUT/f"{x['id']}.json").write_text(json.dumps(x,sort_keys=True,separators=(',',':'))+'\n')
  exp=json.load(open(R/'chunks'/f"{x['id']}.json"))
  if x!=exp:mism.append(x['id'])
report={'version':'post-v0.5-continuation-33','status':'PASS' if not mism and len(list(OUT.glob('*.json')))==697 else 'FAIL','fresh_reclassification':f"{len(list(OUT.glob('*.json')))}/697",'mismatches':mism,'elapsed_seconds':time.time()-t,'method':'exact polynomial-remainder root-sign optimization over frozen ExactBoundaryClassifier 0.5.0 from fresh bundle extraction'}
raw=json.dumps(report,sort_keys=True,separators=(',',':')).encode();report['sha256_without_self']=hashlib.sha256(raw).hexdigest();(R/'FAST_EXACT_D55_REPLAY_REPORT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print(json.dumps(report,indent=2))
