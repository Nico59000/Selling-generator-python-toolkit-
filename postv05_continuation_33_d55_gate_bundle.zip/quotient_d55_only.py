import json,sys,time,hashlib
from pathlib import Path
BASE=Path('/mnt/data/cont33');sys.path.insert(0,str(BASE/'toolkit_src'))
from selling_toolkit.fast_layers import quotient_layer_fast,FastHitRange
rows=json.load(open(BASE/'POSTV05_DEPTH55_24256_24952_CLASSIFICATION.json'))['classifications']
idx=json.load(open(BASE/'base32_extract/POSTV05_REPRESENTATIVE_INDEX_AFTER_D45.json'))['representatives']
seed=json.load(open(BASE/'base32_extract/inputs/synthetic_invariant_Qa.seed.json'))
nodes=[idx[i] for i in range(24256,24953)]
ranges=[FastHitRange('older_0_8221',0,8221),FastHitRange('d49',8222,8453),FastHitRange('d40',8454,9822),FastHitRange('d50',9823,10103),FastHitRange('d41',10104,11754),FastHitRange('d51',11755,12089),FastHitRange('d42',12090,14087),FastHitRange('d52',14088,14477),FastHitRange('d43',14478,16874),FastHitRange('d53',16875,17361),FastHitRange('d44',17362,20236),FastHitRange('d54',20237,20814),FastHitRange('d45',20815,24255),FastHitRange('d55',24256,24952),FastHitRange('d46-index-only',24953,29078)]
print('START quotient',flush=True);t=time.time();q=quotient_layer_fast(seed=seed,global_representatives=idx,nodes=nodes,classifications=rows,target_depth=56,kind='DEPTH56',layer_label='d56-post-v05-cont33',hit_ranges=ranges);elapsed=time.time()-t
qo={'version':'post-v0.5-continuation-33','phase':'d55-quotient','status':'PASS-697/697-EXACT-QUOTIENTED','engine':'selling-toolkit-0.5.0 FastCanonicalIndex int64 guarded','processing_order':'id','known_index_before':'0..29078','counts':q['counts'],'hit_buckets':q['hit_buckets'],'events':q['events'],'multiwalls':q['multiwalls'],'new_depth56_nodes':q['new_nodes'],'elapsed_seconds':elapsed,'guards':['complete current global index 0..29078 used','d46 24953..29078 treated as known index-only/HIT-only and not classified','new d56 representatives inserted immediately for deterministic same-pass collapse','d46 classification not opened','next principal layer not opened']}
raw=json.dumps(qo,sort_keys=True,separators=(',',':')).encode();qo['sha256_without_self']=hashlib.sha256(raw).hexdigest();(BASE/'POSTV05_DEPTH55_24256_24952_QUOTIENT_TOOLKIT.json').write_text(json.dumps(qo,indent=2,sort_keys=True)+'\n')
idxo={'version':'post-v0.5-continuation-33','status':'INDEX-AFTER-D55','representatives':q['representatives_after']};raw=json.dumps(idxo,sort_keys=True,separators=(',',':')).encode();idxo['sha256_without_self']=hashlib.sha256(raw).hexdigest();(BASE/'POSTV05_REPRESENTATIVE_INDEX_AFTER_D55.json').write_text(json.dumps(idxo,indent=2,sort_keys=True)+'\n')
print('quotient',q['counts'],'hit_buckets',q['hit_buckets'],'new_range',([q['new_nodes'][0]['id'],q['new_nodes'][-1]['id']] if q['new_nodes'] else None),'index_last',len(q['representatives_after'])-1,'elapsed',round(elapsed,3),flush=True)
