#!/usr/bin/env python3
import argparse,json,os,sys,time
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import sympy as sp
_G=None
class FastSignMixin:
    def root_sign(self, poly_r, root_poly, iv):
        r=self.r; G=sp.Poly(poly_r,r,domain=sp.QQ); F=sp.Poly(root_poly,r,domain=sp.QQ)
        if G.is_zero:return 0
        R=G.rem(F)
        if R.is_zero:return 0
        if R.degree()<=0:
            v=R.LC();return 1 if v>0 else -1
        if R.degree()==1:
            a,b=R.all_coeffs();t=-b/a
            if F.eval(t)==0:return 0
            lo,hi=iv
            for _ in range(40):
                if hi<t:return -1 if a>0 else 1
                if t<lo:return 1 if a>0 else -1
                if lo==hi:return 1 if a*(lo-t)>0 else -1
                lo,hi=sp.refine_root(F,lo,hi,eps=(hi-lo)/10)
        return super().root_sign(poly_r,root_poly,iv)
def load(p):return json.load(open(p,encoding='utf-8'))
def init_worker(seed):
    global _G
    sys.path.insert(0,'/mnt/data/cont27/toolkit_src')
    from selling_seed2d.chart import build_chart
    from selling_seed2d.classifier import ExactBoundaryClassifier
    class FastExactBoundaryClassifier(FastSignMixin,ExactBoundaryClassifier):pass
    c=build_chart(load(seed));_G=FastExactBoundaryClassifier(c.q,c.r,c.wall_vector,c.D0)
def worker(n):
    from sympy.core.cache import clear_cache
    try:
        L=sp.Matrix([[sp.Integer(v) for v in row] for row in n['L']]);c=_G.classify_cell(L)
        return {'id':int(n['id']),'ordinary_walls':list(c['ordinary_walls']),'multiwall_components':[{'factor':z['factor'],'walls':list(z['walls'])} for z in c.get('multiwall_components',[])],'polynomials':c.get('polynomials',{})}
    finally: clear_cache()
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--start',type=int,default=14478);ap.add_argument('--end',type=int,default=16874);ap.add_argument('--workers',type=int,default=5);ap.add_argument('--out',default='/mnt/data/cont28/fast_results');a=ap.parse_args()
    out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
    idx=load('/mnt/data/cont27/POSTV05_REPRESENTATIVE_INDEX_AFTER_D52.json')['representatives'];nodes=[idx[i] for i in range(a.start,a.end+1) if not (out/f'{i}.json').exists()]
    print('START',len(nodes),flush=True);t=time.time();ok=0
    with ProcessPoolExecutor(max_workers=a.workers,initializer=init_worker,initargs=(Path('/mnt/data/cont26/work/c24/inputs/synthetic_invariant_Qa.seed.json'),)) as ex:
      fs={ex.submit(worker,n):n for n in nodes}
      for f in as_completed(fs):
        x=f.result();p=out/f"{x['id']}.json";tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(x,sort_keys=True,separators=(',',':'))+'\n');os.replace(tmp,p);ok+=1
        if ok%100==0 or ok==len(nodes):print('P',ok,'/',len(nodes),'secs',round(time.time()-t,1),flush=True)
    print('END',ok,round(time.time()-t,1),flush=True)
if __name__=='__main__':main()
