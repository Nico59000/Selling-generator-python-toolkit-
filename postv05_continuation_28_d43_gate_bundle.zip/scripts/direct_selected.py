import os,json,sys,time
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import sympy as sp
from sympy.core.cache import clear_cache
sys.path.insert(0,'/mnt/data/cont27/toolkit_src')
from selling_seed2d.chart import build_chart
from selling_seed2d.classifier import ExactBoundaryClassifier
IDX=json.load(open('/mnt/data/cont27/POSTV05_REPRESENTATIVE_INDEX_AFTER_D52.json'))['representatives']
SEED=json.load(open('/mnt/data/cont26/work/c24/inputs/synthetic_invariant_Qa.seed.json'))
IDS=[14481,14748,15372,15374,15412,15430,15688,15702,15709,15723,16437,16509,16533,16547,16548,16605,16850,16856]
OUT=Path('/mnt/data/cont28/direct_multiwall');OUT.mkdir(exist_ok=True)
_G=None
def init():
 global _G
 c=build_chart(SEED);_G=ExactBoundaryClassifier(c.q,c.r,c.wall_vector,c.D0)
def work(i):
 try:
  n=IDX[i]; L=sp.Matrix([[sp.Integer(v) for v in row] for row in n['L']]);c=_G.classify_cell(L)
  return {'id':i,'ordinary_walls':list(c['ordinary_walls']),'multiwall_components':[{'factor':z['factor'],'walls':list(z['walls'])} for z in c.get('multiwall_components',[])],'polynomials':c.get('polynomials',{})}
 finally: clear_cache()
if __name__=='__main__':
 t=time.time()
 with ProcessPoolExecutor(max_workers=5,initializer=init) as ex:
  fs={ex.submit(work,i):i for i in IDS}
  for f in as_completed(fs):
   x=f.result();(OUT/f"{x['id']}.json").write_text(json.dumps(x,sort_keys=True,separators=(',',':'))+'\n')
 print('done',time.time()-t)
