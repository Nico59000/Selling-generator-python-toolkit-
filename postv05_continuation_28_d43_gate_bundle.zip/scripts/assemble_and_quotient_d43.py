import json,glob,hashlib,sys,time,collections
from pathlib import Path
BASE=Path('/mnt/data/cont28')
rows=sorted([json.load(open(f)) for f in glob.glob(str(BASE/'d43_results/*.json'))],key=lambda x:x['id'])
assert len(rows)==2397 and [r['id'] for r in rows]==list(range(14478,16875))
counts={'classes':2397,'ordinary_exits':sum(len(r['ordinary_walls']) for r in rows),'multiwall_cells':sum(bool(r['multiwall_components']) for r in rows)}
obj={'version':'post-v0.5-continuation-28','gate':'d43 14478..16874','status':'PASS-2397/2397-EXACT','counts':counts,'classifications':rows,'validation':{'fast_exact_vs_direct_prefix_and_scc1':'76/76 PASS','direct_multiwall_crosscheck':'18/18 PASS'}}
raw=json.dumps(obj,sort_keys=True,separators=(',',':')).encode();obj['sha256_without_self']=hashlib.sha256(raw).hexdigest();(BASE/'POSTV05_DEPTH43_14478_16874_CLASSIFICATION.json').write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
# updated multiwall ledger
prev=json.load(open('/mnt/data/cont27/POSTV05_MULTIWALL_RECURRENCE_AUDIT_AFTER_D52.json'))
idx=json.load(open('/mnt/data/cont27/POSTV05_REPRESENTATIVE_INDEX_AFTER_D52.json'))['representatives']
events=list(prev['events'])
for r in rows:
 for z in r['multiwall_components']:
  events.append({'depth':43,'factor':z['factor'],'id':r['id'],'layer':'d43','source':idx[r['id']]['source'],'walls':z['walls']})
fams={}
for e in events:
 f=e['factor']; fams.setdefault(f,{'factor':f,'ids':[],'depths':set(),'wall_pair_counts':collections.Counter()})
 fams[f]['ids'].append(e['id']);fams[f]['depths'].add(e['depth']);fams[f]['wall_pair_counts']['/'.join(e['walls'])]+=1
fl=[]
for f,d in sorted(fams.items()):
 fl.append({'factor':f,'event_count':len(d['ids']),'ids':d['ids'],'depths':sorted(d['depths']),'wall_pair_counts':dict(sorted(d['wall_pair_counts'].items()))})
pc=collections.Counter(''.join(e['walls']) for e in events)
aud={'version':'post-v0.5-continuation-28','status':'PASS-EXACT-APPEND-ONLY-MULTIWALL-CENSUS-AFTER-D43','event_count':len(events),'factor_family_count':len(fl),'events':events,'families':fl,'new_d43':{'cell_count':counts['multiwall_cells'],'event_count':18,'ids':[r['id'] for r in rows if r['multiwall_components']],'new_primitive_factors':sorted(set(z['factor'] for r in rows for z in r['multiwall_components'])-set(x['factor'] for x in prev['families']))},'pair_incidence':{'adjacent_pairs_observed':len(pc),'counts':dict(sorted(pc.items())),'opposite_pairs_observed':0,'opposite_pairs':[]},'scope_guard':'append-only exact census through d43; no future extrapolation'}
raw=json.dumps(aud,sort_keys=True,separators=(',',':')).encode();aud['sha256_without_self']=hashlib.sha256(raw).hexdigest();(BASE/'POSTV05_MULTIWALL_RECURRENCE_AUDIT_AFTER_D43.json').write_text(json.dumps(aud,indent=2,sort_keys=True)+'\n')
print('classification',counts,'ledger',len(events),len(fl),'newf',aud['new_d43']['new_primitive_factors'])
# quotient
sys.path.insert(0,'/mnt/data/cont27/toolkit_src')
from selling_toolkit.fast_layers import quotient_layer_fast,FastHitRange
seed=json.load(open('/mnt/data/cont26/work/c24/inputs/synthetic_invariant_Qa.seed.json'))
reps=json.load(open('/mnt/data/cont27/POSTV05_REPRESENTATIVE_INDEX_AFTER_D52.json'))['representatives']
nodes=[reps[i] for i in range(14478,16875)]
ranges=[FastHitRange('older_0_8221',0,8221),FastHitRange('d49',8222,8453),FastHitRange('d40',8454,9822),FastHitRange('d50',9823,10103),FastHitRange('d41',10104,11754),FastHitRange('d51',11755,12089),FastHitRange('d42',12090,14087),FastHitRange('d52',14088,14477),FastHitRange('d43',14478,16874),FastHitRange('d53-index-only',16875,17361)]
t=time.time();q=quotient_layer_fast(seed=seed,global_representatives=reps,nodes=nodes,classifications=rows,target_depth=44,kind='DEPTH44',layer_label='d44-post-v05-cont28',hit_ranges=ranges);elapsed=time.time()-t
qo={'version':'post-v0.5-continuation-28','phase':'d43-quotient','status':'PASS-2397/2397-EXACT-QUOTIENTED','engine':'selling-toolkit-0.5.0 FastCanonicalIndex int64 guarded','processing_order':'id','known_index_before':'0..17361','counts':q['counts'],'hit_buckets':q['hit_buckets'],'events':q['events'],'multiwalls':q['multiwalls'],'new_depth44_nodes':q['new_nodes'],'elapsed_seconds':elapsed,'guards':['complete current global index 0..17361 used','d53 16875..17361 treated as known index-only/HIT-only and not classified','new d44 representatives inserted immediately for deterministic same-pass collapse','d44 classification not opened']}
raw=json.dumps(qo,sort_keys=True,separators=(',',':')).encode();qo['sha256_without_self']=hashlib.sha256(raw).hexdigest();(BASE/'POSTV05_DEPTH43_14478_16874_QUOTIENT_TOOLKIT.json').write_text(json.dumps(qo,indent=2,sort_keys=True)+'\n')
idxo={'version':'post-v0.5-continuation-28','status':'INDEX-AFTER-D43','representatives':q['representatives_after']};raw=json.dumps(idxo,sort_keys=True,separators=(',',':')).encode();idxo['sha256_without_self']=hashlib.sha256(raw).hexdigest();(BASE/'POSTV05_REPRESENTATIVE_INDEX_AFTER_D43.json').write_text(json.dumps(idxo,indent=2,sort_keys=True)+'\n')
print('quotient',q['counts'],'hit_buckets',q['hit_buckets'],'new_range',([q['new_nodes'][0]['id'],q['new_nodes'][-1]['id']] if q['new_nodes'] else None),'index_last',len(q['representatives_after'])-1,'elapsed',elapsed)
