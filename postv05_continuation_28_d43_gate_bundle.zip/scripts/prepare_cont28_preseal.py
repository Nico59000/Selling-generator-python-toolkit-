import json,hashlib,shutil,zipfile,glob,os
from pathlib import Path
ROOT=Path('/mnt/data/cont28');ST=ROOT/'preseal_stage'
if ST.exists():shutil.rmtree(ST)
ST.mkdir()
def cp(src,rel):
 s=Path(src);d=ST/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(s,d)
def sha(p):
 h=hashlib.sha256();
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
# reports/checkpoint generated below
# validation report
bad=[];checked=0
for f in glob.glob(str(ROOT/'class_results/*.json')):
 d=json.load(open(f));g=ROOT/'d43_results'/f"{d['id']}.json"
 if g.exists():
  checked+=1
  if json.load(open(g))!=d:bad.append(d['id'])
md=[]
for f in glob.glob(str(ROOT/'direct_multiwall/*.json')):
 d=json.load(open(f));e=json.load(open(ROOT/'d43_results'/f"{d['id']}.json"));
 if d!=e:md.append(d['id'])
val={'version':'post-v0.5-continuation-28','status':'PASS' if not bad and not md and checked==76 else 'FAIL','direct_crosscheck_count':checked,'direct_crosscheck_failures':bad,'multiwall_direct_count':18,'multiwall_direct_failures':md,'method':'FastExactBoundaryClassifier optimization crosschecked against frozen ExactBoundaryClassifier 0.5.0'}
(ROOT/'POSTV05_D43_CLASSIFIER_CROSSCHECK.json').write_text(json.dumps(val,indent=2,sort_keys=True)+'\n')
# toolkit freeze hashes
src='/mnt/data/cont26/final_stage/inputs/selling_toolkit_v05_0_source.zip';whl='/mnt/data/cont26/final_stage/inputs/selling_toolkit-0.5.0-py3-none-any.whl'
freeze={'version':'post-v0.5-continuation-28','status':'PASS-0.5.0-FROZEN-BYTE-IDENTICAL','source_zip_sha256':sha(src),'wheel_sha256':sha(whl),'expected_source_sha256':'d5e35f99cdb556a5f1d6c52355196aa592022527581f468bee1987c28384961b','expected_wheel_sha256':'17d61dec03024c6392cf4ce2362e13e7b37facb06314e37ab2c7a65ac3681e88'}
freeze['byte_identical_expected']=freeze['source_zip_sha256']==freeze['expected_source_sha256'] and freeze['wheel_sha256']==freeze['expected_wheel_sha256'];(ROOT/'POSTV05_CONTINUATION_28_TOOLKIT_FREEZE_AUDIT.json').write_text(json.dumps(freeze,indent=2,sort_keys=True)+'\n')
q=json.load(open(ROOT/'POSTV05_DEPTH43_14478_16874_QUOTIENT_TOOLKIT.json'));scc=json.load(open(ROOT/'POSTV05_DEPTH43_SCC_RECALCULATION.json'));aud=json.load(open(ROOT/'POSTV05_MULTIWALL_RECURRENCE_AUDIT_AFTER_D43.json'))
checkpoint={'version':'post-v0.5-continuation-28','gate':'d43 14478..16874','status':'D43-PASS-EXACT/PRESEAL','publication_state':'RESEARCH-CHECKPOINT/PRESEAL/NONPUBLISHABLE','classification':{'classes':2397,'status':'PASS-2397/2397-EXACT','ordinary_exits':8800,'multiwall_cells':18,'multiwall_ids':aud['new_d43']['ids']},'multiwall':{'events':106,'families':13,'new_d43_events':18,'new_primitive_families':5,'adjacent_pairs':'12/12','opposite_pairs':'0/3'},'quotient':{'hits':5925,'new':2875,'hit_buckets':q['hit_buckets'],'d44_range':[17362,20236],'global_index_after':'0..20236','d53':'HIT-only/unclassified'},'scc':{'scope':'d23..d43','count':scc['count'],'sizes':scc['sizes'],'d44_source_partition':{'0':2860,'1':15}},'verification':{'independent_oracle':'PASS','U_hits':'5925/5925 PASS','direct_classifier_crosscheck':'76/76 PASS','direct_multiwall_crosscheck':'18/18 PASS'},'toolkit':freeze,'guards':['d53 remains unclassified','d44 remains unclassified','no next lateral layer opened','v55 overlays separated']}
(ROOT/'POSTV05_CONTINUATION_28_D43_CHECKPOINT.json').write_text(json.dumps(checkpoint,indent=2,sort_keys=True)+'\n')
safe='''POST-v0.5 continuation 28 — SAFE NEXT FRONTIER AFTER D43\n\nRetain continuations 15–28 append-only and selling-toolkit 0.5.0 public/FROZEN/BYTE-IDENTICAL.\n\npost-v0.5 continuation 29 — d53 = 16875..17361 (487 classes):\n- classify d53 exactly and require 487/487 before any quotient;\n- quotient only after full classification against complete current index 0..20236;\n- d44=17362..20236 is known for HIT detection only and remains unclassified during d53;\n- do not classify the next lateral layer before d53 closure.\n\nOnly after d53 closure: classify d44 SCC-by-SCC using source partition 2875 = 2860_SCC0 + 15_SCC1, then quotient and recalc d23..d44.\n\nRetain d43 result: 2397/2397 exact, 8800 ordinary exits, 18 multiwalls, quotient 8800=5925 HIT+2875 NEW, d44=17362..20236.\nRetain multiwall ledger 106 events / 13 primitive factors, 12/12 adjacent and 0/3 opposite.\nRetain d53=16875..17361 unclassified.\nRetain HTNT v4 / selling-toolkit 0.6.0-dev research branch as SEPARATED/NOT-RELEASED.\n'''
(ROOT/'POSTV05_SAFE_NEXT_FRONTIER_AFTER_D43.txt').write_text(safe)
# copies core
for name in ['POSTV05_DEPTH43_14478_16874_CLASSIFICATION.json','POSTV05_DEPTH43_14478_16874_QUOTIENT_TOOLKIT.json','POSTV05_DEPTH43_INDEPENDENT_VERIFICATION_REPORT.json','POSTV05_DEPTH43_SCC_RECALCULATION.json','POSTV05_MULTIWALL_RECURRENCE_AUDIT_AFTER_D43.json','POSTV05_REPRESENTATIVE_INDEX_AFTER_D43.json','POSTV05_CONTINUATION_28_D43_CHECKPOINT.json','POSTV05_CONTINUATION_28_TOOLKIT_FREEZE_AUDIT.json','POSTV05_D43_CLASSIFIER_CROSSCHECK.json','POSTV05_SAFE_NEXT_FRONTIER_AFTER_D43.txt']:
 cp(ROOT/name,name)
cp('/mnt/data/cont27/POSTV05_REPRESENTATIVE_INDEX_AFTER_D52.json','POSTV05_REPRESENTATIVE_INDEX_AFTER_D52.json')
cp('/mnt/data/cont26/final_stage/POSTV05_DEPTH42_SCC_RECALCULATION.json','POSTV05_DEPTH42_SCC_RECALCULATION.json')
cp(src,'inputs/selling_toolkit_v05_0_source.zip');cp(whl,'inputs/selling_toolkit-0.5.0-py3-none-any.whl');cp('/mnt/data/cont26/final_stage/inputs/synthetic_invariant_Qa.seed.json','inputs/synthetic_invariant_Qa.seed.json');cp('/mnt/data/cont27/POSTV05_CONTINUATION_27_ATOMIC_COMPLETION_TOKEN.json','inputs/POSTV05_CONTINUATION_27_ATOMIC_COMPLETION_TOKEN.json')
# chunks exact full
for p in sorted((ROOT/'d43_results').glob('*.json')):cp(p,'chunks/'+p.name)
for p in sorted((ROOT/'scripts').glob('*.py')):cp(p,'scripts/'+p.name)
# formal/research overlays retained
if Path('/mnt/data/cont27/formal_context').exists():
 for p in sorted(Path('/mnt/data/cont27/formal_context').glob('*')):cp(p,'formal_context/'+p.name)
for p in ['/mnt/data/cont27/selling-toolkit-0.6.0-dev0-research-prototype.zip','/mnt/data/cont27/SELLING_TOOLKIT_060DEV_HTNT_V4_RESEARCH_CERTIFICATE.json']:
 if Path(p).exists():cp(p,'research_overlay/'+Path(p).name)
# create manifest + sums
files=sorted(p for p in ST.rglob('*') if p.is_file());entries=[{'path':p.relative_to(ST).as_posix(),'sha256':sha(p),'size':p.stat().st_size} for p in files]
man={'version':'post-v0.5-continuation-28','status':'PRESEAL/NONPUBLISHABLE','entry_count':len(entries),'postseal_replay':'PENDING','entries':entries};(ST/'POSTV05_CONTINUATION_28_MANIFEST.json').write_text(json.dumps(man,indent=2,sort_keys=True)+'\n')
rows=[f"{sha(p)}  {p.relative_to(ST).as_posix()}" for p in sorted(x for x in ST.rglob('*') if x.is_file())];(ST/'POSTV05_CONTINUATION_28_SHA256SUMS.txt').write_text('\n'.join(rows)+'\n')
ZIP=ROOT/'postv05_continuation_28_d43_preseal_bundle.zip'
with zipfile.ZipFile(ZIP,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(x for x in ST.rglob('*') if x.is_file()):
  arc=p.relative_to(ST).as_posix();info=zipfile.ZipInfo(arc,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=(0o100644<<16);info.create_system=3;z.writestr(info,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
print(json.dumps({'manifest_entries':len(entries),'sha_rows':len(rows),'zip_entries':len(rows)+1,'zip_size':ZIP.stat().st_size,'zip_sha256':sha(ZIP)},indent=2))
