import json,sys,time
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import sympy as sp
from sympy.core.cache import clear_cache
ROOT=Path('/mnt/data/cont28/postseal_fresh_extract');sys.path.insert(0,str(ROOT/'toolkit_src'))
from selling_seed2d.chart import build_chart
from selling_seed2d.classifier import ExactBoundaryClassifier
IDX=json.load(open(ROOT/'POSTV05_REPRESENTATIVE_INDEX_AFTER_D52.json'))['representatives'];SEED=json.load(open(ROOT/'inputs/synthetic_invariant_Qa.seed.json'));EXP={x['id']:x for x in json.load(open(ROOT/'POSTV05_DEPTH43_14478_16874_CLASSIFICATION.json'))['classifications']}
MULTI=[14481,14748,15372,15374,15412,15430,15688,15702,15709,15723,16437,16509,16533,16547,16548,16605,16850,16856]
# 12 evenly spaced plus all multiwalls
spread=[]
for k in range(12):spread.append(14478 + round(k*(16874-14478)/11))
IDS=sorted(set(MULTI+spread))
_G=None
def init():
 global _G
 c=build_chart(SEED);_G=ExactBoundaryClassifier(c.q,c.r,c.wall_vector,c.D0)
def work(i):
 try:
  L=sp.Matrix([[sp.Integer(v) for v in row] for row in IDX[i]['L']]);c=_G.classify_cell(L)
  return {'id':i,'ordinary_walls':list(c['ordinary_walls']),'multiwall_components':[{'factor':z['factor'],'walls':list(z['walls'])} for z in c.get('multiwall_components',[])],'polynomials':c.get('polynomials',{})}
 finally:clear_cache()
if __name__=='__main__':
 t=time.time();bad=[];multi_bad=[]
 with ProcessPoolExecutor(max_workers=5,initializer=init) as ex:
  for x in ex.map(work,IDS):
   if x!=EXP[x['id']]:bad.append(x['id'])
   if x['id'] in MULTI and x!=EXP[x['id']]:multi_bad.append(x['id'])
 rep={'status':'PASS' if not bad else 'FAIL','checked':len(IDS),'multiwalls_checked':18,'failures':bad,'multiwall_failures':multi_bad,'elapsed_seconds':time.time()-t,'method':'fresh frozen selling-toolkit 0.5.0 ExactBoundaryClassifier direct'}
 (ROOT/'DIRECT_TOOLKIT_D43_CROSSCHECK.json').write_text(json.dumps(rep,indent=2,sort_keys=True)+'\n');print(json.dumps(rep))
