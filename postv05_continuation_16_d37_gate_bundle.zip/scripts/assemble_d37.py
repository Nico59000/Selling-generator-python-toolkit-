import sys,json,glob,os,time,hashlib
sys.path.insert(0,'/mnt/data/post_v05/rel/src')
from selling_toolkit.fast_layers import quotient_layer_fast, FastHitRange
BASE='/mnt/data/post_v05/rel'; ROOT='/mnt/data/post_v05'; OUT=ROOT+'/d37_gate'; os.makedirs(OUT,exist_ok=True)
def load(p):
    with open(p,'r',encoding='utf-8') as f:return json.load(f)
def write(name,obj):
    raw=json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode(); h=hashlib.sha256(raw).hexdigest(); obj=dict(obj);obj['sha256_without_self']=h
    path=os.path.join(OUT,name)
    with open(path,'w',encoding='utf-8') as f:json.dump(obj,f,indent=2,sort_keys=True,ensure_ascii=False);f.write('\n')
    return path,h
chunks=[]; rows=[]; elapsed=0.0
for fn in sorted(glob.glob(OUT+'/chunks/d37_scc*.json')):
    d=load(fn); chunks.append({'file':os.path.basename(fn),'source_scc':d['source_scc'],'offset':d['offset'],'id_range':d['id_range'],'count':d['count'],'sha256_without_self':d['sha256_without_self']}); rows+=d['results']; elapsed+=float(d['elapsed_seconds'])
rows.sort(key=lambda r:r['id'])
assert len(rows)==790 and [r['id'] for r in rows]==list(range(4988,5778)), (len(rows),rows[0]['id'],rows[-1]['id'])
# exact SCC group counts from sealed d36 quotient labels
idx36=load(BASE+'/V04_REPRESENTATIVE_INDEX_AFTER_D36.json')['representatives']
nodes=idx36[4988:5778]
group={0:[n for n in nodes if int(n['enlarged_source_scc'])==0],1:[n for n in nodes if int(n['enlarged_source_scc'])==1]}
assert len(group[0])==781 and len(group[1])==9
multi=[r for r in rows if r.get('multiwall_components')]
classification={'version':'post-v0.5-continuation-16','phase':'d37-classification','status':'PASS-790/790-EXACT-SCC-BY-SCC','layer':'d37','id_range':[4988,5777],'active_source_sccs':[0,1],'source_scc_group_sizes':{'0':781,'1':9},'class_count':790,'ordinary_exit_count':sum(len(r['ordinary_walls']) for r in rows),'multiwall_count':len(multi),'multiwall_ids':[r['id'] for r in multi],'chunk_count':len(chunks),'chunks':chunks,'elapsed_chunk_seconds_sum':elapsed,'results':rows,'guards':['assembled only after all 790 exact classifications present','SCC0 781/781 closed before SCC1 9/9 opened','multiwall components retained and not expanded as ordinary exits','d47 known as index-only 5778..5945 and not classified']}
p,ch=write('POSTV05_DEPTH37_4988_5777_CLASSIFICATION_SCC.json',classification)
print('CLASSIFICATION',classification['ordinary_exit_count'],classification['multiwall_count'],classification['multiwall_ids'],ch,flush=True)
# full known index after d46
idx46=load(ROOT+'/d46_gate/POSTV05_REPRESENTATIVE_INDEX_AFTER_D46.json')['representatives']
assert len(idx46)==5946 and [n['id'] for n in idx46]==list(range(5946))
seed=load(BASE+'/toolchain/synthetic_invariant_Qa.seed.json')
# source SCC mapping derived exactly from stored d37 labels
source_scc={}
for n in nodes:
    s=int(n['source']); c=int(n['enlarged_source_scc'])
    if s in source_scc and source_scc[s]!=c: raise AssertionError((s,source_scc[s],c))
    source_scc[s]=c
ranges=[
 FastHitRange('d37',4988,5777),FastHitRange('d47-index-only',5778,5945),FastHitRange('d46',4858,4987),
 FastHitRange('d36',4188,4857),FastHitRange('d45',4078,4187),FastHitRange('d35',3538,4077),FastHitRange('d44',3448,3537),FastHitRange('older',0,3447)]
t=time.time(); q=quotient_layer_fast(seed=seed,global_representatives=idx46,nodes=nodes,classifications=rows,target_depth=38,kind='DEPTH38',layer_label='d38-post-v05-cont16',hit_ranges=ranges,source_scc=source_scc); dt=time.time()-t
quot={'version':'post-v0.5-continuation-16','phase':'d37-quotient','status':'PASS-790/790-EXACT-QUOTIENTED','engine':'selling-toolkit-0.5.0 FastCanonicalIndex int64 guarded','known_index_before':'0..5945','processing_order':'enlarged_source_scc then id','elapsed_seconds':dt,'counts':q['counts'],'multiwalls':q['multiwalls'],'hit_buckets':q['hit_buckets'],'events':q['events'],'new_depth38_nodes':q['new_nodes'],'guards':['complete post-d46 global index 0..5945 used','d47 5778..5945 treated as known index-only and not classified','new representatives inserted immediately for deterministic same-pass collapse','multiwall components retained/not expanded','public toolkit API/CLI/schema unchanged']}
qp,qh=write('POSTV05_DEPTH37_4988_5777_QUOTIENT_SCC_TOOLKIT.json',quot)
print('QUOTIENT',json.dumps(q['counts'],sort_keys=True),'BUCKETS',json.dumps(q['hit_buckets'],sort_keys=True),'sec',round(dt,3),qh,flush=True)
reps={'version':'post-v0.5-continuation-16','status':f"PASS-COMPLETE-GLOBAL-INDEX-0..{len(q['representatives_after'])-1}",'representative_count':len(q['representatives_after']),'representatives':q['representatives_after']}
rp,rh=write('POSTV05_REPRESENTATIVE_INDEX_AFTER_D37.json',reps)
print('INDEX',len(q['representatives_after']),len(q['representatives_after'])-1,rh,flush=True)
