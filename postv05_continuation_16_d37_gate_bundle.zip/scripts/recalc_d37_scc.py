import sys,json,os,hashlib
sys.path.insert(0,'/mnt/data/post_v05/rel/src')
from selling_toolkit.layers import tarjan_scc
BASE='/mnt/data/post_v05/rel'; OUT='/mnt/data/post_v05/d37_gate'
def load(p):
    with open(p,'r') as f:return json.load(f)
def write(name,obj):
    raw=json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode(); h=hashlib.sha256(raw).hexdigest(); obj=dict(obj); obj['sha256_without_self']=h
    with open(os.path.join(OUT,name),'w') as f:json.dump(obj,f,indent=2,sort_keys=True);f.write('\n')
    return h
old=load(BASE+'/V04_DEPTH36_SCC_RECALCULATION.json')['enlarged_d23_to_d36_scc']
old_comps={c['scc']:c['ids'] for c in old['components']}
id2old={i:s for s,ids in old_comps.items() for i in ids}
assert len(id2old)==3710
# Meta vertices: old SCCs as negative tags -1..-7, plus d37 ids 4988..5777.
def ov(s): return -(s+1)
meta_vertices=[ov(s) for s in sorted(old_comps)] + list(range(4988,5778))
meta_edges=[]
# old condensation edges (none currently, but retain generically)
for e in old.get('condensation_edges',[]): meta_edges.append((ov(e['from']),ov(e['to'])))
# d36 -> d37 edges from sealed continuation-14 quotient
q36=load(BASE+'/V04_DEPTH36_4188_4857_QUOTIENT_SCC_TOOLKIT.json')
for e in q36['events']:
    t=int(e['target']); s=int(e['source'])
    if 4988<=t<=5777:
        meta_edges.append((ov(id2old[s]),t))
# d37 -> old/d37 edges from current quotient; exclude d46, d47, d38/same-pass
q37=load(OUT+'/POSTV05_DEPTH37_4988_5777_QUOTIENT_SCC_TOOLKIT.json')
for e in q37['events']:
    s=int(e['source']); t=int(e['target'])
    if t in id2old: meta_edges.append((s,ov(id2old[t])))
    elif 4988<=t<=5777: meta_edges.append((s,t))
meta=tarjan_scc(meta_vertices,meta_edges)
# Expand meta SCCs to actual IDs.
expanded=[]
for c in meta['components']:
    ids=[]
    for v in c['ids']:
        if v<0: ids.extend(old_comps[-v-1])
        else: ids.append(v)
    expanded.append(sorted(ids))
expanded.sort(key=lambda c:(-len(c),c[0]))
# Build exact condensation between expanded comps from meta edges.
cid={v:i for i,c in enumerate(expanded) for v in c}
from collections import Counter
cond=Counter()
# expand meta edge endpoint to representative actual id for cid lookup
for a,b in meta_edges:
    aa=old_comps[-a-1][0] if a<0 else a
    bb=old_comps[-b-1][0] if b<0 else b
    if cid[aa]!=cid[bb]: cond[(cid[aa],cid[bb])]+=1
res={'version':'post-v0.5-continuation-16','phase':'d37-scc-recalculation','status':'PASS-EXACT-SCC-RECALC','scope':'d23..d37 only; d46/d47/d38 excluded','method':'exact old SCC contraction + all d36->d37 and d37->(d23..d37) quotient edges','vertex_count':sum(map(len,expanded)),'count':len(expanded),'sizes':[len(c) for c in expanded],'components':[{'scc':i,'size':len(c),'ids':c} for i,c in enumerate(expanded)],'condensation_edges':[{'from':a,'to':b,'count':n} for (a,b),n in sorted(cond.items())],'edge_summary':{'old_condensation_edges':len(old.get('condensation_edges',[])),'d36_to_d37':sum(4988<=int(e['target'])<=5777 for e in q36['events']),'d37_to_old':sum(int(e['target']) in id2old for e in q37['events']),'d37_to_d37':sum(4988<=int(e['target'])<=5777 for e in q37['events'])},'guards':['old d23..d36 SCC partition taken from sealed exact recalculation','d46/d47 and new d38 nodes excluded from d23..d37 SCC scope','all relevant quotient edges included; multiwalls not expanded']}
h=write('POSTV05_DEPTH37_SCC_RECALCULATION.json',res)
print(json.dumps({'status':res['status'],'vertex_count':res['vertex_count'],'count':res['count'],'sizes':res['sizes'],'edge_summary':res['edge_summary'],'sha256_without_self':h}))
