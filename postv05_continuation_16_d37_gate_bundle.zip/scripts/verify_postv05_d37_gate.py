#!/usr/bin/env python3
import sys,json,zipfile,tempfile,hashlib,glob
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def load(p): return json.load(open(p))
# verify chunk self-hashes and exact assembly
rows=[]; bad=[]
for p in sorted((R/'chunks').glob('d37_scc*.json')):
    d=load(p); x=dict(d); h=x.pop('sha256_without_self',None); raw=json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
    if hashlib.sha256(raw).hexdigest()!=h: bad.append('chunk_hash:'+p.name)
    rows+=d['results']
rows.sort(key=lambda r:r['id'])
clf=load(R/'POSTV05_DEPTH37_4988_5777_CLASSIFICATION_SCC.json')
if rows!=clf['results']: bad.append('chunk_assembly_mismatch')
if [r['id'] for r in rows]!=list(range(4988,5778)): bad.append('coverage')
# use frozen toolkit source for direct classifier checks + exact quotient replay
with tempfile.TemporaryDirectory() as td:
    zipfile.ZipFile(R/'inputs/selling_toolkit_v05_0_source.zip').extractall(td); sys.path.insert(0,td)
    from selling_toolkit.layers import classify_exact, tarjan_scc
    from selling_seed2d.algebra import S,FIRST_MOVE,WALL_ACTION,RELABEL,build_finite_group
    from selling_seed2d.seed import seed_matrices
    seed=load(R/'inputs/synthetic_invariant_Qa.seed.json')
    idx36=load(R/'inputs/V04_REPRESENTATIVE_INDEX_AFTER_D36.json')['representatives']; nodes=idx36[4988:5778]
    direct=classify_exact([idx36[i] for i in [5377,5761,5766,5777]],seed,workers=4)
    cm={r['id']:r for r in rows}
    if direct!=[cm[i] for i in [5377,5761,5766,5777]]: bad.append('direct_classifier_multiwall_mismatch')
    reps=load(R/'inputs/POSTV05_REPRESENTATIVE_INDEX_AFTER_D46.json')['representatives']; quot=load(R/'POSTV05_DEPTH37_4988_5777_QUOTIENT_SCC_TOOLKIT.json')
    _Q,_A,Qc,deck_named=seed_matrices(seed); deck=build_finite_group([g for _,g in deck_named],32)
    def smat(M):return tuple(tuple(int(x) for x in row) for row in M.tolist())
    def mm(A,B):
        C=list(zip(*B));return tuple(tuple(sum(a*b for a,b in zip(row,col)) for col in C) for row in A)
    def tr(A):return tuple(zip(*A))
    def neg(A):return tuple(tuple(-x for x in row) for row in A)
    def key(A):return tuple(x for row in A for x in row)
    D=[smat(x) for x in deck]; RR=[smat(x) for x in RELABEL]; Sm={w:smat(S[FIRST_MOVE[w]-1]) for w in FIRST_MOVE}; Wm={w:smat(WALL_ACTION[w]) for w in WALL_ACTION}; Q=smat(Qc)
    variants={}; current=[dict(x) for x in reps]
    def add(rid,A):
        for di,d in enumerate(D):
            DA=mm(d,A)
            for ri,r in enumerate(RR):
                X=mm(DA,r);variants.setdefault(key(X),(rid,di,ri,1));variants.setdefault(key(neg(X)),(rid,di,ri,-1))
    for x in current:add(int(x['id']),tuple(tuple(int(v) for v in row) for row in x['A']))
    got=[];new=[];next_id=len(current)
    for n in sorted(nodes,key=lambda n:(int(n['enlarged_source_scc']),int(n['id']))):
        A=tuple(tuple(int(v) for v in row) for row in n['A']);L=tuple(tuple(int(v) for v in row) for row in n['L']);scc=int(n['enlarged_source_scc'])
        for wall in cm[n['id']]['ordinary_walls']:
            An=mm(A,Sm[wall]);Ln=mm(Wm[wall],L);M=mm(mm(tr(An),Q),An);con=[sum(M[i][j] for j in range(3)) for i in range(3)]+[-M[0][1],-M[0][2],-M[1][2]];j2=sum(v*v for v in con)
            e={'source':n['id'],'wall':wall,'J2':str(j2),'enlarged_source_scc':scc};hit=variants.get(key(An))
            if hit is not None:
                target,di,ri,sign=hit;e.update(status='HIT',target=target,deck_index=di,relabel_index=ri,sign=sign)
            else:
                target=next_id;next_id+=1;e.update(status='NEW',target=target)
                nn={'id':target,'path_from_C2':n.get('path_from_C2','')+wall,'kind':'DEPTH38','depth':38,'source':n['id'],'arrival_wall':wall,'A':[[str(v) for v in row] for row in An],'L':[[str(v) for v in row] for row in Ln],'M':[[str(v) for v in row] for row in M],'J2':str(j2),'conorm6':[str(v) for v in con],'_layer':'d38-post-v05-cont16','enlarged_source_scc':scc}
                new.append(nn);current.append(nn);add(target,An)
            got.append(e)
    if got!=quot['events']: bad.append('event_replay_mismatch')
    if new!=quot['new_depth38_nodes']: bad.append('new_node_replay_mismatch')
    if len(current)!=6887: bad.append('final_index_size')
# static exact checks
expected_multi=[(5377,'114*q + 379*r - 201',['m','n']),(5761,'98*q + 345*r - 179',['g','m']),(5766,'98*q + 345*r - 179',['h','l']),(5777,'2*q + 5*r - 3',['h','k'])]
got_multi=[]
for r in rows:
    for c in r.get('multiwall_components',[]): got_multi.append((r['id'],c['factor'],c['walls']))
if got_multi!=expected_multi: bad.append('multiwall_list')
q=load(R/'POSTV05_DEPTH37_4988_5777_QUOTIENT_SCC_TOOLKIT.json')
if q['counts']!={'classes':790,'ordinary_exits':2892,'hits':1951,'new':941,'multiwall_cells':4}: bad.append('quotient_counts')
scc=load(R/'POSTV05_DEPTH37_SCC_RECALCULATION.json')
if scc['sizes']!=[4414,80,2,1,1,1,1]: bad.append('scc_sizes')
audit=load(R/'POSTV05_CONTINUATION_16_TOOLKIT_FREEZE_AUDIT.json')
if audit['status']!='PASS-TOOLKIT-0.5.0-FROZEN-UNCHANGED': bad.append('toolkit_freeze')
print(json.dumps({'status':'PASS' if not bad else 'FAIL','failed':bad,'classification':len(rows),'events':len(q['events']),'new':len(q['new_depth38_nodes']),'scc_sizes':scc['sizes']},sort_keys=True))
raise SystemExit(1 if bad else 0)
