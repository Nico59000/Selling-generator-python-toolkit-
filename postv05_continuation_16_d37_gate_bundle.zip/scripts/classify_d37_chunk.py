import sys,json,time,hashlib,os,argparse
sys.path.insert(0,'/mnt/data/post_v05/rel/src')
from selling_toolkit.layers import classify_exact
ap=argparse.ArgumentParser(); ap.add_argument('scc',type=int); ap.add_argument('start',type=int); ap.add_argument('count',type=int); ap.add_argument('--workers',type=int,default=12); a=ap.parse_args()
BASE='/mnt/data/post_v05/rel'; OUT='/mnt/data/post_v05/d37_gate/chunks'; os.makedirs(OUT,exist_ok=True)
seed=json.load(open(BASE+'/toolchain/synthetic_invariant_Qa.seed.json'))
reps=json.load(open(BASE+'/V04_REPRESENTATIVE_INDEX_AFTER_D36.json'))['representatives']
nodes=[n for n in reps[4988:5778] if int(n.get('enlarged_source_scc',-1))==a.scc]
sub=nodes[a.start:a.start+a.count]
if not sub: raise SystemExit('empty')
fn=f'd37_scc{a.scc}_{a.start:03d}_{a.start+len(sub)-1:03d}.json'; path=os.path.join(OUT,fn)
t=time.time(); rows=classify_exact(sub,seed,workers=min(a.workers,len(sub))); dt=time.time()-t
obj={'version':'post-v0.5-continuation-16','phase':'d37-classification-chunk','layer':'d37','source_scc':a.scc,'offset':[a.start,a.start+len(sub)-1],'id_range':[sub[0]['id'],sub[-1]['id']],'count':len(rows),'elapsed_seconds':dt,'results':rows}
raw=json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode(); h=hashlib.sha256(raw).hexdigest(); obj['sha256_without_self']=h
with open(path,'w') as f: json.dump(obj,f,indent=2,sort_keys=True); f.write('\n')
print(json.dumps({'file':fn,'scc':a.scc,'offset':obj['offset'],'ids':obj['id_range'],'count':len(rows),'seconds':round(dt,3),'ordinary':sum(len(r['ordinary_walls']) for r in rows),'multi_ids':[r['id'] for r in rows if r.get('multiwall_components')],'sha256_without_self':h}))
