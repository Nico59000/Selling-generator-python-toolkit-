#!/usr/bin/env python3
import json,hashlib,tempfile,zipfile,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def load(p):return json.load(open(p,encoding='utf-8'))
def mm(A,B):
    C=list(zip(*B));return tuple(tuple(sum(a*b for a,b in zip(row,col)) for col in C) for row in A)
def tr(A):return tuple(zip(*A))
def neg(A):return tuple(tuple(-x for x in row) for row in A)
def key(A):return tuple(x for row in A for x in row)
bad=[];rows=[]
for p in sorted((R/'chunks').glob('d48_*.json')):
 d=load(p);x=dict(d);h=x.pop('sha256_without_self',None);raw=json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
 if hashlib.sha256(raw).hexdigest()!=h:bad.append('chunk_hash:'+p.name)
 rows+=d['results']
rows.sort(key=lambda x:x['id']);clf=load(R/'POSTV05_DEPTH48_6887_7073_CLASSIFICATION.json')
if rows!=clf['results']:bad.append('chunk_assembly')
if [x['id'] for x in rows]!=list(range(6887,7074)):bad.append('coverage')
with tempfile.TemporaryDirectory() as td:
 zipfile.ZipFile(R/'inputs/selling_toolkit_v05_0_source.zip').extractall(td);sys.path.insert(0,td)
 from selling_toolkit.layers import classify_exact
 from selling_seed2d.algebra import S,FIRST_MOVE,WALL_ACTION,RELABEL,build_finite_group
 from selling_seed2d.seed import seed_matrices
 seed=load(R/'inputs/synthetic_invariant_Qa.seed.json');reps=load(R/'inputs/POSTV05_REPRESENTATIVE_INDEX_AFTER_D38.json')['representatives'];nodes=reps[6887:7074]
 direct=classify_exact(nodes,seed,workers=5)
 if direct!=rows:bad.append('full_reclassification_mismatch')
 _Q,_A,Qc,deck_named=seed_matrices(seed);deck=build_finite_group([g for _,g in deck_named],32)
 def smat(M):return tuple(tuple(int(x) for x in row) for row in M.tolist())
 D=[smat(x) for x in deck];RR=[smat(x) for x in RELABEL];Sm={w:smat(S[FIRST_MOVE[w]-1]) for w in FIRST_MOVE};Wm={w:smat(WALL_ACTION[w]) for w in WALL_ACTION};Q=smat(Qc)
 variants={};cur=[dict(x) for x in reps]
 def add(rid,A):
  for di,d in enumerate(D):
   DA=mm(d,A)
   for ri,r in enumerate(RR):
    X=mm(DA,r);variants.setdefault(key(X),(rid,di,ri,1));variants.setdefault(key(neg(X)),(rid,di,ri,-1))
 for x in cur:add(int(x['id']),tuple(tuple(int(v) for v in row) for row in x['A']))
 got=[];new=[];next_id=len(cur);cm={x['id']:x for x in rows}
 for n in nodes:
  A=tuple(tuple(int(v) for v in row) for row in n['A']);L=tuple(tuple(int(v) for v in row) for row in n['L'])
  for wall in cm[n['id']]['ordinary_walls']:
   An=mm(A,Sm[wall]);Ln=mm(Wm[wall],L);M=mm(mm(tr(An),Q),An);con=[sum(M[i][j] for j in range(3)) for i in range(3)]+[-M[0][1],-M[0][2],-M[1][2]];j2=sum(v*v for v in con);e={'source':n['id'],'wall':wall,'J2':str(j2)};hit=variants.get(key(An))
   if hit is not None:
    target,di,ri,sign=hit;e.update(status='HIT',target=target,deck_index=di,relabel_index=ri,sign=sign)
   else:
    target=next_id;next_id+=1;e.update(status='NEW',target=target);nn={'id':target,'path_from_C2':n.get('path_from_C2','')+wall,'kind':'DEPTH49','depth':49,'source':n['id'],'arrival_wall':wall,'A':[[str(v) for v in row] for row in An],'L':[[str(v) for v in row] for row in Ln],'M':[[str(v) for v in row] for row in M],'J2':str(j2),'conorm6':[str(v) for v in con],'_layer':'d49-post-v05-cont19'};new.append(nn);cur.append(nn);add(target,An)
   got.append(e)
 q=load(R/'POSTV05_DEPTH48_6887_7073_QUOTIENT_TOOLKIT.json')
 if got!=q['events']:bad.append('quotient_event_replay')
 if new!=q['new_depth49_nodes']:bad.append('new_nodes_replay')
 if len(cur)!=8454:bad.append('final_index_size')
rec=load(R/'POSTV05_MULTIWALL_RECURRENCE_AUDIT_D23_D48.json')
if rec['event_count']!=54 or rec['factor_family_count']!=5:bad.append('recurrence_counts')
if rec['pair_incidence']['adjacent_pairs_observed']!=12 or rec['pair_incidence']['opposite_pairs_observed']!=0:bad.append('incidence_census')
if rec['factor345']['event_count']!=14 or rec['factor345']['status'].split(';')[0].strip()!='CONTEXT/PENDING-MORPHISM for 345 <-> (3,4,5)':bad.append('345_guard')
a=load(R/'POSTV05_CONTINUATION_19_TOOLKIT_FREEZE_AUDIT.json')
if a['status']!='PASS-TOOLKIT-0.5.0-FROZEN-UNCHANGED':bad.append('toolkit_freeze')
print(json.dumps({'status':'PASS' if not bad else 'FAIL','failed':bad,'classification':len(rows),'events':696,'new':232,'index_last':8453,'recurrence_events':54,'factor_families':5,'adjacent_pairs':'12/12','opposite_pairs':'0/3'},sort_keys=True));raise SystemExit(1 if bad else 0)
