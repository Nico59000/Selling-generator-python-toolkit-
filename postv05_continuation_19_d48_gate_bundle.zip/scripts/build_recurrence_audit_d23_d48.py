import json,glob,collections,hashlib,math
from pathlib import Path
R=Path('/mnt/data/post_v05'); G=R/'d48_gate'
rows=[]
def add(layer,id,f,w,source): rows.append({'layer':layer,'depth':int(layer[1:]),'id':int(id),'factor':f,'walls':list(w),'source':source})
# d23 replay
for p in sorted(G.glob('historical_d23_*.json')):
 d=json.load(open(p));
 for x in d['results']:
  for c in x.get('multiwall_components',[]): add('d23',x['id'],c['factor'],c['walls'],'v05 exact replay of full d23 range 468..549')
# d24 checkpoint exact
add('d24',680,'2*q + 5*r - 3',['h','k'],'v0.4 continuation-3 sealed checkpoint')
add('d24',691,'2*q + 5*r - 3',['h','l'],'v0.4 continuation-3 sealed checkpoint')
# d25 exact replay is all zero, recorded separately
# d26..d35 exact replay of checkpoint multiwall ids
h=json.load(open(G/'POSTV05_HISTORICAL_MULTIWALL_REPLAY_D26_D35_V05.json'))
for x in h['results']:
 for c in x.get('multiwall_components',[]): add(x['layer'],x['id'],c['factor'],c['walls'],'v05 exact replay of append-only historical representative; 9/9 checkpoint-value control PASS')
# sealed newer classifications
sources=[
 ('d36',R/'rel/V04_DEPTH36_4188_4857_CLASSIFICATION_SCC.json','v0.5 release sealed classification'),
 ('d37',R/'d37_gate/POSTV05_DEPTH37_4988_5777_CLASSIFICATION_SCC.json','post-v0.5 continuation 16 sealed'),
 ('d38',R/'d38_gate/POSTV05_DEPTH38_5946_6886_CLASSIFICATION_SCC.json','post-v0.5 continuation 18 sealed'),
 ('d46',R/'d46_gate/POSTV05_DEPTH46_4858_4987_CLASSIFICATION.json','post-v0.5 continuation 15 sealed'),
 ('d47',R/'d47_gate/POSTV05_DEPTH47_5778_5945_CLASSIFICATION.json','post-v0.5 continuation 17 sealed'),
 ('d48',G/'POSTV05_DEPTH48_6887_7073_CLASSIFICATION.json','post-v0.5 continuation 19 preseal exact classification'),
]
for layer,p,src in sources:
 d=json.load(open(p)); arr=d.get('results',d.get('classification',[]))
 for x in arr:
  for c in x.get('multiwall_components',[]): add(layer,x['id'],c['factor'],c['walls'],src)
rows.sort(key=lambda x:x['id'])
# aggregate
by=collections.defaultdict(list)
for x in rows: by[x['factor']].append(x)
families=[]
for f,rr in sorted(by.items(),key=lambda kv:(-len(kv[1]),kv[0])):
 wp=collections.Counter(tuple(x['walls']) for x in rr)
 families.append({'factor':f,'event_count':len(rr),'depths':sorted(set(x['depth'] for x in rr)),
                  'layers':[f'd{d}' for d in sorted(set(x['depth'] for x in rr))],
                  'ids':[x['id'] for x in rr],
                  'wall_pair_counts':{'/'.join(k):v for k,v in sorted(wp.items())}})
# tetrahedral edge incidence census
edge={'g':'12','h':'13','k':'14','l':'34','m':'24','n':'23'}
all_pairs=[tuple(sorted((a,b))) for i,a in enumerate('ghklmn') for b in 'ghklmn'[i+1:]]
opp=[('g','l'),('h','m'),('k','n')]
pair_counts=collections.Counter(tuple(x['walls']) for x in rows)
adj=[p for p in all_pairs if p not in opp]
# full-range replay nulls / checkpoint no-multi layers
null_cert=[
 {'scope':'d25 ids 710..816','method':'107/107 exact v0.5 replay','multiwall_count':0},
 {'scope':'d33 preexisting ids 609..623','method':'15/15 exact v0.5 replay','multiwall_count':0},
 {'scope':'d34 preexisting ids 693..709','method':'17/17 exact v0.5 replay','multiwall_count':0},
 {'scope':'side frontiers d35 817..835, d36 941..966, d37 1097..1124, d38 1286..1323, d39 1505..1541, d40 1772..1820, d41 2083..2130, d42 2451..2523, d43 2909..2979, d44 3448..3537, d45 4078..4187','method':'sealed checkpoint declarations','multiwall_count':0}
]
obj={
 'version':'post-v0.5-continuation-19',
 'status':'PASS-PROVEN-EXACT-INCIDENCE-CENSUS-WITHIN-AUDITED-D23-D48-CORPUS',
 'scope_guard':'This is an exact census of audited closed/classified representatives and checkpoint-declared zero side frontiers; it is not an extrapolation theorem for future depths.',
 'event_count':len(rows),'factor_family_count':len(families),'events':rows,'families':families,
 'tetrahedral_wall_edge_map':edge,
 'pair_incidence':{
   'all_15_wall_pairs':[[''.join(p),pair_counts[p]] for p in all_pairs],
   'observed_distinct_pairs':len(pair_counts),
   'adjacent_pairs_total':12,'adjacent_pairs_observed':sum(1 for p in adj if pair_counts[p]>0),
   'opposite_pairs':[[''.join(p),pair_counts[p]] for p in opp],
   'opposite_pairs_observed':sum(1 for p in opp if pair_counts[p]>0),
   'verdict':'12/12 tetrahedral-adjacent edge pairs observed; 0/3 opposite edge pairs observed'
 },
 'null_multiwall_scopes':null_cert,
 'factor345':{
   'factor':'98*q + 345*r - 179','event_count':len(by['98*q + 345*r - 179']),
   'depths':sorted(set(x['depth'] for x in by['98*q + 345*r - 179'])),
   'status':'CONTEXT/PENDING-MORPHISM for 345 <-> (3,4,5); recurrence is exact but triangle interpretation is not promoted'
 },
 'typing_guards':[
   'factor recurrence is exact equality of primitive boundary factors, not yet a common source-native carrier',
   'tetrahedral adjacency census uses the source-certified wall-edge map; it does not imply a complete classification theorem for all future multiwalls',
   '345 <-> 3-4-5 remains CONTEXT/PENDING-MORPHISM',
   'no numeric equality or cardinality is a morphism'
 ]
}
raw=json.dumps(obj,sort_keys=True,separators=(',',':')).encode();obj['sha256_without_self']=hashlib.sha256(raw).hexdigest()
out=G/'POSTV05_MULTIWALL_RECURRENCE_AUDIT_D23_D48.json';out.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
# compact text
lines=['POST-V0.5 MULTIWALL RECURRENCE AUDIT D23..D48','',f"events={len(rows)} factor_families={len(families)}",'']
for f in families: lines.append(f"{f['factor']}: {f['event_count']} events; depths={','.join(map(str,f['depths']))}; pairs={f['wall_pair_counts']}")
lines += ['',obj['pair_incidence']['verdict'],'345 interpretation: CONTEXT/PENDING-MORPHISM','scope: exact audited corpus only']
(G/'POSTV05_MULTIWALL_RECURRENCE_AUDIT_D23_D48.txt').write_text('\n'.join(lines)+'\n')
print(json.dumps({'status':obj['status'],'events':len(rows),'families':[(x['factor'],x['event_count'],x['depths']) for x in families],'pair_incidence':obj['pair_incidence']['verdict'],'sha256_without_self':obj['sha256_without_self']},indent=2))
