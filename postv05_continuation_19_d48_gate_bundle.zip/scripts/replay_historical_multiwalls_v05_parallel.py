import json, sys, hashlib, os
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
ROOT=Path('/mnt/data/post_v05')
sys.path.insert(0,str(ROOT/'rel/src'))
from selling_toolkit.layers import imat
from selling_seed2d.chart import build_chart
from selling_seed2d.classifier import ExactBoundaryClassifier
_CLF=None

def init_worker(seed):
    global _CLF
    chart=build_chart(seed)
    _CLF=ExactBoundaryClassifier(chart.q,chart.r,chart.wall_vector,chart.D0)

def work(items):
    out=[]
    for layer,i,L in items:
        c=_CLF.classify_cell(imat(L))
        out.append({'layer':layer,'id':i,'ordinary_walls':list(c.get('ordinary_walls',[])),
                    'multiwall_components':[{'factor':z['factor'],'walls':list(z['walls'])} for z in c.get('multiwall_components',[])]})
    return out

idx=json.loads((ROOT/'d48_gate/POSTV05_REPRESENTATIVE_INDEX_AFTER_D48.json').read_text())
reps={int(x['id']):x for x in idx['representatives']}
ids_by_layer={
'd26':[879,922], 'd27':[1024], 'd28':[1285], 'd29':[1406,1490,1498],
'd30':[1760,1766,1771], 'd31':[1940,2070,2074], 'd32':[2283,2450],
'd33':[2895,2899], 'd34':[3214,3390,3396,3447], 'd35':[4013,4017,4065,4068,4077],
}
items=[(layer,i,reps[i]['L']) for layer,ids in ids_by_layer.items() for i in ids]
seed=json.loads((ROOT/'rel/toolchain/synthetic_invariant_Qa.seed.json').read_text())
w=5; groups=[items[i::w] for i in range(w)]
rows=[]
with ProcessPoolExecutor(max_workers=w,initializer=init_worker,initargs=(seed,)) as ex:
    fs=[ex.submit(work,g) for g in groups if g]
    for f in as_completed(fs): rows.extend(f.result())
rows.sort(key=lambda x:x['id'])
# validate known original checkpoint factors for d34/d35
expected={
3214:('2*q + 5*r - 3',['h','l']),3390:('362*q + 1389*r - 699',['h','n']),3396:('362*q + 1389*r - 699',['m','n']),3447:('2*q + 5*r - 3',['m','n']),
4013:('362*q + 1389*r - 699',['h','n']),4017:('362*q + 1389*r - 699',['h','n']),4065:('98*q + 345*r - 179',['m','n']),4068:('98*q + 345*r - 179',['h','l']),4077:('2*q + 5*r - 3',['l','m'])}
fail=[]
for r in rows:
    if r['id'] in expected:
        comps=r['multiwall_components']; e=expected[r['id']]
        if len(comps)!=1 or comps[0]['factor']!=e[0] or comps[0]['walls']!=e[1]: fail.append({'id':r['id'],'got':comps,'expected':e})
obj={'status':'PASS-EXACT-V05-HISTORICAL-ID-REPLAY' if not fail else 'REFUTED-MISMATCH','toolkit':'0.5.0-FROZEN','known_checkpoint_validation':'9/9 PASS' if not fail else fail,'results':rows}
raw=json.dumps(obj,sort_keys=True,separators=(',',':')).encode(); obj['sha256_without_self']=hashlib.sha256(raw).hexdigest()
out=ROOT/'d48_gate/POSTV05_HISTORICAL_MULTIWALL_REPLAY_D26_D35_V05.json'; out.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':obj['status'],'count':len(rows),'known_validation':obj['known_checkpoint_validation'],'rows':rows},indent=2))
