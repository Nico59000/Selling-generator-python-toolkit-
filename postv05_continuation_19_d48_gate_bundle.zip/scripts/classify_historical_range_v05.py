import sys,json,hashlib,os,argparse,time
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
ROOT=Path('/mnt/data/post_v05'); sys.path.insert(0,str(ROOT/'rel/src'))
from selling_toolkit.layers import imat
from selling_seed2d.chart import build_chart
from selling_seed2d.classifier import ExactBoundaryClassifier
_CLF=None
def init(seed):
 global _CLF
 c=build_chart(seed); _CLF=ExactBoundaryClassifier(c.q,c.r,c.wall_vector,c.D0)
def work(group):
 out=[]
 for x in group:
  c=_CLF.classify_cell(imat(x['L']))
  out.append({'id':int(x['id']),'ordinary_walls':list(c.get('ordinary_walls',[])),'multiwall_components':[{'factor':z['factor'],'walls':list(z['walls'])} for z in c.get('multiwall_components',[])]})
 return out
ap=argparse.ArgumentParser(); ap.add_argument('lo',type=int);ap.add_argument('hi',type=int);ap.add_argument('--workers',type=int,default=5);ap.add_argument('--tag',required=True); a=ap.parse_args()
idx=json.load(open(ROOT/'d48_gate/POSTV05_REPRESENTATIVE_INDEX_AFTER_D48.json'))['representatives']
nodes=[idx[i] for i in range(a.lo,a.hi+1)]
w=min(a.workers,len(nodes));groups=[nodes[i::w] for i in range(w)]; t=time.time(); rows=[]
seed=json.load(open(ROOT/'rel/toolchain/synthetic_invariant_Qa.seed.json'))
with ProcessPoolExecutor(max_workers=w,initializer=init,initargs=(seed,)) as ex:
 for f in as_completed([ex.submit(work,g) for g in groups if g]): rows.extend(f.result())
rows.sort(key=lambda x:x['id']);obj={'status':'PASS-EXACT-V05-REPLAY','range':[a.lo,a.hi],'count':len(rows),'elapsed_seconds':time.time()-t,'results':rows}
raw=json.dumps(obj,sort_keys=True,separators=(',',':')).encode();obj['sha256_without_self']=hashlib.sha256(raw).hexdigest()
out=ROOT/f'd48_gate/historical_{a.tag}_{a.lo}_{a.hi}.json';out.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
print(json.dumps({'file':out.name,'count':len(rows),'multi_ids':[x['id'] for x in rows if x['multiwall_components']],'multi':[(x['id'],x['multiwall_components']) for x in rows if x['multiwall_components']],'seconds':round(obj['elapsed_seconds'],2)}))
