import sympy as sp
from selling_toolkit.quartic import x,y,z,u,v,w,reconstruct_pascal_reduced,decompose_pascal_reduced,rho_covariant,reconstruct_lorentz_rho,reduce_to_pascal_coordinates
from selling_toolkit.extension import ProductLift3D5D,TrivialSellingLift3D5D

def test_pascal_roundtrip_and_rho():
    f=reconstruct_pascal_reduced(x**4-y**4,0,x*y,1)
    assert sp.expand(f-(x**4-y**4+6*x*y*z**2+z**4))==0
    d=decompose_pascal_reduced(f)
    assert sp.expand(d.polynomial()-f)==0
    assert sp.factor(rho_covariant(f)-(4*u*v-w**2)/4)==0

def test_noether_controls_zero():
    assert rho_covariant(x**4+y**4+z**4)==0
    assert rho_covariant(x**3*y+y**3*z+z**3*x)==0

def test_product_lift_roundtrip():
    L=ProductLift3D5D(); s=L.lift((1,2,3),(4,5))
    assert s==(1,2,3,4,5); assert L.project_base(s)==(1,2,3);assert L.project_fibre(s)==(4,5)


def test_inverse_lorentz_reconstruction():
    q=reconstruct_lorentz_rho(scale=1,A=1,c=1)
    assert sp.expand(q.polynomial()-(x**4-y**4+6*x*y*z**2+z**4))==0
    assert sp.factor(rho_covariant(q.polynomial())-(4*u*v-w**2)/4)==0
    q2=reconstruct_lorentz_rho(scale=6,A=2,c=1)
    assert sp.factor(rho_covariant(q2.polynomial())-6*(4*u*v-w**2)/4)==0


def test_general_z3_reduction_roundtrip():
    q=reconstruct_lorentz_rho(1,1,1).polynomial()
    ell=x+2*y
    original=sp.expand(q.subs(z,z+ell/4))
    red=reduce_to_pascal_coordinates(original)
    assert sp.expand(red["reduced"]-q)==0
    assert sp.expand(original-red["reduced"].subs(z,z+red["shift"]))==0


def test_passive_selling_5d_lift():
    Q=sp.Matrix([[2,1,0],[1,-3,1],[0,1,-2]])
    F=sp.Matrix([[1,0],[0,2]])
    L=TrivialSellingLift3D5D()
    assert all(L.congruence_identity(A,Q,F) for A in L.wall_base_matrices().values())
    assert len(L.wall_lifts())==6 and len(L.relabel_lifts())==24
    assert all(abs(int(A.det()))==1 for A in L.wall_lifts().values())

def test_gl3_rho_covariance_and_reconstruction():
    import sympy as sp
    from selling_toolkit.quartic import x,y,z,rho_covariant,reconstruct_gl3_lorentz_rho
    for A in [sp.Matrix([[1,1,0],[0,1,0],[0,0,1]]),sp.diag(2,1,1),sp.Matrix([[2,1,0],[0,1,0],[0,0,1]])]:
        r=reconstruct_gl3_lorentz_rho(A)
        assert sp.simplify(r['target_rho']-r['expected_rho'])==0

def test_projection_preserving_5d_lift_classification():
    import sympy as sp
    from selling_toolkit.extension import ProjectionPreservingLinearLift3D5D
    A=sp.Matrix([[1,1,0],[0,1,0],[0,0,1]])
    C=sp.Matrix([[1,0,0],[0,1,0]]);D=sp.Matrix([[1,1],[0,1]])
    T=ProjectionPreservingLinearLift3D5D.lift(A,C,D)
    assert ProjectionPreservingLinearLift3D5D.preserves_base_projection(T,A)
    assert not ProjectionPreservingLinearLift3D5D.fixes_fibre_pointwise(T)
    P=ProjectionPreservingLinearLift3D5D.lift(A)
    assert ProjectionPreservingLinearLift3D5D.preserves_base_projection(P,A)
    assert ProjectionPreservingLinearLift3D5D.fixes_fibre_pointwise(P)

def test_hasse_minkowski_and_explicit_isotropic_congruence():
    from selling_toolkit.rational_forms import compare_rational_congruence,explicit_isotropic_ternary_congruence
    from selling_toolkit.quartic import quadratic_matrix
    Q0=quadratic_matrix((4*u*v-w**2)/4)
    A=sp.Matrix([[2,1,0],[0,1,1],[0,0,1]])
    # ordinary rational congruence target
    Q1=sp.simplify(A.T*Q0*A)
    dec=compare_rational_congruence(Q0,Q1)
    assert dec['congruent'] and dec['tests']['hasse_all_places']
    ex=explicit_isotropic_ternary_congruence(Q0,Q1,bound=16)
    assert ex['status']=='PROVEN-EXPLICIT-RATIONAL-CONGRUENCE-WITNESS'
    X=sp.Matrix([[sp.Rational(v) for v in row] for row in ex['witness']])
    assert sp.simplify(X.T*Q0*X-Q1)==sp.zeros(3)
    bad=compare_rational_congruence(Q0,sp.diag(1,1,1))
    assert not bad['congruent']

def test_fixed_scale_quartic_covariance_orbit_solver():
    from selling_toolkit.rational_forms import fixed_scale_quartic_covariance_orbit
    from selling_toolkit.quartic import quadratic_matrix,transform_rho_gl3
    Q0=quadratic_matrix((4*u*v-w**2)/4)
    A0=sp.Matrix([[2,1,0],[0,1,0],[0,0,1]])
    qA=transform_rho_gl3((4*u*v-w**2)/4,A0)
    QA=quadratic_matrix(qA)
    r=fixed_scale_quartic_covariance_orbit(Q0,QA,bound=20)
    assert r['in_orbit'] and r['A_witness'] is not None
    A=sp.Matrix([[sp.Rational(v) for v in row] for row in r['A_witness']])
    assert sp.simplify(A.det()**6*A.inv()*Q0*A.inv().T-QA)==sp.zeros(3)
    # Congruent by diag(2,1,1), but determinant ratio =4, not a 16th power.
    X=sp.diag(2,1,1);Qbad=X.T*Q0*X
    bad=fixed_scale_quartic_covariance_orbit(Q0,Qbad,bound=20)
    assert bad['rational_congruence']['congruent'] and not bad['in_orbit']

def test_determinant_swap_selling_5d_lift():
    from selling_toolkit.extension import DeterminantSwapSellingLift3D5D,TrivialSellingLift3D5D
    L=DeterminantSwapSellingLift3D5D()
    walls=list(TrivialSellingLift3D5D.wall_base_matrices().values())
    J=sp.Matrix([[0,1],[1,0]])
    assert all(L.fibre_action(A)==J for A in walls)
    assert all(L.homomorphism_identity(A,B) for A in walls for B in walls)
    X,Y=sp.symbols('X Y')
    assert L.swap_flips_residual(X,Y)
    # two orientation-reversing wall steps act trivially on the fibre
    assert all((L.lift_matrix(A)*L.lift_matrix(B))[3:,3:]==sp.eye(2) for A in walls for B in walls)


def test_unbounded_constructive_isotropic_witness_and_congruence():
    from selling_toolkit.rational_forms import find_isotropic_vector_exact,explicit_isotropic_ternary_congruence_exact,fixed_scale_quartic_covariance_orbit_exact
    from selling_toolkit.quartic import quadratic_matrix,transform_rho_gl3
    Q0=quadratic_matrix((4*u*v-w**2)/4)
    A=sp.Matrix([[7,3,1],[2,5,1],[1,0,3]])
    Q1=sp.simplify(A.T*Q0*A)
    v0=find_isotropic_vector_exact(Q0);v1=find_isotropic_vector_exact(Q1)
    assert v0 is not None and v1 is not None
    assert sp.simplify((v0.T*Q0*v0)[0])==0 and sp.simplify((v1.T*Q1*v1)[0])==0
    ex=explicit_isotropic_ternary_congruence_exact(Q0,Q1)
    assert ex['witness'] is not None and ex['bounded_search_used'] is False
    X=sp.Matrix([[sp.Rational(v) for v in row] for row in ex['witness']])
    assert sp.simplify(X.T*Q0*X-Q1)==sp.zeros(3)
    A0=sp.Matrix([[2,1,0],[0,1,0],[0,0,1]])
    QA=quadratic_matrix(transform_rho_gl3((4*u*v-w**2)/4,A0))
    orb=fixed_scale_quartic_covariance_orbit_exact(Q0,QA)
    assert orb['in_orbit'] and orb['A_witness'] is not None and orb['bounded_search_used'] is False


def test_golden_residual_fibre_adapter():
    from selling_toolkit.extension import GoldenResidualFibreAdapter
    m=sp.symbols('m', positive=True)
    assert all(GoldenResidualFibreAdapter.identities(m).values())


def test_nonzero_C_coboundary_lift():
    from selling_toolkit.extension import CoboundaryCoupledSellingLift3D5D,TrivialSellingLift3D5D
    L=CoboundaryCoupledSellingLift3D5D(); walls=list(TrivialSellingLift3D5D.wall_base_matrices().values())
    assert any(L.C(A)!=sp.zeros(2,3) for A in walls)
    assert all(L.conjugacy_identity(A) for A in walls)
    assert all(L.homomorphism_identity(A,B) for A in walls for B in walls)

def test_det_swap_h1_no_go():
    from selling_toolkit.cohomology import DeterminantSwapH1NoGo
    c=DeterminantSwapH1NoGo.certificate()
    assert c['all_relation_matrix_identities_exact']
    assert c['constraint_rank']==30
    assert c['relation_solution_dimension']==6
    assert c['coboundary_rank']==6
    assert c['H1_dimension']==0

def test_golden_residual_affine_h1_no_go():
    from selling_toolkit.cohomology import GoldenResidualAffineH1NoGo
    c=GoldenResidualAffineH1NoGo.certificate()
    assert c['constraint_rank']==5
    assert c['relation_solution_dimension']==1
    assert c['coboundary_rank']==1
    assert c['H1_dimension']==0
    assert c['relation_nullspace']==[['1','1','1','1','1','1']]


def test_base_module_rank2_fibre_no_go():
    from selling_toolkit.fibre_representations import BaseModuleRank2FibreNoGo
    c=BaseModuleRank2FibreNoGo.certificate()
    assert c['generated_algebra_dimension']==9
    assert c['generated_algebra_equals_M3Q']
    assert c['commutant_dimension']==1
    assert c['irreducible_base_module']
    assert not c['rank2_subrepresentation_exists']
    assert not c['rank2_quotient_representation_exists']
