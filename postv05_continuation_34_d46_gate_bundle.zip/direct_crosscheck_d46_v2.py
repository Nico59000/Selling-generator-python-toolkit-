import json,sys,time,hashlib
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import sympy as sp
from sympy.core.cache import clear_cache
R=Path('/mnt/data/cont34/postseal_fresh_extract_v2'); sys.path.insert(0,str(R/'toolkit_src_extracted'))
from selling_seed2d.chart import build_chart
from selling_seed2d.classifier import ExactBoundaryClassifier
idx=json.load(open(R/'POSTV05_REPRESENTATIVE_INDEX_AFTER_D55.json'))['representatives']
seed=json.load(open(R/'inputs/synthetic_invariant_Qa.seed.json'))
multis=[24965,25132,25157,25393,25698,25770,25772,25791,26193,26271,26280,26480,26643,26652,27249,27253,27329,27338,27359,27364,27732,27748,28415,28474,28583,29052,29053,29054,29064,29065,29078]
ids=set(round(24953+i*(29078-24953)/49) for i in range(50)); ids.update(multis); ids=sorted(ids)
_G=None
def imat(rows): return sp.Matrix([[sp.Integer(v) for v in row] for row in rows])
def init_worker(seed):
 global _G
 c=build_chart(seed); _G=ExactBoundaryClassifier(c.q,c.r,c.wall_vector,c.D0)
def worker(i):
 try:
  c=_G.classify_cell(imat(idx[i]['L']))
  return {'id':i,'ordinary_walls':list(c['ordinary_walls']),'multiwall_components':[{'factor':z['factor'],'walls':list(z['walls'])} for z in c.get('multiwall_components',[])],'polynomials':c.get('polynomials',{})}
 finally: clear_cache()
t=time.time(); bad=[]; done=0
with ProcessPoolExecutor(max_workers=5,initializer=init_worker,initargs=(seed,)) as ex:
 futs={ex.submit(worker,i):i for i in ids}
 for f in as_completed(futs):
  x=f.result(); done+=1
  exp=json.load(open(R/'replay_chunks_v2'/f"{x['id']}.json"))
  if x!=exp: bad.append(x['id'])
  if done%10==0: print('P',done,'/',len(ids),'bad',len(bad),flush=True)
report={'version':'post-v0.5-continuation-34','status':'PASS' if not bad else 'FAIL','checked':len(ids),'ids':ids,'failures':bad,'multiwall_ids':multis,'multiwalls_checked':sum(i in ids for i in multis),'elapsed_seconds':time.time()-t,'method':'fresh frozen selling-toolkit 0.5.0 ExactBoundaryClassifier direct distributed crosscheck against immutable fresh replay v2'}
raw=json.dumps(report,sort_keys=True,separators=(',',':')).encode(); report['sha256_without_self']=hashlib.sha256(raw).hexdigest()
(R/'DIRECT_TOOLKIT_D46_CROSSCHECK_V2.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps(report,indent=2))
