import json,glob,hashlib,sys,time,collections
from pathlib import Path
BASE=Path('/mnt/data/cont34')
rows=sorted([json.load(open(f)) for f in glob.glob(str(BASE/'d46_fast/*.json'))],key=lambda x:x['id'])
assert len(rows)==4126 and [r['id'] for r in rows]==list(range(24953,29079))
counts={'classes':4126,'ordinary_exits':sum(len(r['ordinary_walls']) for r in rows),'multiwall_cells':sum(bool(r['multiwall_components']) for r in rows)}
obj={'version':'post-v0.5-continuation-34','gate':'d46 24953..29078','status':'PASS-4126/4126-EXACT','counts':counts,'classifications':rows,'validation':{'engine':'selling-toolkit-0.5.0 ExactBoundaryClassifier with exact polynomial-remainder root-sign optimization','direct_reference_crosscheck':'36/36 bit-identical before full census','direct_multiwall_recheck':'31/31 PASS original classifier'}}
raw=json.dumps(obj,sort_keys=True,separators=(',',':')).encode();obj['sha256_without_self']=hashlib.sha256(raw).hexdigest();(BASE/'POSTV05_DEPTH46_24953_29078_CLASSIFICATION.json').write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
prev=json.load(open(BASE/'base/POSTV05_MULTIWALL_RECURRENCE_AUDIT_AFTER_D55.json'))
idx=json.load(open(BASE/'base/POSTV05_REPRESENTATIVE_INDEX_AFTER_D55.json'))['representatives']
events=list(prev['events'])
for r in rows:
 for z in r['multiwall_components']:
  events.append({'depth':46,'factor':z['factor'],'id':r['id'],'layer':'d46','source':idx[r['id']]['source'],'walls':z['walls']})
fams={}
for e in events:
 f=e['factor'];fams.setdefault(f,{'factor':f,'ids':[],'depths':set(),'wall_pair_counts':collections.Counter()});fams[f]['ids'].append(e['id']);fams[f]['depths'].add(e['depth']);fams[f]['wall_pair_counts']['/'.join(e['walls'])]+=1
fl=[]
for f,d in sorted(fams.items()):fl.append({'factor':f,'event_count':len(d['ids']),'ids':d['ids'],'depths':sorted(d['depths']),'wall_pair_counts':dict(sorted(d['wall_pair_counts'].items()))})
pc=collections.Counter('/'.join(e['walls']) for e in events);oldf=set(x['factor'] for x in prev['families']);newf=sorted(set(z['factor'] for r in rows for z in r['multiwall_components'])-oldf)
aud={'version':'post-v0.5-continuation-34','status':'PASS-EXACT-APPEND-ONLY-MULTIWALL-CENSUS-AFTER-D46','event_count':len(events),'factor_family_count':len(fl),'events':events,'families':fl,'new_d46':{'cell_count':counts['multiwall_cells'],'event_count':sum(len(r['multiwall_components']) for r in rows),'ids':[r['id'] for r in rows if r['multiwall_components']],'new_primitive_factors':newf},'pair_incidence':{'adjacent_pairs_observed':len(pc),'counts':dict(sorted(pc.items())),'opposite_pairs_observed':0,'opposite_pairs':[]},'scope_guard':'append-only exact census through d46; no future extrapolation'}
raw=json.dumps(aud,sort_keys=True,separators=(',',':')).encode();aud['sha256_without_self']=hashlib.sha256(raw).hexdigest();(BASE/'POSTV05_MULTIWALL_RECURRENCE_AUDIT_AFTER_D46.json').write_text(json.dumps(aud,indent=2,sort_keys=True)+'\n')
print('classification',counts,'ledger',len(events),len(fl),'newf',newf,'ids',aud['new_d46']['ids'],'pairs',len(pc),flush=True)
# quotient only after 4126/4126 assertions
sys.path.insert(0,str(BASE/'toolkit_src'))
from selling_toolkit.fast_layers import quotient_layer_fast,FastHitRange
seed=json.load(open(BASE/'base/inputs/synthetic_invariant_Qa.seed.json')); reps=idx;nodes=[reps[i] for i in range(24953,29079)]
ranges=[FastHitRange('older_0_8221',0,8221),FastHitRange('d49',8222,8453),FastHitRange('d40',8454,9822),FastHitRange('d50',9823,10103),FastHitRange('d41',10104,11754),FastHitRange('d51',11755,12089),FastHitRange('d42',12090,14087),FastHitRange('d52',14088,14477),FastHitRange('d43',14478,16874),FastHitRange('d53',16875,17361),FastHitRange('d44',17362,20236),FastHitRange('d54',20237,20814),FastHitRange('d45',20815,24255),FastHitRange('d55',24256,24952),FastHitRange('d46',24953,29078),FastHitRange('d56-index-only',29079,29933)]
t=time.time();q=quotient_layer_fast(seed=seed,global_representatives=reps,nodes=nodes,classifications=rows,target_depth=47,kind='DEPTH47',layer_label='d47-post-v05-cont34',hit_ranges=ranges);elapsed=time.time()-t
qo={'version':'post-v0.5-continuation-34','phase':'d46-quotient','status':'PASS-4126/4126-EXACT-QUOTIENTED','engine':'selling-toolkit-0.5.0 FastCanonicalIndex int64 guarded','processing_order':'id','known_index_before':'0..29933','counts':q['counts'],'hit_buckets':q['hit_buckets'],'events':q['events'],'multiwalls':q['multiwalls'],'new_depth47_nodes':q['new_nodes'],'elapsed_seconds':elapsed,'guards':['complete current global index 0..29933 used','d56 29079..29933 treated as known index-only/HIT-only and not classified','new d47 representatives inserted immediately for deterministic same-pass collapse','d56 classification not opened','next lateral layer not opened']}
raw=json.dumps(qo,sort_keys=True,separators=(',',':')).encode();qo['sha256_without_self']=hashlib.sha256(raw).hexdigest();(BASE/'POSTV05_DEPTH46_24953_29078_QUOTIENT_TOOLKIT.json').write_text(json.dumps(qo,indent=2,sort_keys=True)+'\n')
idxo={'version':'post-v0.5-continuation-34','status':'INDEX-AFTER-D46','representatives':q['representatives_after']};raw=json.dumps(idxo,sort_keys=True,separators=(',',':')).encode();idxo['sha256_without_self']=hashlib.sha256(raw).hexdigest();(BASE/'POSTV05_REPRESENTATIVE_INDEX_AFTER_D46.json').write_text(json.dumps(idxo,indent=2,sort_keys=True)+'\n')
print('quotient',q['counts'],'hit_buckets',q['hit_buckets'],'new_range',([q['new_nodes'][0]['id'],q['new_nodes'][-1]['id']] if q['new_nodes'] else None),'index_last',len(q['representatives_after'])-1,'elapsed',round(elapsed,3),flush=True)
