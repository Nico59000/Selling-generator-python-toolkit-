from __future__ import annotations

from dataclasses import dataclass
from collections import Counter
from concurrent.futures import ProcessPoolExecutor, as_completed
from typing import Any, Iterable, Mapping, Sequence
import sys
import sympy as sp

from selling_seed2d.algebra import (
    S, FIRST_MOVE, WALL_ACTION, RELABEL, matrix_key, build_finite_group,
)
from selling_seed2d.seed import seed_matrices
from selling_seed2d.chart import build_chart
from selling_seed2d.classifier import ExactBoundaryClassifier


def imat(rows: Sequence[Sequence[Any]]) -> sp.Matrix:
    return sp.Matrix([[sp.Integer(v) for v in row] for row in rows])


def strmat(M: sp.Matrix) -> list[list[str]]:
    return [[str(v) for v in row] for row in M.tolist()]


def j2_conorm6(M: sp.Matrix) -> tuple[int, list[int]]:
    vals = [sum(M[i, j] for j in range(3)) for i in range(3)] + [
        -M[0, 1], -M[0, 2], -M[1, 2]
    ]
    return int(sum(v * v for v in vals)), [int(v) for v in vals]


@dataclass(frozen=True)
class HitRange:
    name: str
    start: int
    stop: int  # inclusive

    def contains(self, value: int) -> bool:
        return self.start <= value <= self.stop


class CanonicalIndex:
    """Exact canonical lookup under deck x superbase-relabel x projective sign."""

    def __init__(self, seed: Mapping[str, Any], representatives: Sequence[Mapping[str, Any]]):
        _Q, _A0, self.Qc, deck_named = seed_matrices(dict(seed))
        self.deck = build_finite_group([g for _, g in deck_named], 32)
        self.variants: dict[tuple[str, ...], tuple[int, int, int, int]] = {}
        self.representatives: list[dict[str, Any]] = [dict(x) for x in representatives]
        ids = [int(x["id"]) for x in self.representatives]
        if ids != list(range(len(ids))):
            raise ValueError("representative ids must be contiguous from zero")
        for x in self.representatives:
            self.add(int(x["id"]), imat(x["A"]))

    def add(self, rep_id: int, A: sp.Matrix) -> None:
        for di, D in enumerate(self.deck):
            DA = D * A
            for ri, R in enumerate(RELABEL):
                X = DA * R
                self.variants.setdefault(matrix_key(X), (rep_id, di, ri, +1))
                self.variants.setdefault(matrix_key(-X), (rep_id, di, ri, -1))

    def lookup(self, A: sp.Matrix):
        return self.variants.get(matrix_key(A))

    @property
    def next_id(self) -> int:
        return len(self.representatives)


def _classify_payload(payload: tuple[dict[str, Any], dict[str, Any]]) -> dict[str, Any]:
    node, seed = payload
    chart = build_chart(seed)
    clf = ExactBoundaryClassifier(chart.q, chart.r, chart.wall_vector, chart.D0)
    c = clf.classify_cell(imat(node["L"]))
    return {
        "id": int(node["id"]),
        "ordinary_walls": list(c["ordinary_walls"]),
        "multiwall_components": [
            {"factor": z["factor"], "walls": list(z["walls"])}
            for z in c.get("multiwall_components", [])
        ],
        "polynomials": c.get("polynomials", {}),
    }


def classify_exact(nodes: Sequence[Mapping[str, Any]], seed: Mapping[str, Any], workers: int = 1) -> list[dict[str, Any]]:
    """Classify a whole layer exactly; caller controls atomic publication."""
    payload = [(dict(n), dict(seed)) for n in nodes]
    if workers <= 1:
        rows = [_classify_payload(x) for x in payload]
    else:
        rows = []
        with ProcessPoolExecutor(max_workers=workers) as ex:
            futs = [ex.submit(_classify_payload, x) for x in payload]
            for fut in as_completed(futs):
                rows.append(fut.result())
    return sorted(rows, key=lambda r: r["id"])


def bucket_target(target: int, ranges: Sequence[HitRange], same_pass_start: int) -> str:
    if target >= same_pass_start:
        return "same-pass"
    for r in ranges:
        if r.contains(target):
            return r.name
    return "unbucketed-known"


def quotient_layer(
    *,
    seed: Mapping[str, Any],
    global_representatives: Sequence[Mapping[str, Any]],
    nodes: Sequence[Mapping[str, Any]],
    classifications: Sequence[Mapping[str, Any]],
    target_depth: int,
    kind: str,
    layer_label: str,
    hit_ranges: Sequence[HitRange] = (),
    source_scc: Mapping[int, int] | None = None,
) -> dict[str, Any]:
    """Quotient ordinary exits of a fully classified layer against a global index.

    Multiwall components are retained in `multiwalls` and never expanded into
    ordinary exits. New representatives are inserted immediately so same-pass
    duplicates collapse deterministically.
    """
    idx = CanonicalIndex(seed, global_representatives)
    cmap = {int(r["id"]): dict(r) for r in classifications}
    nmap = {int(n["id"]): dict(n) for n in nodes}
    if set(cmap) != set(nmap):
        raise ValueError("classification/node id mismatch")
    next_id = idx.next_id
    same_pass_start = next_id
    events: list[dict[str, Any]] = []
    new_nodes: list[dict[str, Any]] = []
    buckets: Counter[str] = Counter()
    order = sorted(nmap)
    if source_scc is not None:
        order.sort(key=lambda i: (source_scc[int(nmap[i]["source"])], i))

    for i in order:
        n = nmap[i]
        A = imat(n["A"])
        L = imat(n["L"])
        scc = source_scc[int(n["source"])] if source_scc is not None else None
        for wall in cmap[i]["ordinary_walls"]:
            An = A * S[FIRST_MOVE[wall] - 1]
            Ln = WALL_ACTION[wall] * L
            M = An.T * idx.Qc * An
            j2, con = j2_conorm6(M)
            event: dict[str, Any] = {"source": i, "wall": wall, "J2": str(j2)}
            if scc is not None:
                event["enlarged_source_scc"] = int(scc)
            hit = idx.lookup(An)
            if hit is not None:
                target, di, ri, sign = hit
                event.update(status="HIT", target=target, deck_index=di, relabel_index=ri, sign=sign)
                buckets[bucket_target(target, hit_ranges, same_pass_start)] += 1
            else:
                target = next_id
                next_id += 1
                event.update(status="NEW", target=target)
                nn: dict[str, Any] = {
                    "id": target,
                    "path_from_C2": n.get("path_from_C2", "") + wall,
                    "kind": kind,
                    "depth": target_depth,
                    "source": i,
                    "arrival_wall": wall,
                    "A": strmat(An),
                    "L": strmat(Ln),
                    "M": strmat(M),
                    "J2": str(j2),
                    "conorm6": [str(v) for v in con],
                    "_layer": layer_label,
                }
                if scc is not None:
                    nn["enlarged_source_scc"] = int(scc)
                new_nodes.append(nn)
                idx.representatives.append(nn)
                idx.add(target, An)
            events.append(event)

    multiwalls = [
        {"id": int(r["id"]), "ordinary_walls": list(r["ordinary_walls"]), "components": list(r.get("multiwall_components", []))}
        for r in classifications if r.get("multiwall_components")
    ]
    return {
        "events": events,
        "new_nodes": new_nodes,
        "multiwalls": multiwalls,
        "hit_buckets": dict(buckets),
        "counts": {
            "classes": len(nodes),
            "ordinary_exits": len(events),
            "hits": sum(e["status"] == "HIT" for e in events),
            "new": len(new_nodes),
            "multiwall_cells": len(multiwalls),
        },
        "representatives_after": idx.representatives,
    }


def tarjan_scc(vertices: Iterable[int], edges: Iterable[tuple[int, int]]) -> dict[str, Any]:
    V = list(vertices)
    Vset = set(V)
    adj = {v: [] for v in V}
    edge_list = []
    for a, b in edges:
        if a in Vset and b in Vset:
            adj[a].append(b)
            edge_list.append((a, b))
    sys.setrecursionlimit(max(30000, len(V) * 10 + 1000))
    stack: list[int] = []
    on: set[int] = set()
    index: dict[int, int] = {}
    low: dict[int, int] = {}
    comps: list[list[int]] = []
    counter = [0]

    def visit(v: int) -> None:
        index[v] = low[v] = counter[0]
        counter[0] += 1
        stack.append(v); on.add(v)
        for w in adj[v]:
            if w not in index:
                visit(w); low[v] = min(low[v], low[w])
            elif w in on:
                low[v] = min(low[v], index[w])
        if low[v] == index[v]:
            c = []
            while True:
                w = stack.pop(); on.remove(w); c.append(w)
                if w == v:
                    break
            comps.append(sorted(c))

    for v in V:
        if v not in index:
            visit(v)
    comps.sort(key=lambda c: (-len(c), c[0]))
    cid = {v: i for i, c in enumerate(comps) for v in c}
    cond: Counter[tuple[int, int]] = Counter()
    for a, b in edge_list:
        if cid[a] != cid[b]:
            cond[(cid[a], cid[b])] += 1
    return {
        "vertex_count": len(V),
        "count": len(comps),
        "sizes": [len(c) for c in comps],
        "components": [{"scc": i, "size": len(c), "ids": c} for i, c in enumerate(comps)],
        "condensation_edges": [{"from": a, "to": b, "count": n} for (a, b), n in sorted(cond.items())],
    }
