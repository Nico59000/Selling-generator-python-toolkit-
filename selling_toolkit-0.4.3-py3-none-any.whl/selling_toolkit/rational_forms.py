from __future__ import annotations
from dataclasses import dataclass
from itertools import product
from math import gcd,isqrt
from functools import reduce
import sympy as sp
from sympy.solvers.diophantine.diophantine import diop_ternary_quadratic


def _Q(M):
    M=sp.Matrix(M)
    return M.applyfunc(sp.Rational)

def diagonalize_congruence(Q: sp.Matrix):
    """Exact rational congruence diagonalization P.T*Q*P=D."""
    M=_Q(Q)
    if M.rows!=M.cols or M!=M.T: raise ValueError('Q must be symmetric square')
    n=M.rows; P=sp.eye(n)
    for k in range(n):
        piv=None
        for i in range(k,n):
            if M[i,i]!=0: piv=i; break
        if piv is None:
            pair=None
            for i in range(k,n):
                for j in range(i+1,n):
                    if M[i,j]!=0: pair=(i,j); break
                if pair: break
            if pair is None:
                # remaining radical
                continue
            i,j=pair
            E=sp.eye(n); E[j,i]=1
            M=sp.simplify(E.T*M*E); P=P*E; piv=i
        if piv!=k:
            E=sp.eye(n); E.col_swap(k,piv)
            M=sp.simplify(E.T*M*E); P=P*E
        a=sp.Rational(M[k,k])
        if a==0: continue
        E=sp.eye(n)
        for j in range(k+1,n):
            E[k,j]=-sp.Rational(M[k,j],a)
        M=sp.simplify(E.T*M*E); P=P*E
    D=M.applyfunc(sp.factor)
    # exact guard
    if sp.simplify(P.T*_Q(Q)*P-D)!=sp.zeros(n): raise AssertionError('diagonalization guard failed')
    return P,D

def squareclass_int(q) -> int:
    """Signed squarefree integer representing q in Q*/Q*^2."""
    q=sp.Rational(q)
    if q==0:return 0
    s=-1 if q<0 else 1; q=abs(q)
    fn=sp.factorint(int(q.p)); fd=sp.factorint(int(q.q))
    out=s
    for p,e in fn.items():
        if e%2: out*=int(p)
    for p,e in fd.items():
        if e%2: out*=int(p)  # p^-1 and p have the same square class
    return out

def rational_sqrt(q):
    q=sp.Rational(q)
    if q<0:return None
    np,nq=int(q.p),int(q.q); a=isqrt(np);b=isqrt(nq)
    return sp.Rational(a,b) if a*a==np and b*b==nq else None

def _legendre_unit(u:int,p:int)->int:
    r=pow(u%p,(p-1)//2,p)
    if r==1:return 1
    if r==p-1:return -1
    raise ValueError('unit unexpectedly divisible by p')

def hilbert_symbol(a,b,place):
    """Hilbert symbol (a,b)_v for nonzero rationals, v='inf' or prime."""
    a=sp.Rational(a); b=sp.Rational(b)
    if a==0 or b==0: raise ValueError('Hilbert symbol requires nonzero entries')
    if place=='inf': return -1 if a<0 and b<0 else 1
    p=int(place)
    if not sp.isprime(p): raise ValueError('finite place must be prime')
    A=squareclass_int(a); B=squareclass_int(b)
    if p==2:
        alpha=1 if A%2==0 else 0; beta=1 if B%2==0 else 0
        ua=A//(2 if alpha else 1); ub=B//(2 if beta else 1)
        epsa=((ua-1)//2)%2; epsb=((ub-1)//2)%2
        oma=((ua*ua-1)//8)%2; omb=((ub*ub-1)//8)%2
        e=(epsa*epsb + alpha*omb + beta*oma)%2
        return -1 if e else 1
    alpha=1 if A%p==0 else 0; beta=1 if B%p==0 else 0
    ua=A//(p if alpha else 1); ub=B//(p if beta else 1)
    out=-1 if (alpha*beta*((p-1)//2))%2 else 1
    if beta: out*=_legendre_unit(ua,p)
    if alpha: out*=_legendre_unit(ub,p)
    return out

def hasse_invariant_diagonal(diag,place):
    d=[sp.Rational(x) for x in diag if x!=0]
    out=1
    for i in range(len(d)):
        for j in range(i+1,len(d)): out*=hilbert_symbol(d[i],d[j],place)
    return out

def _relevant_primes(diag):
    ps={2}
    for a in diag:
        s=abs(squareclass_int(a))
        if s:
            ps.update(int(p) for p in sp.factorint(s))
    return sorted(ps)

def quadratic_form_invariants(Q):
    Q=_Q(Q); P,D=diagonalize_congruence(Q); diag=[sp.Rational(D[i,i]) for i in range(D.rows)]
    rank=sum(x!=0 for x in diag)
    if rank!=Q.rows: raise ValueError('only nondegenerate forms are supported by this invariant packet')
    sig=(sum(1 for x in diag if x>0),sum(1 for x in diag if x<0),0)
    det=sp.factor(Q.det()); primes=_relevant_primes(diag)
    hasse={str(p):hasse_invariant_diagonal(diag,p) for p in primes}
    hasse['inf']=hasse_invariant_diagonal(diag,'inf')
    return {'dimension':Q.rows,'rank':rank,'determinant':str(det),'determinant_squareclass':squareclass_int(det),'signed_discriminant_squareclass':squareclass_int(((-1)**(Q.rows*(Q.rows-1)//2))*det),'signature':list(sig),'diagonal':[str(x) for x in diag],'relevant_primes':primes,'hasse':hasse,'diagonalizer':[[str(v) for v in row] for row in P.tolist()]}

def compare_rational_congruence(Q1,Q2):
    """Complete Hasse-Minkowski decision for nondegenerate rational forms."""
    a=quadratic_form_invariants(Q1); b=quadratic_form_invariants(Q2)
    if a['dimension']!=b['dimension'] or a['rank']!=b['rank']:
        return {'congruent':False,'status':'REFUTED-DIMENSION-OR-RANK','left':a,'right':b,'places':{}}
    primes=sorted(set(a['relevant_primes'])|set(b['relevant_primes']))
    # recompute at union places from diagonal packets
    da=list(map(sp.Rational,a['diagonal'])); db=list(map(sp.Rational,b['diagonal']))
    places={str(p):[hasse_invariant_diagonal(da,p),hasse_invariant_diagonal(db,p)] for p in primes}
    places['inf']=[hasse_invariant_diagonal(da,'inf'),hasse_invariant_diagonal(db,'inf')]
    tests={
      'determinant_squareclass':a['determinant_squareclass']==b['determinant_squareclass'],
      'signature':a['signature']==b['signature'],
      'hasse_all_places':all(x==y for x,y in places.values()),
    }
    ok=all(tests.values())
    return {'congruent':ok,'status':'PROVEN-CONGRUENT-BY-HASSE-MINKOWSKI' if ok else 'REFUTED-BY-RATIONAL-QUADRATIC-FORM-INVARIANT','tests':tests,'places':places,'left':a,'right':b}

def _primitive_triples(bound:int):
    for m in range(1,bound+1):
        # shell max norm m, deterministic
        for a in range(-m,m+1):
            for b in range(-m,m+1):
                for c in range(-m,m+1):
                    if max(abs(a),abs(b),abs(c))!=m or (a==b==c==0): continue
                    g=gcd(gcd(abs(a),abs(b)),abs(c))
                    if g!=1: continue
                    # projective sign normalization
                    first=next(x for x in (a,b,c) if x)
                    if first<0: continue
                    yield sp.Matrix([a,b,c])

def find_isotropic_vector(Q,bound=24):
    Q=_Q(Q)
    for v in _primitive_triples(bound):
        if (v.T*Q*v)[0]==0:return v
    return None

def isotropic_ternary_normal_form(Q,bound=24):
    """Construct P with P.T Q P = H + <c>, H=[[0,1/2],[1/2,0]]."""
    Q=_Q(Q)
    if Q.shape!=(3,3) or Q.det()==0: raise ValueError('expected nondegenerate ternary form')
    v=find_isotropic_vector(Q,bound=bound)
    if v is None:return None
    t=None;b=None
    for e in [sp.eye(3).col(i) for i in range(3)]:
        be=sp.factor((v.T*Q*e)[0])
        if be!=0:t=e;b=be;break
    if t is None: raise AssertionError('nondegenerate form paired isotropic vector with nothing')
    qt=sp.factor((t.T*Q*t)[0]); w=sp.simplify(t-sp.Rational(qt,2*b)*v)
    b2=sp.factor((v.T*Q*w)[0]); assert b2==b and (w.T*Q*w)[0]==0
    A=sp.Matrix.vstack((v.T*Q),(w.T*Q)); ns=A.nullspace()
    if len(ns)!=1: raise AssertionError('orthogonal line not one-dimensional')
    z=ns[0]; c=sp.factor((z.T*Q*z)[0])
    if c==0: raise AssertionError('orthogonal line unexpectedly isotropic/radical')
    wn=sp.simplify(w/(2*b)); P=v.row_join(wn).row_join(z)
    D=sp.simplify(P.T*Q*P)
    expected=sp.Matrix([[0,sp.Rational(1,2),0],[sp.Rational(1,2),0,0],[0,0,c]])
    if sp.simplify(D-expected)!=sp.zeros(3):raise AssertionError('isotropic normalization failed')
    return {'P':P,'c':c,'isotropic_vector':v,'D':D}

def explicit_isotropic_ternary_congruence(Q1,Q2,bound=24):
    """Explicit witness X with X.T Q1 X=Q2 when both ternary forms are
    rationally isotropic and the anisotropic-line ratio is a rational square.
    The bounded isotropic search is the only incomplete step.
    """
    Q1=_Q(Q1);Q2=_Q(Q2)
    decision=compare_rational_congruence(Q1,Q2)
    if not decision['congruent']:
        return {'status':decision['status'],'decision':decision,'witness':None}
    n1=isotropic_ternary_normal_form(Q1,bound);n2=isotropic_ternary_normal_form(Q2,bound)
    if n1 is None or n2 is None:
        return {'status':'PROVEN-CONGRUENT-BY-HASSE-MINKOWSKI / EXPLICIT-WITNESS-NT-BOUNDED-ISOTROPIC-SEARCH','decision':decision,'witness':None,'bound':bound}
    s=rational_sqrt(sp.Rational(n2['c'],n1['c']))
    if s is None:
        # try sign-equivalent choice cannot alter c square class; this should not happen if congruent.
        raise AssertionError('congruent isotropic ternary forms yielded nonsquare anisotropic ratio')
    S=sp.diag(1,1,s); X=sp.simplify(n1['P']*S*n2['P'].inv())
    if sp.simplify(X.T*Q1*X-Q2)!=sp.zeros(3):raise AssertionError('explicit congruence witness failed')
    return {'status':'PROVEN-EXPLICIT-RATIONAL-CONGRUENCE-WITNESS','decision':decision,'bound':bound,'left_isotropic_vector':[str(x) for x in n1['isotropic_vector']],'right_isotropic_vector':[str(x) for x in n2['isotropic_vector']],'anisotropic_ratio':str(sp.factor(n2['c']/n1['c'])),'witness':[[str(v) for v in row] for row in X.tolist()]}

def rational_nth_root_positive(q,n:int):
    q=sp.Rational(q)
    if q<0 or n<=0:return None
    def iroot_exact(m,n):
        if m==0:return 0
        lo,hi=0,1
        while hi**n<m: hi*=2
        while lo+1<hi:
            mid=(lo+hi)//2
            if mid**n<m:lo=mid
            else:hi=mid
        return hi if hi**n==m else None
    a=iroot_exact(int(q.p),n); b=iroot_exact(int(q.q),n)
    return sp.Rational(a,b) if a is not None and b is not None else None

def fixed_scale_quartic_covariance_orbit(Qbase,Qtarget,bound=24):
    """Decision/witness for Qtarget = det(A)^6 A^-1 Qbase A^-T, A in GL3(Q).

    For ternary forms, determinant ratio must be a positive 16th power.
    Rational congruence is decided by Hasse-Minkowski. On the isotropic branch,
    an explicit congruence witness is built by bounded search and converted to A.
    """
    Qbase=_Q(Qbase); Qtarget=_Q(Qtarget)
    dec=compare_rational_congruence(Qbase,Qtarget)
    ratio=sp.factor(Qtarget.det()/Qbase.det())
    root16=rational_nth_root_positive(ratio,16)
    det_test=root16 is not None
    if not dec['congruent'] or not det_test:
        return {'in_orbit':False,'status':'REFUTED-FIXED-SCALE-QUARTIC-COVARIANCE-ORBIT','rational_congruence':dec,'determinant_ratio':str(ratio),'determinant_ratio_is_16th_power':det_test,'A_witness':None}
    ex=explicit_isotropic_ternary_congruence(Qbase,Qtarget,bound=bound)
    if ex.get('witness') is None:
        return {'in_orbit':True,'status':'PROVEN-IN-ORBIT-BY-HASSE-MINKOWSKI+DET16 / A-WITNESS-NT-BOUNDED-ISOTROPIC-SEARCH','rational_congruence':dec,'determinant_ratio':str(ratio),'determinant_ratio_is_16th_power':True,'A_witness':None,'congruence_witness_status':ex['status']}
    X=sp.Matrix([[sp.Rational(v) for v in row] for row in ex['witness']])
    if X.det()<0:X=-X
    d=rational_nth_root_positive(sp.factor(X.det()),8)
    if d is None: raise AssertionError('det16 condition and congruence witness determinant inconsistent')
    A=sp.simplify(d**3*X.inv().T)
    lhs=sp.simplify(A.det()**6*A.inv()*Qbase*A.inv().T)
    if sp.simplify(lhs-Qtarget)!=sp.zeros(3):raise AssertionError('quartic covariance A witness failed')
    return {'in_orbit':True,'status':'PROVEN-EXPLICIT-FIXED-SCALE-QUARTIC-COVARIANCE-A-WITNESS','rational_congruence':dec,'determinant_ratio':str(ratio),'determinant_ratio_is_16th_power':True,'congruence_witness':ex['witness'],'A_witness':[[str(v) for v in row] for row in A.tolist()],'det_A':str(sp.factor(A.det()))}


def find_isotropic_vector_exact(Q):
    """Construct an exact rational isotropic vector for a ternary form.

    This path has no coefficient/vector search bound.  Denominators are cleared
    and SymPy's exact homogeneous-ternary-quadratic solver is used to construct
    one integral solution, which is then verified against the original Q-form.
    If the exact solver does not return a nonzero solution, ``None`` is returned
    and callers must keep the explicit witness NT rather than infer one.
    """
    Q=_Q(Q)
    if Q.shape!=(3,3) or Q.det()==0: raise ValueError('expected nondegenerate ternary form')
    X=sp.symbols('x_iso y_iso z_iso', integer=True)
    v=sp.Matrix(X)
    expr=sp.expand((v.T*Q*v)[0])
    P=sp.Poly(expr,*X,domain=sp.QQ)
    den=sp.ilcm(*[sp.Rational(c).q for _,c in P.terms()]) if P.terms() else 1
    iexpr=sp.expand(expr*den)
    sol=diop_ternary_quadratic(iexpr)
    if not sol or any(a is None for a in sol): return None
    vv=sp.Matrix([sp.Rational(a) for a in sol])
    if vv==sp.zeros(3,1): return None
    # primitive integral normalization when possible
    dens=[sp.Rational(a).q for a in vv]; L=sp.ilcm(*dens)
    ints=[int(sp.Rational(a)*L) for a in vv]
    g=reduce(gcd,[abs(a) for a in ints if a] or [1])
    ints=[a//g for a in ints]
    first=next((a for a in ints if a),1)
    if first<0: ints=[-a for a in ints]
    vv=sp.Matrix(ints)
    if sp.simplify((vv.T*Q*vv)[0])!=0: raise AssertionError('exact isotropic solver returned invalid witness')
    return vv


def _isotropic_normal_form_from_vector(Q,v):
    Q=_Q(Q); v=sp.Matrix(v)
    if v.shape!=(3,1) or v==sp.zeros(3,1) or sp.simplify((v.T*Q*v)[0])!=0:
        raise ValueError('v must be a nonzero Q-isotropic column vector')
    t=None;b=None
    for e in [sp.eye(3).col(i) for i in range(3)]:
        be=sp.factor((v.T*Q*e)[0])
        if be!=0:t=e;b=be;break
    if t is None: raise AssertionError('nondegenerate form paired isotropic vector with nothing')
    qt=sp.factor((t.T*Q*t)[0]); w=sp.simplify(t-sp.Rational(qt,2*b)*v)
    b2=sp.factor((v.T*Q*w)[0]); assert b2==b and sp.simplify((w.T*Q*w)[0])==0
    A=sp.Matrix.vstack((v.T*Q),(w.T*Q)); ns=A.nullspace()
    if len(ns)!=1: raise AssertionError('orthogonal line not one-dimensional')
    z=ns[0]; c=sp.factor((z.T*Q*z)[0])
    if c==0: raise AssertionError('orthogonal line unexpectedly isotropic/radical')
    wn=sp.simplify(w/(2*b)); P=v.row_join(wn).row_join(z)
    D=sp.simplify(P.T*Q*P)
    expected=sp.Matrix([[0,sp.Rational(1,2),0],[sp.Rational(1,2),0,0],[0,0,c]])
    if sp.simplify(D-expected)!=sp.zeros(3):raise AssertionError('isotropic normalization failed')
    return {'P':P,'c':c,'isotropic_vector':v,'D':D}


def isotropic_ternary_normal_form_exact(Q):
    """Unbounded constructive isotropic normal form when an exact witness exists."""
    Q=_Q(Q); v=find_isotropic_vector_exact(Q)
    return None if v is None else _isotropic_normal_form_from_vector(Q,v)


def explicit_isotropic_ternary_congruence_exact(Q1,Q2):
    """Construct X with X.T Q1 X=Q2 without bounded isotropic-vector search.

    Hasse--Minkowski is used for the complete rational congruence decision.
    On the rationally isotropic ternary branch an exact Diophantine solver
    constructs both isotropic vectors and the witness is then certified by
    direct matrix equality.
    """
    Q1=_Q(Q1);Q2=_Q(Q2)
    decision=compare_rational_congruence(Q1,Q2)
    if not decision['congruent']:
        return {'status':decision['status'],'decision':decision,'witness':None,'bounded_search_used':False}
    n1=isotropic_ternary_normal_form_exact(Q1); n2=isotropic_ternary_normal_form_exact(Q2)
    if n1 is None or n2 is None:
        return {'status':'PROVEN-CONGRUENT-BY-HASSE-MINKOWSKI / EXPLICIT-WITNESS-NT-EXACT-DIOPHANTINE-SOLVER-RETURNED-NONE','decision':decision,'witness':None,'bounded_search_used':False}
    s=rational_sqrt(sp.Rational(n2['c'],n1['c']))
    if s is None: raise AssertionError('congruent isotropic ternary forms yielded nonsquare anisotropic ratio')
    S=sp.diag(1,1,s); X=sp.simplify(n1['P']*S*n2['P'].inv())
    if sp.simplify(X.T*Q1*X-Q2)!=sp.zeros(3):raise AssertionError('explicit exact congruence witness failed')
    return {'status':'PROVEN-EXPLICIT-RATIONAL-CONGRUENCE-WITNESS-UNBOUNDED-CONSTRUCTIVE','decision':decision,'bounded_search_used':False,'left_isotropic_vector':[str(x) for x in n1['isotropic_vector']],'right_isotropic_vector':[str(x) for x in n2['isotropic_vector']],'anisotropic_ratio':str(sp.factor(n2['c']/n1['c'])),'witness':[[str(v) for v in row] for row in X.tolist()]}


def fixed_scale_quartic_covariance_orbit_exact(Qbase,Qtarget):
    """Constructive fixed-scale quartic-covariance orbit test without bounded search."""
    Qbase=_Q(Qbase);Qtarget=_Q(Qtarget)
    dec=compare_rational_congruence(Qbase,Qtarget)
    ratio=sp.factor(Qtarget.det()/Qbase.det()); root16=rational_nth_root_positive(ratio,16)
    det_test=root16 is not None
    if not dec['congruent'] or not det_test:
        return {'in_orbit':False,'status':'REFUTED-FIXED-SCALE-QUARTIC-COVARIANCE-ORBIT','rational_congruence':dec,'determinant_ratio':str(ratio),'determinant_ratio_is_16th_power':det_test,'A_witness':None,'bounded_search_used':False}
    ex=explicit_isotropic_ternary_congruence_exact(Qbase,Qtarget)
    if ex.get('witness') is None:
        return {'in_orbit':True,'status':'PROVEN-IN-ORBIT-BY-HASSE-MINKOWSKI+DET16 / A-WITNESS-NT-EXACT-DIOPHANTINE-SOLVER-RETURNED-NONE','rational_congruence':dec,'determinant_ratio':str(ratio),'determinant_ratio_is_16th_power':True,'A_witness':None,'bounded_search_used':False,'congruence_witness_status':ex['status']}
    X=sp.Matrix([[sp.Rational(v) for v in row] for row in ex['witness']])
    if X.det()<0:X=-X
    d=rational_nth_root_positive(sp.factor(X.det()),8)
    if d is None: raise AssertionError('det16 condition and congruence witness determinant inconsistent')
    A=sp.simplify(d**3*X.inv().T)
    lhs=sp.simplify(A.det()**6*A.inv()*Qbase*A.inv().T)
    if sp.simplify(lhs-Qtarget)!=sp.zeros(3):raise AssertionError('quartic covariance exact A witness failed')
    return {'in_orbit':True,'status':'PROVEN-EXPLICIT-FIXED-SCALE-QUARTIC-COVARIANCE-A-WITNESS-UNBOUNDED-CONSTRUCTIVE','rational_congruence':dec,'determinant_ratio':str(ratio),'determinant_ratio_is_16th_power':True,'congruence_witness':ex['witness'],'A_witness':[[str(v) for v in row] for row in A.tolist()],'det_A':str(sp.factor(A.det())),'bounded_search_used':False}
