from __future__ import annotations
from collections import Counter
from dataclasses import dataclass
from typing import Any,Mapping,Sequence
import numpy as np
from selling_seed2d.algebra import S,FIRST_MOVE,WALL_ACTION,RELABEL,build_finite_group
from selling_seed2d.seed import seed_matrices

I64=np.iinfo(np.int64)
def _arr(M):
    a=np.array([[int(v) for v in row] for row in M.tolist()],dtype=np.int64)
    return a
def _rows(x): return [[str(int(v)) for v in row] for row in x.tolist()]
def _key(x): return tuple(int(v) for v in x.ravel())
def _safe_mm(a,b):
    # project values are far from i64 bound; explicit conservative operand guard
    ma=int(np.max(np.abs(a))) if a.size else 0; mb=int(np.max(np.abs(b))) if b.size else 0
    if ma and mb and ma*mb*max(a.shape[1],1) > I64.max//4:
        raise OverflowError('int64 guard triggered; use exact-object fallback')
    return a@b

@dataclass(frozen=True)
class FastHitRange:
    name:str;start:int;stop:int
    def contains(self,v:int)->bool:return self.start<=v<=self.stop

class FastCanonicalIndex:
    def __init__(self,seed:Mapping[str,Any],reps:Sequence[Mapping[str,Any]]):
        _Q,_A,self.Qc_sym,deck_named=seed_matrices(dict(seed));self.Qc=_arr(self.Qc_sym)
        self.deck=[_arr(x) for x in build_finite_group([g for _,g in deck_named],32)]
        self.rel=[_arr(x) for x in RELABEL]
        self.variants={};self.representatives=[dict(x) for x in reps]
        ids=[int(x['id']) for x in reps]
        if ids!=list(range(len(ids))):raise ValueError('representative ids must be contiguous')
        for x in reps:self.add(int(x['id']),np.array(x['A'],dtype=np.int64))
    def add(self,rid,A):
        for di,D in enumerate(self.deck):
            DA=_safe_mm(D,A)
            for ri,R in enumerate(self.rel):
                X=_safe_mm(DA,R);k=_key(X);kn=tuple(-v for v in k)
                self.variants.setdefault(k,(rid,di,ri,1));self.variants.setdefault(kn,(rid,di,ri,-1))
    def lookup(self,A):return self.variants.get(_key(A))
    @property
    def next_id(self):return len(self.representatives)

def _bucket(t,ranges,same):
    if t>=same:return 'same-pass'
    for r in ranges:
        if r.contains(t):return r.name
    return 'unbucketed-known'

def quotient_layer_fast(*,seed,global_representatives,nodes,classifications,target_depth,kind,layer_label,hit_ranges=(),source_scc=None):
    idx=FastCanonicalIndex(seed,global_representatives)
    cmap={int(r['id']):dict(r) for r in classifications};nmap={int(n['id']):dict(n) for n in nodes}
    if set(cmap)!=set(nmap):raise ValueError('classification/node mismatch')
    Sm={w:_arr(S[FIRST_MOVE[w]-1]) for w in FIRST_MOVE}; Wm={w:_arr(WALL_ACTION[w]) for w in WALL_ACTION}
    next_id=idx.next_id;same=next_id;events=[];new=[];buckets=Counter();order=sorted(nmap)
    if source_scc is not None:order.sort(key=lambda i:(source_scc[int(nmap[i]['source'])],i))
    for i in order:
        n=nmap[i];A=np.array(n['A'],dtype=np.int64);L=np.array(n['L'],dtype=np.int64);scc=source_scc[int(n['source'])] if source_scc is not None else None
        for wall in cmap[i]['ordinary_walls']:
            An=_safe_mm(A,Sm[wall]);Ln=_safe_mm(Wm[wall],L);M=_safe_mm(_safe_mm(An.T,idx.Qc),An)
            con=[int(sum(M[i,j] for j in range(3))) for i in range(3)]+[-int(M[0,1]),-int(M[0,2]),-int(M[1,2])]
            j2=sum(v*v for v in con);e={'source':i,'wall':wall,'J2':str(j2)}
            if scc is not None:e['enlarged_source_scc']=int(scc)
            hit=idx.lookup(An)
            if hit is not None:
                target,di,ri,sign=hit;e.update(status='HIT',target=target,deck_index=di,relabel_index=ri,sign=sign);buckets[_bucket(target,hit_ranges,same)]+=1
            else:
                target=next_id;next_id+=1;e.update(status='NEW',target=target)
                nn={'id':target,'path_from_C2':n.get('path_from_C2','')+wall,'kind':kind,'depth':target_depth,'source':i,'arrival_wall':wall,'A':_rows(An),'L':_rows(Ln),'M':_rows(M),'J2':str(j2),'conorm6':[str(v) for v in con],'_layer':layer_label}
                if scc is not None:nn['enlarged_source_scc']=int(scc)
                new.append(nn);idx.representatives.append(nn);idx.add(target,An)
            events.append(e)
    multi=[{'id':int(r['id']),'ordinary_walls':list(r['ordinary_walls']),'components':list(r.get('multiwall_components',[]))} for r in classifications if r.get('multiwall_components')]
    return {'events':events,'new_nodes':new,'multiwalls':multi,'hit_buckets':dict(buckets),'counts':{'classes':len(nodes),'ordinary_exits':len(events),'hits':sum(e['status']=='HIT' for e in events),'new':len(new),'multiwall_cells':len(multi)},'representatives_after':idx.representatives}
