from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from math import factorial
from typing import Any, Mapping
import sympy as sp

x, y, z = sp.symbols("x y z")
u, v, w = sp.symbols("u v w")

BASIS4 = [
    (4,0,0),(3,1,0),(2,2,0),(1,3,0),(0,4,0),
    (3,0,1),(2,1,1),(1,2,1),(0,3,1),
    (2,0,2),(1,1,2),(0,2,2),(1,0,3),(0,1,3),(0,0,4),
]
MULT4 = {e: factorial(4)//(factorial(e[0])*factorial(e[1])*factorial(e[2])) for e in BASIS4}


def _binary_degree(poly: sp.Expr, degree: int) -> sp.Expr:
    poly = sp.expand(poly)
    if poly == 0:
        return sp.Integer(0)
    p = sp.Poly(poly, x, y, domain=sp.QQ)
    if any(sum(m) != degree for m, _ in p.terms()):
        raise ValueError(f"binary form must be homogeneous of degree {degree}")
    return poly


@dataclass(frozen=True)
class PascalReducedQuartic:
    """Pascal/Brioschi reduced z-expansion.

    f = alpha(x,y) + 4 beta(x,y) z + 6 gamma(x,y) z^2 + a z^4.
    The z^3 coefficient is zero by the reduced-coordinate convention.
    """
    alpha: sp.Expr
    beta: sp.Expr
    gamma: sp.Expr
    a: sp.Rational | int

    def __post_init__(self):
        object.__setattr__(self, "alpha", _binary_degree(self.alpha, 4))
        object.__setattr__(self, "beta", _binary_degree(self.beta, 3))
        object.__setattr__(self, "gamma", _binary_degree(self.gamma, 2))
        object.__setattr__(self, "a", sp.Rational(self.a))

    def polynomial(self) -> sp.Expr:
        return sp.expand(self.alpha + 4*self.beta*z + 6*self.gamma*z**2 + self.a*z**4)

    def coefficient_blocks(self) -> dict[str, str]:
        return {"alpha": str(self.alpha), "beta": str(self.beta), "gamma": str(self.gamma), "a": str(self.a)}


def reconstruct_pascal_reduced(alpha: sp.Expr, beta: sp.Expr, gamma: sp.Expr, a: Any) -> sp.Expr:
    return PascalReducedQuartic(alpha, beta, gamma, a).polynomial()


def decompose_pascal_reduced(f: sp.Expr) -> PascalReducedQuartic:
    P = sp.Poly(sp.expand(f), x, y, z, domain=sp.QQ)
    if any(sum(m) != 4 for m, _ in P.terms()):
        raise ValueError("f must be a homogeneous ternary quartic")
    z3 = sum(c*x**m[0]*y**m[1] for m,c in P.terms() if m[2] == 3)
    if sp.expand(z3) != 0:
        raise ValueError("quartic is not in Pascal reduced coordinates: nonzero z^3 block")
    alpha = sum(c*x**m[0]*y**m[1] for m,c in P.terms() if m[2] == 0)
    beta4 = sum(c*x**m[0]*y**m[1] for m,c in P.terms() if m[2] == 1)
    gamma6 = sum(c*x**m[0]*y**m[1] for m,c in P.terms() if m[2] == 2)
    a_terms = [c for m,c in P.terms() if m == (0,0,4)]
    a = a_terms[0] if a_terms else 0
    return PascalReducedQuartic(sp.expand(alpha), sp.expand(sp.Rational(1,4)*beta4), sp.expand(sp.Rational(1,6)*gamma6), a)


@lru_cache(maxsize=1)
def _rho_kernel() -> sp.Poly:
    x1,y1,z1,x2,y2,z2,x3,y3,z3 = sp.symbols("x1 y1 z1 x2 y2 z2 x3 y3 z3")
    A12=sp.Matrix([[u,x1,x2],[v,y1,y2],[w,z1,z2]])
    A23=sp.Matrix([[u,x2,x3],[v,y2,y3],[w,z2,z3]])
    A31=sp.Matrix([[u,x3,x1],[v,y3,y1],[w,z3,z1]])
    gens=(u,v,w,x1,y1,z1,x2,y2,z2,x3,y3,z3)
    return sp.Poly(sp.expand(A12.det()**2*A23.det()**2*A31.det()**2/sp.Integer(6)), *gens, domain=sp.QQ)


def quartic_actual_coefficients(f: sp.Expr) -> dict[tuple[int,int,int], sp.Rational]:
    P = sp.Poly(sp.expand(f), x, y, z, domain=sp.QQ)
    if any(sum(m) != 4 for m, _ in P.terms()):
        raise ValueError("f must be homogeneous of degree four")
    return {m: sp.Rational(c) for m,c in P.terms()}


def rho_covariant(f: sp.Expr) -> sp.Expr:
    """Exact v54 rho = D_f(psi)/144 for a ternary quartic."""
    actual = quartic_actual_coefficients(f)
    normalized = {e: sp.Rational(actual.get(e,0), MULT4[e]) for e in BASIS4}
    psi = 0
    for mon, k in _rho_kernel().terms():
        eu,ev,ew = mon[:3]
        c1 = normalized.get(mon[3:6], 0)
        c2 = normalized.get(mon[6:9], 0)
        c3 = normalized.get(mon[9:12], 0)
        if c1 and c2 and c3:
            psi += k*c1*c2*c3*u**eu*v**ev*w**ew
    psi = sp.expand(psi)
    D = 0
    for e, a in actual.items():
        if a:
            D += a*sp.diff(psi, u,e[0], v,e[1], w,e[2])
    return sp.factor(sp.expand(D/sp.Integer(144)))


def quadratic_matrix(q: sp.Expr) -> sp.Matrix:
    q = sp.expand(q)
    P = sp.Poly(q, u, v, w, domain=sp.QQ)
    Q = sp.zeros(3)
    vars_ = [u,v,w]
    for i,t in enumerate(vars_): Q[i,i] = P.coeff_monomial(t**2)
    for i in range(3):
        for j in range(i+1,3):
            c=P.coeff_monomial(vars_[i]*vars_[j]); Q[i,j]=Q[j,i]=sp.Rational(c,2)
    return Q


def reconstruct_lorentz_rho(scale=1, A=1, c=1) -> PascalReducedQuartic:
    """Exact inverse recipe for rho = scale*(4*u*v-w**2)/4.

    On the Pascal subfamily
        f = A*x^4 + B*y^4 + 6*G*x*y*z^2 + C*z^4
    one has
        rho = -A*B*G*(4*C*u*v-G*w**2)/4.
    Setting G=C=c and B=-scale/(A*c**2) gives the target Lorentz form.
    """
    A=sp.Rational(A); c=sp.Rational(c); scale=sp.Rational(scale)
    if A == 0 or c == 0:
        raise ValueError("A and c must be nonzero")
    B=-scale/(A*c**2)
    return PascalReducedQuartic(A*x**4+B*y**4, sp.Integer(0), c*x*y, c)


def reduce_to_pascal_coordinates(f: sp.Expr):
    """Eliminate the z^3 block by an exact homogeneous linear shift when [z^4]f != 0.

    If f = a z^4 + ell(x,y) z^3 + ..., set old_z = new_z - ell/(4a).
    The returned polynomial is in Pascal reduced coordinates and is accompanied
    by the exact shift. No variable permutation is performed when a=0.
    """
    P=sp.Poly(sp.expand(f),x,y,z,domain=sp.QQ)
    if any(sum(m)!=4 for m,_ in P.terms()):
        raise ValueError("f must be a homogeneous ternary quartic")
    a=P.coeff_monomial(z**4)
    if a==0:
        raise ValueError("z^4 coefficient is zero; choose another pivot coordinate explicitly")
    ell=sp.expand(sum(c*x**m[0]*y**m[1] for m,c in P.terms() if m[2]==3))
    shift=sp.factor(ell/(4*a))
    reduced=sp.expand(f.subs(z,z-shift))
    dec=decompose_pascal_reduced(reduced)
    return {"reduced":reduced,"decomposition":dec,"shift":shift,"old_z_in_terms_of_new_z":sp.expand(z-shift)}

def transform_quartic_gl3(f: sp.Expr, A: sp.Matrix) -> sp.Expr:
    """Return f(A*x) for an invertible 3x3 rational matrix A."""
    A=sp.Matrix(A)
    if A.shape!=(3,3) or A.det()==0: raise ValueError('A must be invertible 3x3')
    X=sp.Matrix([x,y,z]); Y=A*X
    return sp.expand(f.subs({x:Y[0],y:Y[1],z:Y[2]}, simultaneous=True))


def transform_rho_gl3(q: sp.Expr, A: sp.Matrix) -> sp.Expr:
    """GL3 covariance target: det(A)^6 q(A^{-T}U)."""
    A=sp.Matrix(A)
    if A.shape!=(3,3) or A.det()==0: raise ValueError('A must be invertible 3x3')
    U=sp.Matrix([u,v,w]); V=A.inv().T*U
    return sp.factor(sp.expand(A.det()**6*q.subs({u:V[0],v:V[1],w:V[2]}, simultaneous=True)))


def reconstruct_gl3_lorentz_rho(A: sp.Matrix, scale=1, quartic_A=1, c=1) -> dict[str, sp.Expr]:
    """Reconstruct an explicit quartic whose rho lies in the GL3(Q) orbit
    of scale*(4uv-w^2)/4.

    This requires an explicit rational invertible A; equal real signature alone
    is not treated as a rational-congruence certificate.
    """
    base=reconstruct_lorentz_rho(scale=scale,A=quartic_A,c=c)
    f0=base.polynomial(); fA=transform_quartic_gl3(f0,A)
    q0=rho_covariant(f0); expected=transform_rho_gl3(q0,A); actual=rho_covariant(fA)
    if sp.simplify(actual-expected)!=0: raise AssertionError('GL3 rho covariance replay failed')
    return {'base_quartic':f0,'transformed_quartic':fA,'base_rho':q0,'target_rho':actual,'expected_rho':expected}
