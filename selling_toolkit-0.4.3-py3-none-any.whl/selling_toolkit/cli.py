from __future__ import annotations
import argparse,json
import sympy as sp
from .quartic import x,y,z,u,v,w,rho_covariant,decompose_pascal_reduced,reconstruct_lorentz_rho,reduce_to_pascal_coordinates,quadratic_matrix
from .extension import TrivialSellingLift3D5D,DeterminantSwapSellingLift3D5D,GoldenResidualFibreAdapter,CoboundaryCoupledSellingLift3D5D
from .rational_forms import compare_rational_congruence,fixed_scale_quartic_covariance_orbit_exact,explicit_isotropic_ternary_congruence_exact

def _mat(s):
    x=sp.sympify(s)
    M=sp.Matrix(x)
    if M.shape!=(3,3):raise ValueError('expected a 3x3 matrix expression')
    return M

def main():
    p=argparse.ArgumentParser(prog="selling-toolkit")
    sub=p.add_subparsers(dest="cmd",required=True)
    q=sub.add_parser("rho",help="compute exact v54 rho of a ternary quartic")
    q.add_argument("expr"); q.add_argument("--decompose-pascal",action="store_true")
    r=sub.add_parser("reconstruct-rho",help="reconstruct a Pascal quartic with rho=lambda*(4uv-w^2)/4")
    r.add_argument("--scale",default="1");r.add_argument("--A",default="1");r.add_argument("--c",default="1")
    d=sub.add_parser("reduce-pascal",help="eliminate the z^3 block with the z^4 pivot")
    d.add_argument("expr")
    l=sub.add_parser("lift5d",help="report a guarded exact 3D->5D Selling lift")
    l.add_argument("--mode",choices=["passive","det-swap","coboundary"],default="passive")
    c=sub.add_parser("congruence",help="compare two rational symmetric ternary matrices by Hasse-Minkowski")
    c.add_argument("left");c.add_argument("right")
    o=sub.add_parser("quartic-orbit",help="test fixed-scale quartic-covariance orbit of two rho matrices")
    o.add_argument("base");o.add_argument("target")
    e=sub.add_parser("congruence-witness",help="construct an exact rational ternary congruence witness without bounded isotropic search")
    e.add_argument("left");e.add_argument("right")
    g=sub.add_parser("golden-adapter",help="report the exact determinant-swap to golden-residual fibre adapter")
    g.add_argument("--magnitude",default="1")
    a=p.parse_args()
    if a.cmd=="rho":
        f=sp.sympify(a.expr,locals={"x":x,"y":y,"z":z});out={"quartic":str(sp.expand(f)),"rho":str(rho_covariant(f))}
        if a.decompose_pascal:out["pascal_reduced"]=decompose_pascal_reduced(f).coefficient_blocks()
    elif a.cmd=="reconstruct-rho":
        q=reconstruct_lorentz_rho(sp.Rational(a.scale),sp.Rational(a.A),sp.Rational(a.c));out={"quartic":str(q.polynomial()),"blocks":q.coefficient_blocks(),"rho":str(rho_covariant(q.polynomial()))}
    elif a.cmd=="reduce-pascal":
        f=sp.sympify(a.expr,locals={"x":x,"y":y,"z":z});r0=reduce_to_pascal_coordinates(f);out={"reduced":str(r0["reduced"]),"shift":str(r0["shift"]),"blocks":r0["decomposition"].coefficient_blocks()}
    elif a.cmd=="congruence":out=compare_rational_congruence(_mat(a.left),_mat(a.right))
    elif a.cmd=="quartic-orbit":out=fixed_scale_quartic_covariance_orbit_exact(_mat(a.base),_mat(a.target))
    elif a.cmd=="congruence-witness":out=explicit_isotropic_ternary_congruence_exact(_mat(a.left),_mat(a.right))
    elif a.cmd=="golden-adapter":
        m=sp.sympify(a.magnitude);out={"status":GoldenResidualFibreAdapter.status,"mu":str(GoldenResidualFibreAdapter.mu()),"nu":str(GoldenResidualFibreAdapter.nu()),"Gamma_plus":[str(x) for x in GoldenResidualFibreAdapter.gamma(m,+1)],"Gamma_minus":[str(x) for x in GoldenResidualFibreAdapter.gamma(m,-1)],"identities":GoldenResidualFibreAdapter.identities(m)}
    else:
        L=TrivialSellingLift3D5D() if a.mode=='passive' else (DeterminantSwapSellingLift3D5D() if a.mode=='det-swap' else CoboundaryCoupledSellingLift3D5D())
        out={"status":L.status}
        if a.mode in ('passive','det-swap'): out['wall_lifts']={k:[[str(v) for v in row] for row in M.tolist()] for k,M in L.wall_lifts().items()}
        else:
            walls=TrivialSellingLift3D5D.wall_base_matrices();out['wall_lifts']={k:[[str(v) for v in row] for row in L.lift_matrix(M).tolist()] for k,M in walls.items()};out['C_blocks']={k:[[str(v) for v in row] for row in L.C(M).tolist()] for k,M in walls.items()}
        if a.mode=='passive':out['relabel_count']=len(L.relabel_lifts())
    print(json.dumps(out,indent=2))
