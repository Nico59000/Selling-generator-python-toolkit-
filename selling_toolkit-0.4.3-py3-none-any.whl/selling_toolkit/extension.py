from __future__ import annotations
from dataclasses import dataclass
from typing import Sequence
import sympy as sp
from selling_seed2d.algebra import S,FIRST_MOVE,RELABEL

@dataclass(frozen=True)
class ProductLift3D5D:
    """Guarded coordinate product B3 x F2."""
    base_labels: tuple[str,str,str] = ("b1","b2","b3")
    fibre_labels: tuple[str,str] = ("f+","f-")
    status: str = "PROVEN-PRODUCT-LIFT/SEPARATED-FROM-5D-SELLING-DYNAMICS"

    def lift(self, base3: Sequence[float], fibre2: Sequence[float]) -> tuple[float,float,float,float,float]:
        if len(base3) != 3 or len(fibre2) != 2:
            raise ValueError("expected 3 base coordinates and 2 fibre coordinates")
        return tuple(base3) + tuple(fibre2)

    def project_base(self, state5: Sequence[float]) -> tuple[float,float,float]:
        if len(state5) != 5: raise ValueError("expected five coordinates")
        return tuple(state5[:3])

    def project_fibre(self, state5: Sequence[float]) -> tuple[float,float]:
        if len(state5) != 5: raise ValueError("expected five coordinates")
        return tuple(state5[3:])

@dataclass(frozen=True)
class TrivialSellingLift3D5D:
    """Exact passive-fibre lift of the current 3D Selling transformation system.

    A 3x3 transformation A is sent to diag(A,I2).  For any symmetric Q3 and
    any symmetric fibre form F2,
      lift(A)^T (Q3 direct_sum F2) lift(A)
        = (A^T Q3 A) direct_sum F2.
    Thus the 3D dynamics is recovered by projection and the fibre is passive.
    This is NOT a claim of a native coupled 5D Selling wall/conorm theory.
    """
    status: str = "PROVEN-EXACT-PASSIVE-FIBRE-SELLING-LIFT / COUPLED-5D-SELLING-NT"

    @staticmethod
    def lift_matrix(A3: sp.Matrix) -> sp.Matrix:
        A3=sp.Matrix(A3)
        if A3.shape != (3,3): raise ValueError("A3 must be 3x3")
        return sp.diag(A3,sp.eye(2))

    @staticmethod
    def lift_gram(Q3: sp.Matrix,F2: sp.Matrix) -> sp.Matrix:
        Q3=sp.Matrix(Q3);F2=sp.Matrix(F2)
        if Q3.shape!=(3,3) or F2.shape!=(2,2): raise ValueError("expected Q3 3x3 and F2 2x2")
        if Q3!=Q3.T or F2!=F2.T: raise ValueError("forms must be symmetric")
        return sp.diag(Q3,F2)

    @classmethod
    def congruence_identity(cls,A3:sp.Matrix,Q3:sp.Matrix,F2:sp.Matrix) -> bool:
        A5=cls.lift_matrix(A3); Q5=cls.lift_gram(Q3,F2)
        rhs=cls.lift_gram(sp.Matrix(A3).T*sp.Matrix(Q3)*sp.Matrix(A3),F2)
        return sp.simplify(A5.T*Q5*A5-rhs)==sp.zeros(5)

    @classmethod
    def wall_base_matrices(cls) -> dict[str,sp.Matrix]:
        return {w:S[i-1] for w,i in FIRST_MOVE.items()}

    @classmethod
    def wall_lifts(cls) -> dict[str,sp.Matrix]:
        return {w:cls.lift_matrix(A) for w,A in cls.wall_base_matrices().items()}

    @classmethod
    def relabel_base_matrices(cls) -> list[sp.Matrix]:
        return list(RELABEL)

    @classmethod
    def relabel_lifts(cls) -> list[sp.Matrix]:
        return [cls.lift_matrix(R) for R in cls.relabel_base_matrices()]

@dataclass(frozen=True)
class ProjectionPreservingLinearLift3D5D:
    """Classification of linear 5D lifts preserving the 3D base projection.

    For block T=[[P,Q],[C,D]], pi3*T=A*pi3 for all states iff P=A,Q=0.
    Hence all such lifts are [[A,0],[C,D]]. If the fibre projection is also
    fixed pointwise, C=0,D=I2 and diag(A,I2) is unique.
    """
    status: str = "PROVEN-BLOCK-CLASSIFICATION / FIBRE-TO-BASE-COUPLING-REFUTED-UNDER-STRICT-PROJECTION"

    @staticmethod
    def lift(A3: sp.Matrix, C23: sp.Matrix | None=None, D2: sp.Matrix | None=None) -> sp.Matrix:
        A3=sp.Matrix(A3); C23=sp.zeros(2,3) if C23 is None else sp.Matrix(C23); D2=sp.eye(2) if D2 is None else sp.Matrix(D2)
        if A3.shape!=(3,3) or C23.shape!=(2,3) or D2.shape!=(2,2): raise ValueError('bad block shape')
        return A3.row_join(sp.zeros(3,2)).col_join(C23.row_join(D2))

    @staticmethod
    def preserves_base_projection(T5: sp.Matrix,A3: sp.Matrix) -> bool:
        T5=sp.Matrix(T5);A3=sp.Matrix(A3)
        if T5.shape!=(5,5) or A3.shape!=(3,3): return False
        return T5[:3,:3]==A3 and T5[:3,3:]==sp.zeros(3,2)

    @staticmethod
    def fixes_fibre_pointwise(T5: sp.Matrix) -> bool:
        T5=sp.Matrix(T5)
        return T5.shape==(5,5) and T5[3:,:3]==sp.zeros(2,3) and T5[3:,3:]==sp.eye(2)

@dataclass(frozen=True)
class DeterminantSwapSellingLift3D5D:
    """Non-passive positive two-fibre lift induced by sign(det A3).

    The source base map is A3. The fibre representation is the unique
    permutation representation C2 -> S2: orientation preserving maps act by I2,
    orientation reversing maps act by the coordinate swap J. Thus C=0 and
    D(A)=J^epsilon is an exact group homomorphism. This is an algebraic Selling
    extension relative to an ordered two-coordinate fibre; identifying that
    fibre with a historical Binet/elliptic/golden fibre remains a separate map.
    """
    status: str = "PROVEN-SOURCE-EXACT-DETERMINANT-C2-FIBRE-REPRESENTATION / HISTORICAL-FIBRE-IDENTIFICATION-SEPARATED"

    @staticmethod
    def swap() -> sp.Matrix:
        return sp.Matrix([[0,1],[1,0]])

    @classmethod
    def fibre_action(cls,A3:sp.Matrix) -> sp.Matrix:
        A3=sp.Matrix(A3)
        if A3.shape!=(3,3) or A3.det()==0: raise ValueError('A3 must be invertible 3x3')
        # Current Selling source is rational/integral, so determinant sign is exact.
        return sp.eye(2) if A3.det()>0 else cls.swap()

    @classmethod
    def lift_matrix(cls,A3:sp.Matrix) -> sp.Matrix:
        A3=sp.Matrix(A3); D=cls.fibre_action(A3)
        return A3.row_join(sp.zeros(3,2)).col_join(sp.zeros(2,3).row_join(D))

    @classmethod
    def homomorphism_identity(cls,A:sp.Matrix,B:sp.Matrix) -> bool:
        A=sp.Matrix(A);B=sp.Matrix(B)
        return cls.lift_matrix(A*B)==cls.lift_matrix(A)*cls.lift_matrix(B)

    @classmethod
    def wall_lifts(cls) -> dict[str,sp.Matrix]:
        return {w:cls.lift_matrix(A) for w,A in TrivialSellingLift3D5D.wall_base_matrices().items()}

    @staticmethod
    def residual(fibre2:Sequence) -> sp.Expr:
        if len(fibre2)!=2: raise ValueError('expected two fibre coordinates')
        return sp.sympify(fibre2[0])-sp.sympify(fibre2[1])

    @classmethod
    def swap_flips_residual(cls,X,Y) -> bool:
        v=sp.Matrix([sp.sympify(X),sp.sympify(Y)]); z=cls.swap()*v
        return sp.simplify(cls.residual(z)+cls.residual(v))==0


@dataclass(frozen=True)
class GoldenResidualFibreAdapter:
    """Exact adapter between signed residual r and the historical positive golden fibre.

    mu=phi^2, nu=sqrt(5)*phi and nu-mu=1.  For magnitude m>=0,
    Gamma(+m)=m(nu,mu), Gamma(-m)=m(mu,nu).  Therefore the coordinate swap J
    intertwines residual sign reversal with the positive-fibre realization:
    J Gamma(r)=Gamma(-r), and Delta(Gamma(r))=r.
    """
    status: str = "PROVEN-EXACT-GOLDEN-RESIDUAL-FIBRE-INTERTWINER / FULL-BINET-ELLIPTIC-FIBRE-SEPARATED"

    @staticmethod
    def phi(): return (sp.Integer(1)+sp.sqrt(5))/2
    @classmethod
    def mu(cls): return sp.simplify(cls.phi()**2)
    @classmethod
    def nu(cls): return sp.simplify(sp.sqrt(5)*cls.phi())
    @classmethod
    def gamma(cls,magnitude,sign:int=1):
        m=sp.sympify(magnitude)
        if sign not in (-1,1): raise ValueError('sign must be +/-1')
        return sp.Matrix([m*cls.nu(),m*cls.mu()]) if sign>0 else sp.Matrix([m*cls.mu(),m*cls.nu()])
    @staticmethod
    def delta(v):
        v=sp.Matrix(v)
        if v.shape not in ((2,1),(2,)): raise ValueError('expected two-coordinate fibre')
        return sp.simplify(v[0]-v[1])
    @classmethod
    def identities(cls,magnitude):
        m=sp.sympify(magnitude);J=DeterminantSwapSellingLift3D5D.swap()
        gp=cls.gamma(m,+1);gm=cls.gamma(m,-1)
        return {
          'nu_minus_mu':sp.simplify(cls.nu()-cls.mu())==1,
          'delta_positive':sp.simplify(cls.delta(gp)-m)==0,
          'delta_negative':sp.simplify(cls.delta(gm)+m)==0,
          'swap_intertwiner_positive':sp.simplify(J*gp-gm)==sp.zeros(2,1),
          'swap_intertwiner_negative':sp.simplify(J*gm-gp)==sp.zeros(2,1),
        }

@dataclass(frozen=True)
class CoboundaryCoupledSellingLift3D5D:
    """Exact nonzero-C lower-triangular lift, cohomologically/gauge trivial.

    For any fixed K:Q^3->Q^2 and determinant-swap fibre representation D(A),
      C_K(A)=K A-D(A)K,
      T_K(A)=[[A,0],[C_K(A),D(A)]].
    It is conjugate to diag(A,D(A)) by H_K=[[I,0],[K,I]], hence is a source-
    exact representation with C != 0 for generic K but supplies no new native
    5D extension class and no new Selling walls/conorms by itself.
    """
    status: str = "PROVEN-NONZERO-C-SOURCE-EXACT-COBOUNDARY-LIFT / GAUGE-TRIVIAL-NOT-NATIVE-5D-WALLS"

    @staticmethod
    def default_K(): return sp.Matrix([[1,0,0],[0,1,0]])
    @classmethod
    def C(cls,A3,K=None):
        A3=sp.Matrix(A3);K=cls.default_K() if K is None else sp.Matrix(K)
        if A3.shape!=(3,3) or K.shape!=(2,3): raise ValueError('bad shape')
        D=DeterminantSwapSellingLift3D5D.fibre_action(A3)
        return sp.simplify(K*A3-D*K)
    @classmethod
    def lift_matrix(cls,A3,K=None):
        A3=sp.Matrix(A3);D=DeterminantSwapSellingLift3D5D.fibre_action(A3);C=cls.C(A3,K)
        return A3.row_join(sp.zeros(3,2)).col_join(C.row_join(D))
    @classmethod
    def conjugator(cls,K=None):
        K=cls.default_K() if K is None else sp.Matrix(K)
        return sp.eye(3).row_join(sp.zeros(3,2)).col_join(K.row_join(sp.eye(2)))
    @classmethod
    def conjugacy_identity(cls,A3,K=None):
        H=cls.conjugator(K); base=DeterminantSwapSellingLift3D5D.lift_matrix(A3)
        return sp.simplify(cls.lift_matrix(A3,K)-H*base*H.inv())==sp.zeros(5)
    @classmethod
    def homomorphism_identity(cls,A,B,K=None):
        A=sp.Matrix(A);B=sp.Matrix(B)
        return sp.simplify(cls.lift_matrix(A*B,K)-cls.lift_matrix(A,K)*cls.lift_matrix(B,K))==sp.zeros(5)
