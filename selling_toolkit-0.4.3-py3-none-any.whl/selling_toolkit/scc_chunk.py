from __future__ import annotations
import json,hashlib,time
from pathlib import Path
from collections import defaultdict
from .layers import classify_exact

def classify_scc_chunk(*, seed_path, quotient_path, nodes_key, scc_graph_key, scc, start, count, out_path, workers=8):
    seed=json.load(open(seed_path)); q=json.load(open(quotient_path))
    node_scc={i:c['scc'] for c in q[scc_graph_key]['components'] for i in c['ids']}
    groups=defaultdict(list)
    for n in q[nodes_key]: groups[node_scc[n['source']]].append(n)
    for k in groups: groups[k].sort(key=lambda n:n['id'])
    todo=groups[scc][start:start+count]; t=time.time(); rows=classify_exact(todo,seed,workers=workers); dt=time.time()-t
    byid={n['id']:n for n in todo}
    for r in rows: r['enlarged_source_scc']=scc; r['source']=byid[r['id']]['source']
    out={'version':'v0.4','status':'NONPUBLISHABLE-CHUNK','scc':scc,'slice_start':start,'slice_count':len(rows),'group_total':len(groups[scc]),'elapsed_seconds':dt,'results':rows}
    raw=json.dumps(out,sort_keys=True,separators=(',',':')).encode();out['sha256_without_self']=hashlib.sha256(raw).hexdigest();Path(out_path).parent.mkdir(parents=True,exist_ok=True);json.dump(out,open(out_path,'w'),indent=2)
    return out
