from __future__ import annotations

from itertools import permutations
from typing import Dict, Iterable, List, Tuple
import sympy as sp

WALLS = ("g", "h", "k", "l", "m", "n")

# v49/v50 certified adjacent superbase moves.
S = [
    sp.Matrix([[-1,0,1],[0,1,0],[0,0,1]]),
    sp.Matrix([[-1,1,0],[0,1,0],[0,0,1]]),
    sp.Matrix([[-1,1,1],[0,1,0],[0,0,1]]),
    sp.Matrix([[0,-1,0],[-1,0,0],[-1,-1,1]]),
    sp.Matrix([[0,0,-1],[-1,1,-1],[-1,0,0]]),
    sp.Matrix([[1,-1,-1],[0,0,-1],[0,-1,0]]),
    sp.Matrix([[1,0,0],[0,-1,1],[0,0,1]]),
    sp.Matrix([[1,0,0],[0,1,0],[0,1,-1]]),
    sp.Matrix([[1,0,0],[0,1,0],[1,0,-1]]),
    sp.Matrix([[1,0,0],[0,1,0],[1,1,-1]]),
    sp.Matrix([[1,0,0],[1,-1,0],[0,0,1]]),
    sp.Matrix([[1,0,0],[1,-1,1],[0,0,1]]),
]

# One representative of the two projectively equivalent moves for each wall.
FIRST_MOVE = {"g": 9, "h": 2, "k": 1, "l": 3, "m": 5, "n": 4}
SECOND_MOVE = {"g": 11, "h": 8, "k": 7, "l": 6, "m": 12, "n": 10}


def gram_from_six(a, b, c, g, h, k) -> sp.Matrix:
    return sp.Matrix([[a, k, h], [k, b, g], [h, g, c]])


def six_from_gram(M: sp.Matrix):
    return (
        sp.expand(M[0,0]), sp.expand(M[1,1]), sp.expand(M[2,2]),
        sp.expand(M[1,2]), sp.expand(M[0,2]), sp.expand(M[0,1]),
    )


def homogeneous(M: sp.Matrix) -> Dict[str, sp.Expr]:
    a,b,c,g,h,k = six_from_gram(M)
    return {
        "g": sp.expand(g),
        "h": sp.expand(h),
        "k": sp.expand(k),
        "l": sp.expand(-a-h-k),
        "m": sp.expand(-b-g-k),
        "n": sp.expand(-c-g-h),
    }


def conorms(M: sp.Matrix) -> Dict[str, sp.Expr]:
    a,b,c,g,h,k = six_from_gram(M)
    vals = (a+h+k, b+k+g, c+h+g, -k, -h, -g)
    names = ("p01","p02","p03","p12","p13","p23")
    return dict(zip(names, map(sp.expand, vals)))


def int_matrix(M: sp.Matrix) -> List[List[int]]:
    out=[]
    for i in range(M.rows):
        row=[]
        for j in range(M.cols):
            x=sp.Rational(M[i,j])
            if x.q != 1:
                raise ValueError(f"matrix entry is not integral: {x}")
            row.append(int(x))
        out.append(row)
    return out


def matrix_key(M: sp.Matrix) -> Tuple[str, ...]:
    return tuple(str(sp.simplify(x)) for x in list(M))


def relabelling_matrices() -> List[sp.Matrix]:
    # Superbase v0=-v1-v2-v3; permutations of the four superbase vectors.
    V=[sp.Matrix([-1,-1,-1]), sp.eye(3)[:,0], sp.eye(3)[:,1], sp.eye(3)[:,2]]
    mats=[]
    seen=set()
    for pi in permutations(range(4)):
        A=sp.Matrix.hstack(V[pi[1]],V[pi[2]],V[pi[3]])
        if abs(int(A.det())) != 1:
            continue
        k=matrix_key(A)
        if k not in seen:
            seen.add(k); mats.append(A)
    return mats


RELABEL = relabelling_matrices()


def wall_action_matrices() -> Dict[str, sp.Matrix]:
    """Seed-independent 6x6 action on Selling homogeneous wall coordinates."""
    G,H,K,L,M,N = sp.symbols("g h k l m n")
    a=-L-H-K; b=-M-G-K; c=-N-G-H
    X=gram_from_six(a,b,c,G,H,K)
    syms=[G,H,K,L,M,N]
    out={}
    for wall,idx in FIRST_MOVE.items():
        new=homogeneous(S[idx-1].T*X*S[idx-1])
        A=sp.zeros(6,6)
        for i,lab in enumerate(WALLS):
            e=sp.expand(new[lab])
            for j,s in enumerate(syms):
                A[i,j]=e.coeff(s)
        if A.det()!=1 or A*A!=sp.eye(6):
            raise AssertionError(f"bad wall action for {wall}")
        out[wall]=A
    return out


WALL_ACTION = wall_action_matrices()


def signature(M: sp.Matrix) -> Tuple[int,int,int]:
    """Return exact inertia (#positive,#negative,#zero) for a rational symmetric matrix.

    A real symmetric matrix has only real eigenvalues.  Counting roots of the
    exact characteristic polynomial on (-oo,0) and (0,oo) avoids floating
    eigenvalue instability and is sufficient for the 3x3 seed matrices used
    here (and also works for other small rational symmetric matrices).
    """
    if M.rows != M.cols or M != M.T:
        raise ValueError("matrix must be square and symmetric")
    cp=M.charpoly().as_poly()
    roots=cp.all_roots()
    pos=neg=zero=0
    for r in roots:
        if r.is_positive is True:
            pos += 1
        elif r.is_negative is True:
            neg += 1
        elif r.is_zero is True:
            zero += 1
        else:
            raise ValueError(f"could not certify eigenvalue sign exactly: {r}")
    if pos+neg+zero != M.rows:
        raise ValueError("inertia multiplicity count mismatch")
    return pos,neg,zero


def build_finite_group(generators: Iterable[sp.Matrix], max_size: int = 256) -> List[sp.Matrix]:
    """Exact closure of a finite matrix group. Fails closed if max_size is exceeded."""
    gens=[sp.Matrix(g) for g in generators]
    if not gens:
        return [sp.eye(3)]
    gens2=[]
    for g in gens:
        gens2.append(g)
        try: gens2.append(g.inv())
        except Exception: pass
    seen={matrix_key(sp.eye(3)): sp.eye(3)}
    queue=[sp.eye(3)]
    qi=0
    while qi < len(queue):
        a=queue[qi]; qi+=1
        for g in gens2:
            x=sp.simplify(a*g)
            k=matrix_key(x)
            if k in seen: continue
            if len(seen) >= max_size:
                raise RuntimeError(f"deck group exceeds max_size={max_size}; use no quotient or raise the cap")
            seen[k]=x; queue.append(x)
    return list(seen.values())


def primitive_poly(expr: sp.Expr, q: sp.Symbol, r: sp.Symbol) -> sp.Expr:
    P=sp.Poly(sp.expand(expr), q, r, domain=sp.QQ)
    _content, prim = sp.polys.polytools.primitive(P.as_expr(), q, r)
    F=sp.Poly(prim,q,r,domain=sp.QQ)
    if F.LC() < 0:
        F=-F
    return sp.factor(F.as_expr())
