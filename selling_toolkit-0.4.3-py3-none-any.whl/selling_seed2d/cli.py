from __future__ import annotations

import argparse, json
from pathlib import Path

from .seed import load_seed
from .seedgen import generate_to_file
from .discover import compile_seed
from .render import render_compiled
from .atlas import atlas_from_compiled, atlas_from_v50_reference
from .regularizer import regularize_atlas
from .layout import build_layout
from .render_layout import render_layout
from .schemaio import validate_json_object


def main(argv=None):
    ap=argparse.ArgumentParser(prog="selling-seed2d",description="Seed-parametric 2D Selling constructor / regularizer / layout pipeline")
    sp=ap.add_subparsers(dest="cmd",required=True)

    g=sp.add_parser("seedgen",help="generate a compatible synthetic seed")
    g.add_argument("-o","--output",required=True);g.add_argument("--rng-seed",type=int,default=0)
    g.add_argument("--a",type=int);g.add_argument("--b",type=int);g.add_argument("--c",type=int);g.add_argument("--h",type=int)
    g.add_argument("--preset",choices=["v4","none","generic"],default="generic")
    g.add_argument("--conjugate-steps",type=int,default=8);g.add_argument("--name")
    g.add_argument("--classifier",choices=["exact","sampled"],default="exact")

    v=sp.add_parser("validate",help="validate and normalize a seed")
    v.add_argument("seed")

    c=sp.add_parser("compile",help="discover fields from a seed")
    c.add_argument("seed");c.add_argument("-o","--output",required=True);c.add_argument("--progress",action="store_true")

    r=sp.add_parser("render",help="legacy algebraic-wall render of a compiled field atlas")
    r.add_argument("seed");r.add_argument("compiled");r.add_argument("-o","--output",required=True);r.add_argument("--dpi",type=int,default=180)

    a=sp.add_parser("atlas",help="lift compiled fields to the canonical atlas schema; cellular incidence stays NT unless an exact adapter is supplied")
    a.add_argument("seed");a.add_argument("compiled");a.add_argument("-o","--output",required=True)
    a.add_argument("--adapter",choices=["none","v50-reference"],default="none")
    a.add_argument("--source-dir",help="directory containing exact adapter source artifacts")

    rg=sp.add_parser("regularize",help="replay a certified regularization plan and rebuild C0/C1/C2,d1,d2")
    rg.add_argument("atlas");rg.add_argument("-o","--output",required=True)

    lo=sp.add_parser("layout",help="build a raster-independent layout from a regular complex")
    lo.add_argument("regular_complex");lo.add_argument("-o","--output",required=True)
    lo.add_argument("--mode",choices=["chart_native","topological_independent"],default="chart_native")
    lo.add_argument("--style",choices=["selling","plain"],default="selling")

    rr=sp.add_parser("render-layout",help="render normalized layout JSON to PNG/SVG/PDF")
    rr.add_argument("layout");rr.add_argument("-o","--output",required=True);rr.add_argument("--dpi",type=int,default=220)

    p=sp.add_parser("pipeline",help="legacy compile + algebraic-wall render")
    p.add_argument("seed");p.add_argument("--compiled",required=True);p.add_argument("--image",required=True);p.add_argument("--progress",action="store_true")

    fp=sp.add_parser("full-pipeline",help="compile -> atlas -> regularize -> layout -> render; fails closed if cellular incidence/plan is NT")
    fp.add_argument("seed")
    fp.add_argument("--prefix",required=True)
    fp.add_argument("--adapter",choices=["none","v50-reference"],default="none")
    fp.add_argument("--source-dir")
    fp.add_argument("--layout-mode",choices=["chart_native","topological_independent"],default="chart_native")
    fp.add_argument("--style",choices=["selling","plain"],default="selling")
    fp.add_argument("--format",choices=["png","svg","pdf"],default="svg")
    fp.add_argument("--progress",action="store_true")

    ns=ap.parse_args(argv)
    if ns.cmd=="seedgen":
        s=generate_to_file(ns.output,rng_seed=ns.rng_seed,a=ns.a,b=ns.b,c=ns.c,h=ns.h,preset=ns.preset,
                           conjugate_steps=ns.conjugate_steps,name=ns.name,classifier=ns.classifier)
        print(json.dumps({"status":"PASS","output":ns.output,"name":s["name"]},indent=2))
    elif ns.cmd=="validate":
        s=load_seed(ns.seed);validate_json_object(s,"selling.seed.v1");print(json.dumps({"status":"PASS","name":s["name"],"derived":s["derived"]},indent=2,ensure_ascii=False))
    elif ns.cmd=="compile":
        out=compile_seed(ns.seed,ns.output,progress=ns.progress)
        print(json.dumps({k:out[k] for k in ["status","field_count","closed","exact_topology","deck_group_size"]},indent=2))
    elif ns.cmd=="render":
        out=render_compiled(ns.seed,ns.compiled,ns.output,dpi=ns.dpi);print(out)
    elif ns.cmd=="atlas":
        if ns.adapter=="v50-reference":
            if not ns.source_dir: ap.error("atlas --adapter v50-reference requires --source-dir")
            out=atlas_from_v50_reference(ns.seed,ns.compiled,ns.source_dir,ns.output)
        else:
            out=atlas_from_compiled(ns.seed,ns.compiled,ns.output)
        print(json.dumps({"status":out["status"],"htnt":out["htnt"],"output":ns.output},indent=2,ensure_ascii=False))
    elif ns.cmd=="regularize":
        out=regularize_atlas(ns.atlas,ns.output)
        print(json.dumps({"status":out["status"],"counts":[out["C0"],out["C1"],out["C2"]],"chi":out["euler_characteristic"],"certificates":out["certificates"],"output":ns.output},indent=2))
    elif ns.cmd=="layout":
        out=build_layout(ns.regular_complex,ns.output,mode=ns.mode,style=ns.style)
        print(json.dumps({"status":out["status"],"mode":out["mode"],"geometry_level":out.get("geometry_level"),"output":ns.output},indent=2))
    elif ns.cmd=="render-layout":
        print(render_layout(ns.layout,ns.output,dpi=ns.dpi))
    elif ns.cmd=="pipeline":
        out=compile_seed(ns.seed,ns.compiled,progress=ns.progress)
        render_compiled(ns.seed,out,ns.image)
        print(json.dumps({"status":out["status"],"compiled":ns.compiled,"image":ns.image},indent=2))
    elif ns.cmd=="full-pipeline":
        pre=Path(ns.prefix); pre.parent.mkdir(parents=True,exist_ok=True)
        compiled=str(pre)+".compiled.json"; atlas=str(pre)+".atlas.json"; regular=str(pre)+".regular_complex.json"; layout=str(pre)+".layout.json"; image=str(pre)+"."+ns.format
        co=compile_seed(ns.seed,compiled,progress=ns.progress)
        if ns.adapter=="v50-reference":
            if not ns.source_dir: ap.error("full-pipeline --adapter v50-reference requires --source-dir")
            at=atlas_from_v50_reference(ns.seed,co,ns.source_dir,atlas)
        else:
            at=atlas_from_compiled(ns.seed,co,atlas)
        re=regularize_atlas(at,regular)
        la=build_layout(re,layout,mode=ns.layout_mode,style=ns.style)
        render_layout(la,image)
        print(json.dumps({"status":"PASS-FULL-EXACT","compiled":compiled,"atlas":atlas,"regular_complex":regular,"layout":layout,"image":image},indent=2))

if __name__=="__main__":main()
