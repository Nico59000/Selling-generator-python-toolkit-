from __future__ import annotations
import hashlib, json
from pathlib import Path
import sympy as sp


def load(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def digest_wo_self(d):
    x=dict(d); x.pop('sha256_without_self_hash',None)
    return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()

def sparse_matrix(entries, rows, cols):
    M=sp.zeros(rows,cols)
    for e in entries: M[int(e['row']),int(e['col'])]=int(e['value'])
    return M

def verify(root: str|Path):
    root=Path(root); out=root/'outputs'
    lf=load(out/'fig1_v50.local_faces.autosolved.json')
    qi=load(out/'fig1_v50.quotient_incidence.auto.json')
    iso=load(out/'fig1_v50.isotropy.auto.json')
    plan=load(out/'fig1_v50.regularization_plan.auto.json')
    reg=load(out/'fig1_v50.regular_complex.v03.auto.json')
    arc=load(out/'fig1_v50.arc_geometry.v03.auto.json')
    chain=load(root/'V50_CHAIN_ISOMORPHISM_REPORT.json')
    checks={}
    def ck(name, cond): checks[name]=bool(cond)

    # self hashes on artifacts that use canonical compact encoding
    for nm,d in [('local_faces',lf),('quotient',qi),('isotropy',iso),('plan',plan),('arc',arc)]:
        ck(f'{nm}_self_hash', digest_wo_self(d)==d.get('sha256_without_self_hash'))

    ck('local_faces_status', lf.get('status')=='PASS-EXACT-LOCAL-FACE-CYCLES')
    ck('local_faces_counts', lf.get('field_count')==62 and lf.get('cycle_occurrence_count')==63 and len(lf.get('faces',[]))==62)
    ck('field55_two_cycles', sum(1 for f in lf['faces'] if int(f['field'])==55 and len(f.get('cycles',[]))==2)==1)
    certs=[]; segs=[]
    for f in lf['faces']:
        certs.extend(v.get('certificate',{}) for v in f.get('vertices',[]))
        segs.extend(f.get('segments',[]))
    ck('all_vertex_certificates_exact', bool(certs) and all(str(c.get('status','')).startswith('PASS-EXACT') for c in certs))
    ck('all_segment_witnesses_exact', bool(segs) and all(str(s.get('status','')).startswith('PASS-EXACT') and str(s.get('witness',{}).get('status','')).startswith('PASS-EXACT') for s in segs))

    ck('quotient_status', qi.get('status')=='PASS-EXACT-QUOTIENT-TRANSPORT')
    ck('quotient_counts', len(qi.get('vertex_orbits',[]))==60 and len(qi.get('edge_orbits',[]))==118 and len(qi.get('face_orbits',[]))==62)
    ck('pre_regular_counts', qi.get('pre_regular',{}).get('counts')==[60,118,62])
    ck('pre_regular_two_loops', qi.get('pre_regular',{}).get('edge_loops')==2)

    ck('isotropy_status', iso.get('status')=='PASS-EXACT-DECK-ISOTROPY')
    ck('five_face_reflections', sorted(int(x['face']) for x in iso.get('face_reflections',[]))==[38,48,49,53,56])
    ck('two_fixed_edge_points', sorted(map(int,iso.get('fixed_edge_points',{}).keys()))==[80,108])

    ck('plan_status', plan.get('status')=='PASS-EXACT-AUTOMATIC-REGULARIZATION-PLAN')
    ck('plan_counts', plan.get('expected_counts')==[62,123,62])
    ck('plan_ops', len(plan.get('operations',[]))==9)
    ck('plan_add_vertices_2', sum(op.get('op')=='add_vertex' for op in plan['operations'])==2)
    ck('plan_add_edges_5', sum(op.get('op')=='add_edge' for op in plan['operations'])==5)
    ck('plan_replace_edges_2', sum(op.get('op')=='replace_edge_endpoints' for op in plan['operations'])==2)

    ck('regular_status', reg.get('status')=='PASS-EXACT-REGULARIZED')
    ck('regular_counts', [reg.get('C0'),reg.get('C1'),reg.get('C2')]==[62,123,62])
    ck('regular_euler', reg.get('euler_characteristic')==1)
    D1=sparse_matrix(reg['partial1_sparse'],62,123); D2=sparse_matrix(reg['partial2_sparse'],123,62)
    ck('chain_zero_recomputed', D1*D2==sp.zeros(62,62))
    ck('regular_ranks', int(D1.rank())==int(reg['certificates']['partial1_rank_Q']) and int(D2.rank())==int(reg['certificates']['partial2_rank_Q']))

    ck('arc_status', arc.get('status')=='PASS-EXACT-ALGEBRAIC-ARC-GEOMETRY')
    ck('arc_count_123', len(arc.get('edges',[]))==123 and not arc.get('failures'))
    reg_ep={int(e['id']):list(map(int,e['endpoints'])) for e in reg['edges']}
    ck('arc_endpoints_match_regular', all(list(map(int,e['endpoints']))==reg_ep[int(e['id'])] for e in arc['edges']))
    ck('arc_exact_levels', all(str(e.get('exact_level','')).startswith('PASS-EXACT') for e in arc['edges']))

    ck('chain_iso_status', chain.get('status')=='PASS-SIGNED-CELLULAR-CHAIN-ISOMORPHISM')
    ck('chain_iso_counts', chain.get('candidate_counts')==[62,123,62] and chain.get('reference_counts')==[62,123,62])
    ck('chain_iso_equations', chain.get('typed_incidence_graph_isomorphic') is True and chain.get('d1_chain_equation')=='PASS' and chain.get('d2_chain_equation')=='PASS' and not chain.get('d1_failures') and not chain.get('d2_failures'))

    failed=[k for k,v in checks.items() if not v]
    return {'version':'v0.3','status':'PASS' if not failed else 'FAIL','checks':checks,'passed':sum(checks.values()),'total':len(checks),'failed':failed}

if __name__=='__main__':
    import sys
    rep=verify(sys.argv[1] if len(sys.argv)>1 else Path(__file__).resolve().parents[1])
    print(json.dumps(rep,indent=2,ensure_ascii=False))
    raise SystemExit(0 if rep['status']=='PASS' else 1)
