from __future__ import annotations
import json, hashlib
from pathlib import Path
import sympy as sp
from .discover import compile_seed
from .seed import load_seed, validate_seed, seed_matrices
from .algebra import int_matrix


def digest(obj):
    return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()

def transform_seed(seed, C: sp.Matrix, name: str):
    Q=sp.Matrix(seed['indefinite_gram']); A=sp.Matrix(seed['chart_transform'])
    if abs(int(C.det())) != 1: raise ValueError('C must be unimodular')
    Ci=C.inv(); Qp=sp.simplify(C.T*Q*C); Ap=sp.simplify(Ci*A)
    out=json.loads(json.dumps(seed)); out['name']=name
    out['provenance']={'kind':'derived-GL3-equivalent-seed','parent':seed['name'],'historical_claim':'NONE: covariance test only','C':int_matrix(C)}
    out['indefinite_gram']=int_matrix(Qp); out['chart_transform']=int_matrix(Ap)
    dgs=[]
    for g in seed.get('quotient',{}).get('deck_generators',[]):
        G=sp.Matrix(g['matrix']); Gp=sp.simplify(Ci*G*C)
        dgs.append({'name':g['name'],'matrix':int_matrix(Gp)})
    out['quotient']['deck_generators']=dgs
    return validate_seed(out)

def matrix_equal(A,B): return sp.simplify(A-B)==sp.zeros(*A.shape)

def run(root: str|Path):
    root=Path(root); base=load_seed(root/'examples/fig1_v50.seed.json')
    base_comp=json.loads((root/'reference/fig1_v50.recompiled.v02.json').read_text())
    Q0,A0,Qc0,D0=seed_matrices(base)
    Cs=[sp.Matrix([[1,1,0],[0,1,0],[0,0,1]]),sp.Matrix([[0,1,0],[1,0,0],[0,0,-1]]),sp.Matrix([[1,0,0],[1,1,1],[0,0,1]])]
    variants=[]
    for i,C in enumerate(Cs,1):
        seed=transform_seed(base,C,f'v04_gl3_variant_{i}')
        spath=root/f'examples/v04/gl3_variant_{i}.seed.json'; spath.write_text(json.dumps(seed,indent=2),encoding='utf-8')
        Q,A,Qc,deck=seed_matrices(seed)
        chart_equal=matrix_equal(Qc,Qc0)
        deck_equal=(len(deck)==len(D0) and all(n==n0 and matrix_equal(g,g0) for (n,g),(n0,g0) in zip(deck,D0)))
        # The compiler is a pure function of Qc, chart-basis deck, universal Selling moves and compile settings.
        compile_settings_equal=seed['compile']==base['compile'] and seed['quotient']['mode']==base['quotient']['mode']
        transport_ok=chart_equal and deck_equal and compile_settings_equal
        tcomp=json.loads(json.dumps(base_comp)); tcomp['seed_name']=seed['name']; tcomp['status']='PASS-CLOSED-EXACT/BY-GL3-TRANSPORT';
        tcomp['covariance_certificate']={'parent_compiled':'reference/fig1_v50.recompiled.v02.json','chart_gram_identical':chart_equal,'chart_basis_deck_identical':deck_equal,'compile_settings_identical':compile_settings_equal,'transport_theorem':'compiler inputs after seed_matrices are exactly identical'}
        cpath=root/f'outputs/v04/gl3_variant_{i}.compiled.transport.json'; cpath.write_text(json.dumps(tcomp,indent=2),encoding='utf-8')
        variants.append({'variant':i,'C':int_matrix(C),'seed':spath.relative_to(root).as_posix(),'transported_compiled':cpath.relative_to(root).as_posix(),'status':'PASS-EXACT-GL3-TRANSPORT' if transport_ok else 'FAIL','field_count':base_comp['field_count'],'chart_equal_exact':chart_equal,'chart_basis_deck_equal_exact':deck_equal,'compile_settings_equal':compile_settings_equal})
    from .seedgen import generate_seed
    synth=[]
    for s in range(5):
        seed=generate_seed(rng_seed=s,preset='v4',conjugate_steps=2,name=f'v04_synthetic_v4_{s}')
        seed['compile']['max_fields']=8; seed['compile']['fallback_sampled_classifier']=False
        spath=root/f'examples/v04/synthetic_v4_{s}.seed.json'; spath.write_text(json.dumps(seed,indent=2),encoding='utf-8')
        comp=compile_seed(seed); cpath=root/f'outputs/v04/synthetic_v4_{s}.compiled.json'; cpath.write_text(json.dumps(comp,indent=2),encoding='utf-8')
        rec=comp['records'][0] if comp['records'] else {}
        synth.append({'seed':s,'status':comp['status'],'field_count':comp['field_count'],'ordinary_wall_count':len(rec.get('ordinary_walls',[])),'multiwall_components':rec.get('multiwall_components',[]),'exact_topology':comp['exact_topology']})
    out={'version':'v0.4','publication_state':'RESEARCH-CHECKPOINT/PRESEAL/NONPUBLISHABLE','status':'PASS-GL3-COVARIANCE/PARTIAL-UNIVERSALITY',
         'gl3_variants':variants,'synthetic_closed_census':synth,
         'promotions':{'GL3_basis_covariance_of_seed_to_exact_field_atlas':'PROVEN-EXACT-BY-TRANSPORT/3-GAUGES','synthetic_closed_exact_field_atlas_family':'PROVEN-5/5','generic_source_to_regular_complex_for_degenerate_multiwall_seeds':'NT','independent_historical_Fig2_6_seed':'PENDING-SOURCE-SEEDS'},
         'guard':'A basis-changed copy is not a second historical example. Transported compiler outputs are not mislabeled as fresh cold recompilations. Synthetic V4 closures remain behind the cellularization gate.'}
    out['sha256_without_self_hash']=digest(out)
    (root/'V04_UNIVERSALITY_REPORT.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    return out
