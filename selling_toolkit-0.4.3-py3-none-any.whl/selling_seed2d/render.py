from __future__ import annotations

from pathlib import Path
from typing import Dict, Any
import json
import math
import numpy as np
import sympy as sp

from .seed import load_seed
from .chart import build_chart


def _matrix_str(x):
    return sp.Matrix([[sp.Rational(v) for v in row] for row in x])


def render_compiled(seed_or_path, compiled_or_path, output_path, *, dpi=180, title=None):
    import matplotlib.pyplot as plt

    seed=load_seed(seed_or_path) if not isinstance(seed_or_path,dict) else seed_or_path
    comp=json.loads(Path(compiled_or_path).read_text(encoding="utf-8")) if not isinstance(compiled_or_path,dict) else compiled_or_path
    chart=build_chart(seed)
    cfg=seed["render"]
    qmin,qmax=map(float,cfg["q_range"]); rmin,rmax=map(float,cfg["r_range"])
    n=int(cfg.get("resolution",650))
    qv=np.linspace(qmin,qmax,n); rv=np.linspace(rmin,rmax,n)
    Q,R=np.meshgrid(qv,rv)

    fD=sp.lambdify((chart.q,chart.r),chart.D0,"numpy")
    D=np.asarray(fD(Q,R),dtype=float)
    base=[]
    for e in chart.wall_vector:
        arr=np.asarray(sp.lambdify((chart.q,chart.r),e,"numpy")(Q,R),dtype=float)
        if arr.shape==(): arr=np.full_like(Q,float(arr))
        base.append(arr)
    W0=np.stack(base,axis=0)

    fig,ax=plt.subplots(figsize=(10,8))
    ax.set_aspect("equal",adjustable="box")
    ax.set_xlim(qmin,qmax);ax.set_ylim(rmin,rmax)
    ax.set_xlabel("q = z/x");ax.set_ylabel("r = -y/x")
    ax.set_title(title or f"Selling 2D — {seed['name']} — {comp['field_count']} champs")

    if cfg.get("show_domain_boundary",True):
        try:
            ax.contour(Q,R,D,levels=[0],colors="0.55",linewidths=0.8,linestyles="--")
        except Exception:
            pass

    field_masks=[]
    tol=1e-8
    for rec in comp["records"]:
        L=np.array([[float(sp.Rational(v)) for v in row] for row in rec["wall_action_matrix"]],dtype=float)
        W=np.einsum("ij,jxy->ixy",L,W0,optimize=True)
        mask=(D>0)&np.all(W<=tol,axis=0)
        field_masks.append((rec,W,mask))

    if cfg.get("fill_fields",False):
        labels=np.full(Q.shape,np.nan)
        for rec,W,mask in field_masks:
            labels[np.isnan(labels)&mask]=rec["id"]
        ax.imshow(labels,origin="lower",extent=(qmin,qmax,rmin,rmax),interpolation="nearest",alpha=0.18,aspect="auto")

    lw=float(cfg.get("line_width",0.7))
    wall_index={k:i for i,k in enumerate(["g","h","k","l","m","n"])}
    drawn=set()
    for rec,W,mask in field_masks:
        rid=rec["id"]
        for wall,nei in rec.get("neighbors",{}).items():
            target=nei.get("target")
            # Avoid drawing ordinary two-sided edges twice; retain open/truncated edges.
            edge_key=tuple(sorted((rid,target)))+(wall,) if target is not None else (rid,None,wall)
            if target is not None and target < rid:
                continue
            i=wall_index[wall]
            # Mask only by the other five inequalities. This leaves a clean zero contour.
            other=np.ones_like(mask,dtype=bool)
            for j in range(6):
                if j!=i: other &= (W[j] <= 2e-6)
            good=(D>0)&other
            Z=np.ma.array(W[i],mask=~good)
            try:
                ax.contour(Q,R,Z,levels=[0],colors="black",linewidths=lw)
            except Exception:
                pass

        # Multiwall / mirror components: plot the shared factor itself if parseable.
        for m in rec.get("multiwall_components",[]):
            try:
                f=sp.sympify(m["factor"],locals={"q":chart.q,"r":chart.r})
                Z=np.asarray(sp.lambdify((chart.q,chart.r),f,"numpy")(Q,R),dtype=float)
                if Z.shape==(): Z=np.full_like(Q,float(Z))
                # limit to the field neighborhood
                Zm=np.ma.array(Z,mask=~((D>0)&np.all(W<=2e-4,axis=0)))
                ax.contour(Q,R,Zm,levels=[0],colors="black",linewidths=max(1.25,1.7*lw))
            except Exception:
                pass

    if cfg.get("labels",True):
        # Label at median grid point of each nonempty region to avoid extreme tails.
        for rec,W,mask in field_masks:
            ys,xs=np.nonzero(mask)
            if len(xs)<8: continue
            k=len(xs)//2
            # use centroid then nearest point in mask
            cq=float(qv[xs].mean()); cr=float(rv[ys].mean())
            dist=(qv[xs]-cq)**2+(rv[ys]-cr)**2
            kk=int(np.argmin(dist))
            ax.text(float(qv[xs[kk]]),float(rv[ys[kk]]),str(rec["id"]),fontsize=5.5,ha="center",va="center")

    if comp.get("exact_topology"):
        topo_note="exacte fermée"
    elif comp.get("all_visited_exact"):
        topo_note="classification locale exacte / atlas tronqué"
    else:
        topo_note="non certifiée / visualisation"
    note=(f"topologie: {topo_note}; "
          f"quotient={comp.get('quotient_mode')}; deck={comp.get('deck_group_size')}")
    ax.text(0.01,0.01,note,transform=ax.transAxes,fontsize=7,ha="left",va="bottom")
    fig.tight_layout()
    output_path=Path(output_path)
    output_path.parent.mkdir(parents=True,exist_ok=True)
    fig.savefig(output_path,dpi=dpi,bbox_inches="tight")
    plt.close(fig)
    return str(output_path)
