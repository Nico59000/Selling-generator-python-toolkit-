"""selling-seed2d v0.2: seed -> exact field atlas -> guarded cellular atlas -> regular complex -> raster-independent layout."""
__version__ = "0.2.0"
