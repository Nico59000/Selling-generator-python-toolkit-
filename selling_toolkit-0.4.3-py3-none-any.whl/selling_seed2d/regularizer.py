from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Dict, List

import sympy as sp

from .schemaio import validate_json_object, write_json


def _load(x):
    if isinstance(x, dict):
        return x
    return json.loads(Path(x).read_text(encoding="utf-8"))


def _digest(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")).hexdigest()


def _sparse(M: sp.Matrix) -> List[Dict[str, int]]:
    return [{"row": i, "col": j, "value": int(M[i, j])}
            for i in range(M.rows) for j in range(M.cols) if M[i, j] != 0]


def _approx_from_vertex(v: Dict[str, Any]):
    if "approx" in v and len(v["approx"]) == 2:
        return [float(v["approx"][0]), float(v["approx"][1])]
    if "coordinates" in v and len(v["coordinates"]) == 2:
        try:
            return [float(sp.N(sp.sympify(v["coordinates"][0]), 30)), float(sp.N(sp.sympify(v["coordinates"][1]), 30))]
        except Exception:
            return None
    return None


def regularize_atlas(atlas_or_path, output_path=None) -> Dict[str, Any]:
    """Replay a certified regularization plan and rebuild the chain complex.

    The algorithm is seed/figure agnostic.  It accepts only exact cellular
    atlases carrying a promoted regularization plan.  Deriving that plan from
    an arbitrary raw field atlas is intentionally outside this function and is
    still an HT+NT gate in v0.2.
    """
    atlas = _load(atlas_or_path)
    validate_json_object(atlas, "selling.atlas.v1")
    cell = atlas.get("cellular", {})
    plan = cell.get("regularization_plan", {})
    if not str(cell.get("status", "")).startswith("PASS-EXACT"):
        raise ValueError("regularizer requires PASS-EXACT cellular incidence; current atlas remains NT")
    if not str(plan.get("status", "")).startswith("PASS-EXACT"):
        raise ValueError("regularizer requires a PASS-EXACT certified regularization plan")

    pre = cell["pre_regular"]
    vertices = [dict(v) for v in pre["vertex_orbits"]]
    edges = [dict(e) for e in pre["edges"]]
    op_log = []

    def check_dense_ids(items, kind):
        ids = [int(x["id"]) for x in items]
        if ids != list(range(len(items))):
            raise ValueError(f"{kind} ids must be dense 0..n-1, got prefix {ids[:12]}")
    check_dense_ids(vertices, "vertex")
    check_dense_ids(edges, "edge")

    for op in plan.get("operations", []):
        kind = op.get("op")
        if kind == "add_vertex":
            v = dict(op["vertex"])
            if int(v["id"]) != len(vertices):
                raise ValueError(f"add_vertex id {v['id']} is not next dense id {len(vertices)}")
            ap = _approx_from_vertex(v)
            if ap is not None:
                v.setdefault("approx", ap)
            vertices.append(v)
            op_log.append({"op": kind, "id": v["id"]})
        elif kind == "replace_edge_endpoints":
            eid = int(op["edge"])
            if not 0 <= eid < len(edges):
                raise ValueError(f"replace_edge_endpoints bad edge {eid}")
            ep = [int(x) for x in op["endpoints"]]
            if len(ep) != 2:
                raise ValueError("edge endpoints must have length 2")
            edges[eid]["endpoints"] = ep
            edges[eid]["regularization"] = "ENDPOINTS-REPLACED-BY-CERTIFIED-PLAN"
            if "certificate" in op:
                edges[eid]["regularization_certificate"] = op["certificate"]
            op_log.append({"op": kind, "edge": eid, "endpoints": ep})
        elif kind == "add_edge":
            e = dict(op["edge"])
            if int(e["id"]) != len(edges):
                raise ValueError(f"add_edge id {e['id']} is not next dense id {len(edges)}")
            if len(e.get("endpoints", [])) != 2:
                raise ValueError("added edge needs two endpoints")
            edges.append(e)
            op_log.append({"op": kind, "id": e["id"]})
        else:
            raise ValueError(f"unknown regularization operation {kind!r}")

    check_dense_ids(vertices, "vertex")
    check_dense_ids(edges, "edge")
    C0, C1 = len(vertices), len(edges)
    face_cycles = {str(k): v for k, v in plan.get("final_face_cycles", {}).items()}
    face_ids = sorted(int(k) for k in face_cycles)
    if face_ids != list(range(len(face_ids))):
        raise ValueError("face ids must be dense 0..n-1")
    C2 = len(face_ids)

    # Validate every oriented cycle against edge endpoints, then build d1,d2.
    D1 = sp.zeros(C0, C1)
    endpoints_valid = True
    for e in edges:
        eid = int(e["id"]); a, b = map(int, e["endpoints"])
        if not (0 <= a < C0 and 0 <= b < C0):
            endpoints_valid = False
            continue
        D1[a, eid] -= 1; D1[b, eid] += 1
    if not endpoints_valid:
        raise ValueError("one or more regularized edges have invalid endpoints")

    D2 = sp.zeros(C1, C2)
    cycle_closed = True
    orientation_exact = True
    for fid in range(C2):
        steps = face_cycles[str(fid)]
        if not steps:
            raise ValueError(f"face {fid} has empty cycle")
        for k, st in enumerate(steps):
            eid = int(st["edge"]); sg = int(st["sign"])
            a = int(st["v_start"]); b = int(st["v_end"])
            if sg not in {-1, 1} or not (0 <= eid < C1):
                raise ValueError(("bad-face-step", fid, k, st))
            ea, eb = map(int, edges[eid]["endpoints"])
            if sg == 1:
                if (a, b) != (ea, eb):
                    orientation_exact = False
            else:
                if (a, b) != (eb, ea):
                    orientation_exact = False
            nxt = steps[(k + 1) % len(steps)]
            if b != int(nxt["v_start"]):
                cycle_closed = False
            D2[eid, fid] += sg
    if not cycle_closed:
        raise ValueError("one or more final face cycles do not close")
    if not orientation_exact:
        raise ValueError("one or more face steps disagree with oriented edge endpoints")

    prod = D1 * D2
    nz = [{"row": i, "col": j, "value": int(prod[i, j])}
          for i in range(prod.rows) for j in range(prod.cols) if prod[i, j] != 0]
    if nz:
        raise ValueError(f"partial1*partial2 is nonzero; first entries: {nz[:8]}")

    expected = plan.get("expected_counts")
    if expected is not None and list(map(int, expected)) != [C0, C1, C2]:
        raise ValueError(f"regularized counts {[C0,C1,C2]} != certified expected counts {expected}")

    p1 = _sparse(D1); p2 = _sparse(D2)
    structural = {
        "counts": [C0, C1, C2],
        "edge_endpoints": [[int(e["id"]), list(map(int, e["endpoints"]))] for e in edges],
        "face_cycles": face_cycles,
        "partial1_sparse": p1,
        "partial2_sparse": p2,
    }
    structural_digest = _digest(structural)
    ref_digest = plan.get("reference_structural_digest")
    ref_match = None if ref_digest is None else (structural_digest == ref_digest)
    if ref_match is False:
        raise ValueError("regularizer structural digest differs from the certified reference")

    out = {
        "schema": "selling.regular_complex.v1",
        "toolchain": "selling_seed2d_toolchain_v0_2",
        "seed_name": atlas["seed_name"],
        "status": "PASS-EXACT-REGULARIZED",
        "C0": C0, "C1": C1, "C2": C2,
        "euler_characteristic": C0 - C1 + C2,
        "vertices": vertices,
        "edges": edges,
        "face_cycles": face_cycles,
        "partial1_sparse": p1,
        "partial2_sparse": p2,
        "certificates": {
            "partial1_partial2_zero": True,
            "face_cycle_closed": True,
            "edge_endpoints_valid": True,
            "orientation_exact": True,
            "partial1_rank_Q": int(D1.rank()),
            "partial2_rank_Q": int(D2.rank()),
            "regularization_operations_replayed": len(op_log),
            "structural_digest": structural_digest,
            "reference_structural_digest": ref_digest,
            "reference_structural_digest_match": ref_match,
        },
        "operation_log": op_log,
        "guards": [
            "The regularizer only replays a certified plan; automatic singularity-plan derivation is a separate gate.",
            "All boundary matrices are rebuilt from oriented endpoints/cycles and partial1*partial2 is recomputed exactly over Z.",
            "No layout or raster coordinate contributes to cellular incidence.",
        ],
    }
    out["sha256_without_self_hash"] = _digest(out)
    if output_path:
        write_json(out, output_path)
    return out
