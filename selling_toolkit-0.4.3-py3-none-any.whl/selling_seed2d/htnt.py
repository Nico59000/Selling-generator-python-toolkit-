from __future__ import annotations

from dataclasses import dataclass

# Small status vocabulary used by the v0.2 pipeline.  It deliberately keeps
# mathematical promotion separate from implementation progress.
PROVEN = "PROVEN"
PROVEN_EXACT = "PROVEN-EXACT"
PASS = "PASS"
NT = "NT"
SEPARATED = "SEPARATED"
PENDING = "PENDING-MORPHISM"
REFUTED = "REFUTED-TYPED"
VIS_ONLY = "VISUALIZATION-ONLY"


def require(condition: bool, message: str) -> None:
    """Fail closed: a missing mathematical precondition is an exception."""
    if not condition:
        raise ValueError(message)


def is_promoted(status: str) -> bool:
    return status.startswith("PROVEN") or status.startswith("PASS")
