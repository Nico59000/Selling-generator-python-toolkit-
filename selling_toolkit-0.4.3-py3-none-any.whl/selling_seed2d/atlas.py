from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Dict, Tuple

from .schemaio import write_json


def _load(x):
    if isinstance(x, dict):
        return x
    return json.loads(Path(x).read_text(encoding="utf-8"))


def _digest(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")).hexdigest()


def atlas_from_compiled(seed_or_path, compiled_or_path, output_path=None) -> Dict[str, Any]:
    """Lift a compiled field BFS to the v0.2 atlas contract.

    This function intentionally does *not* invent local face cycles.  A closed
    exact field BFS proves field adjacency, but it is not by itself an exact
    primal cell decomposition.  The cellular layer therefore remains NT until
    a source-certified or independently exact cellular adapter is supplied.
    """
    seed = _load(seed_or_path)
    comp = _load(compiled_or_path)
    if comp.get("schema") != "selling.compiled.v1":
        raise ValueError("compiled input must have schema selling.compiled.v1")
    exact = bool(comp.get("exact_topology"))
    fields = []
    for r in comp["records"]:
        fields.append({
            "id": r["id"],
            "path_matrix": r["path_matrix"],
            "wall_action_matrix": r["wall_action_matrix"],
            "ordinary_walls": r.get("ordinary_walls", []),
            "multiwall_components": r.get("multiwall_components", []),
            "neighbors": r.get("neighbors", {}),
            "classifier": r.get("classifier"),
        })
    out = {
        "schema": "selling.atlas.v1",
        "toolchain": "selling_seed2d_toolchain_v0_2",
        "seed_name": seed["name"],
        "source_compiled_schema": comp["schema"],
        "status": "PASS-EXACT-FIELD-ATLAS/CELLULAR-NT" if exact else "FIELD-ATLAS-NOT-PROMOTABLE",
        "htnt": {
            "field_atlas": "PROVEN-EXACT" if exact else "NT/VISUALIZATION-ONLY",
            "cellular_incidence": "NT",
            "regularization_plan": "NT",
        },
        "fields": fields,
        "cellular": {
            "status": "NT/NO-EXACT-LOCAL-FACE-CYCLES",
            "regularization_plan": {"status": "NT", "operations": [], "final_face_cycles": {}},
        },
        "guards": [
            "Closed exact field adjacency is not silently promoted to a primal cellular incidence structure.",
            "The generic regularizer may run only after exact local face cycles, quotient identifications and any singular refinement plan are certified.",
            "Raster or layout output never supplies missing combinatorics.",
        ],
    }
    out["sha256_without_self_hash"] = _digest(out)
    if output_path:
        write_json(out, output_path)
    return out


def _face_segment_info(face: Dict[str, Any], si: int) -> Dict[str, Any]:
    cy = face["cycles"][0]
    seg = cy["segments"][si]
    co = face["components"][seg["component"]]
    return {"kind": co["kind"], "walls": co["walls"], "factor": co["factor"]}


def _cert_index(cert_json: Dict[str, Any]):
    return {(c["field"], c["local_vertex_id"]): c for c in cert_json.get("certificates", [])}


def atlas_from_v50_reference(seed_or_path, compiled_or_path, v50_dir: str | Path, output_path=None) -> Dict[str, Any]:
    """Create a canonical exact cellular atlas from the sealed v50 reference artifacts.

    This is an adapter, not a generic discovery algorithm.  Its purpose is to
    bind the old source-certified v50 incidence data to the new generic schema
    and to regression-test the v0.2 regularizer without moving any NT boundary.
    """
    seed = _load(seed_or_path); comp = _load(compiled_or_path); root = Path(v50_dir)
    if not comp.get("exact_topology") or comp.get("field_count") != 62:
        raise ValueError("v50 reference adapter requires the exact closed 62-field regression atlas")
    faces_j = _load(root / "selling_face_cycles_v50.json")
    edges_j = _load(root / "selling_edge_orbits_v50.json")
    verts_j = _load(root / "selling_vertex_orbits_v50.json")
    vcert_j = _load(root / "selling_face_vertex_exact_certificates_v50.json")
    regular_j = _load(root / "selling_regular_TU_quotient_v50.json")
    for name, data in [("face cycles", faces_j), ("edge orbits", edges_j), ("vertex orbits", verts_j), ("vertex certificates", vcert_j)]:
        if data.get("status") not in {"PASS", "PASS-NUMERIC-CYCLE-STRUCTURE"}:
            raise ValueError(f"v50 {name} is not certified PASS: {data.get('status')}")
    if regular_j.get("status") != "PASS-EXACT-REGULAR-QUOTIENT" or not regular_j.get("partial1_partial2_zero"):
        raise ValueError("v50 regular quotient reference is not PASS-EXACT")

    face_by = {int(x["field"]): x for x in faces_j["faces"]}
    cert = _cert_index(vcert_j)
    # Exact local face data.  Numeric q/r are only display coordinates; exact
    # algebraic certificates remain attached and govern promotion.
    local_faces = []
    for fid in range(62):
        f = face_by[fid]
        cycle = f["cycles"][0]
        vv = []
        for lid in cycle["vertices"]:
            raw = f["vertices"][lid]
            c = cert.get((fid, lid))
            if c is None or not str(c.get("status", "")).startswith("PASS-EXACT"):
                raise ValueError(f"missing exact vertex certificate {(fid,lid)}")
            vv.append({"local_vertex_id": lid, "approx": [raw["q"], raw["r"]], "certificate": c})
        segments = []
        for si, s in enumerate(cycle["segments"]):
            info = _face_segment_info(f, si)
            segments.append({
                "segment_index": si,
                "component": s["component"],
                "v": s["v"],
                "kind": info["kind"],
                "walls": info["walls"],
                "factor": info["factor"],
            })
        local_faces.append({
            "field": fid,
            "vertices": vv,
            "components": f["components"],
            "cycle": {"vertices": cycle["vertices"], "segments": segments, "area_approx": cycle.get("area_approx")},
            "extra_components": f["cycles"][1:] if fid == 55 else [],
        })

    # Pre-regular quotient vertices with representative display coordinates.
    v_orbits = verts_j["vertex_orbits"]
    pre_vertices = []
    for vid, orb in enumerate(v_orbits):
        fid, lid = orb[0]
        raw = face_by[fid]["vertices"][lid]
        c = cert.get((fid, lid))
        pre_vertices.append({
            "id": vid, "kind": "ORBIT", "members": orb,
            "approx": [raw["q"], raw["r"]], "representative_certificate": c,
        })

    # Pre-regular edges and lookup occurrence -> edge orbit.
    edge_of = {tuple(k): ei for ei, orb in enumerate(edges_j["edge_orbits"]) for k in orb}
    endpoint_by = {int(x["edge"]): x for x in verts_j["edge_endpoints"]}
    pre_edges = []
    for eid, orb in enumerate(edges_j["edge_orbits"]):
        fid, si = orb[0]
        info = _face_segment_info(face_by[fid], si)
        ep = endpoint_by[eid]
        pre_edges.append({
            "id": eid, "kind": "BOUNDARY-ORBIT", "endpoints": [ep["v0"], ep["v1"]],
            "source_orbit": orb, "source_kind": info["kind"], "walls": info["walls"], "factor": info["factor"],
        })

    # Pre-regular face cycles, signs determined from quotient endpoints where possible.
    vorb = {tuple(k): vi for vi, orb in enumerate(v_orbits) for k in orb}
    pre_face_cycles: Dict[str, Any] = {}
    for fid in range(62):
        f = face_by[fid]; cy = f["cycles"][0]; V = cy["vertices"]
        steps = []
        for si, s in enumerate(cy["segments"]):
            eid = edge_of[(fid, si)]
            a = vorb[(fid, V[si])]; b = vorb[(fid, V[(si + 1) % len(V)])]
            ea, eb = pre_edges[eid]["endpoints"]
            if a == b == ea == eb:
                sign = 1; orientation_status = "LOOP-SIGN-NOT-USED-BY-REGULARIZER"
            elif [a, b] == [ea, eb]:
                sign = 1; orientation_status = "EXACT-ENDPOINT"
            elif [a, b] == [eb, ea]:
                sign = -1; orientation_status = "EXACT-ENDPOINT"
            else:
                raise ValueError(("pre-edge-endpoint-mismatch", fid, si, eid, [a,b], [ea,eb]))
            steps.append({"edge": eid, "sign": sign, "v_start": a, "v_end": b, "source": [fid, si], "orientation_status": orientation_status})
        pre_face_cycles[str(fid)] = steps

    # A plan is a typed list of local edits + the independently certified final
    # face cycles.  The generic regularizer will replay it and recompute d^2=0.
    final_vertices = regular_j["vertices"]
    final_edges = regular_j["edges"]
    operations = []
    for v in final_vertices[len(pre_vertices):]:
        operations.append({"op": "add_vertex", "vertex": v})
    for eid, e0 in enumerate(pre_edges):
        e1 = final_edges[eid]
        if e0["endpoints"] != e1["endpoints"]:
            operations.append({"op": "replace_edge_endpoints", "edge": eid, "endpoints": e1["endpoints"], "certificate": regular_j.get("fixed_midpoint_certificates", {})})
    for e in final_edges[len(pre_edges):]:
        operations.append({"op": "add_edge", "edge": e})

    fields = []
    for r in comp["records"]:
        fields.append({k: r.get(k) for k in ["id","path_matrix","wall_action_matrix","ordinary_walls","multiwall_components","neighbors","classifier"]})

    out = {
        "schema": "selling.atlas.v1",
        "toolchain": "selling_seed2d_toolchain_v0_2",
        "seed_name": seed["name"],
        "source_compiled_schema": comp["schema"],
        "status": "PASS-EXACT-CELLULAR-ATLAS/V50-REFERENCE-ADAPTER",
        "htnt": {
            "field_atlas": "PROVEN-EXACT",
            "cellular_incidence": "PROVEN-EXACT/V50-SOURCE-CERTIFIED-ADAPTER",
            "regularization_plan": "PROVEN-EXACT/V50-SOURCE-CERTIFIED-ADAPTER",
            "automatic_plan_derivation_for_arbitrary_seed": "NT",
        },
        "fields": fields,
        "cellular": {
            "status": "PASS-EXACT-PRE-REGULAR-INCIDENCE",
            "local_faces": local_faces,
            "pre_regular": {
                "vertex_orbits": pre_vertices,
                "edges": pre_edges,
                "face_cycles": pre_face_cycles,
                "counts": [len(pre_vertices), len(pre_edges), 62],
            },
            "regularization_plan": {
                "status": "PASS-EXACT-CERTIFIED-PLAN",
                "operations": operations,
                "final_face_cycles": regular_j["face_cycles"],
                "expected_counts": [regular_j["C0"], regular_j["C1"], regular_j["C2"]],
                "reference_partial1_partial2_zero": regular_j["partial1_partial2_zero"],
                "reference_structural_digest": _digest({
                    "counts": [regular_j["C0"], regular_j["C1"], regular_j["C2"]],
                    "edge_endpoints": [[e["id"], e["endpoints"]] for e in regular_j["edges"]],
                    "face_cycles": regular_j["face_cycles"],
                    "partial1_sparse": regular_j["partial1_sparse"], "partial2_sparse": regular_j["partial2_sparse"],
                }),
            },
        },
        "guards": [
            "This adapter transports already certified v50 cellular data into the new schema; it does not claim a generic source-to-cycle solver.",
            "The v0.2 regularizer is generic over a certified regularization plan; automatic derivation of that plan for an arbitrary seed remains NT.",
            "Layout/raster data do not participate in incidence or regularization.",
        ],
    }
    out["sha256_without_self_hash"] = _digest(out)
    if output_path:
        write_json(out, output_path)
    return out
