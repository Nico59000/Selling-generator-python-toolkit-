from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

from jsonschema import Draft202012Validator


SCHEMA_FILES = {
    "selling.seed.v1": "selling.seed.v1.schema.json",
    "selling.compiled.v1": "selling.compiled.v1.schema.json",
    "selling.atlas.v1": "selling.atlas.v1.schema.json",
    "selling.regular_complex.v1": "selling.regular_complex.v1.schema.json",
    "selling.layout.v1": "selling.layout.v1.schema.json",
}


def schema_dir() -> Path:
    return Path(__file__).resolve().parent.parent / "schemas"


def load_schema(schema_id: str) -> Dict[str, Any]:
    if schema_id not in SCHEMA_FILES:
        raise KeyError(f"unknown schema id {schema_id!r}")
    return json.loads((schema_dir() / SCHEMA_FILES[schema_id]).read_text(encoding="utf-8"))


def validate_json_object(obj: Dict[str, Any], schema_id: str | None = None) -> None:
    sid = schema_id or obj.get("schema")
    if not sid:
        raise ValueError("object has no schema")
    schema = load_schema(sid)
    errors = sorted(Draft202012Validator(schema).iter_errors(obj), key=lambda e: list(e.path))
    if errors:
        msg = "; ".join(f"{'.'.join(map(str,e.path)) or '<root>'}: {e.message}" for e in errors[:12])
        raise ValueError(f"schema validation failed for {sid}: {msg}")


def write_json(obj: Dict[str, Any], path: str | Path, *, validate: bool = True) -> str:
    if validate:
        validate_json_object(obj)
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")
    return str(p)
