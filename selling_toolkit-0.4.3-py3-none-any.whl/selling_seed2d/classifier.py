from __future__ import annotations

from typing import Dict, Any, List
import sympy as sp

from .algebra import WALLS


class ExactBoundaryClassifier:
    """Generalization of v50 exact_boundary_arc_classifier_v50.

    The classifier is seed-parametric: it receives the six exact wall numerators
    and the exact hyperboloid-domain polynomial D0. It certifies open real arcs,
    distinguishes one-wall arcs from multiwall/mirror factors, and never uses
    raster morphology to create combinatorics.
    """
    def __init__(self, q: sp.Symbol, r: sp.Symbol, wall_vector: sp.Matrix, D0: sp.Expr):
        self.q=q; self.r=r; self.wall_vector=wall_vector; self.D0=sp.factor(D0)

    def primitive_factor_list(self, poly):
        q,r=self.q,self.r
        P=sp.Poly(sp.expand(poly),q,r,domain=sp.QQ)
        _coeff,fac=sp.factor_list(P.as_expr())
        out=[]
        for f,m in fac:
            F=sp.Poly(f,q,r,domain=sp.QQ)
            _cont,prim=sp.polys.polytools.primitive(F.as_expr(),q,r)
            F=sp.Poly(prim,q,r,domain=sp.QQ)
            if F.LC()<0:F=-F
            out.append((sp.factor(F.as_expr()),m))
        return out

    def divisible(self, poly, f):
        q,r=self.q,self.r
        return sp.Poly(poly,q,r,domain=sp.QQ).rem(sp.Poly(f,q,r,domain=sp.QQ)).is_zero

    def critical_q_poly(self, f, polys):
        q,r=self.q,self.r
        terms=[]
        F=sp.Poly(f,q,r,domain=sp.QQ)
        lc=sp.Poly(F.as_poly(r).LC(),q,domain=sp.QQ)
        if lc.degree()>0:terms.append(lc.as_expr())
        dr=sp.diff(f,r)
        if dr!=0:
            res=sp.resultant(f,dr,r)
            if res!=0:terms.append(sp.Poly(res,q,domain=sp.QQ).as_expr())
        for g in polys:
            if self.divisible(g,f):continue
            res=sp.resultant(f,g,r)
            if res!=0:
                rr=sp.Poly(res,q,domain=sp.QQ)
                if rr.degree()>0:terms.append(rr.as_expr())
        if not terms:return sp.Poly(1,q,domain=sp.QQ)
        return sp.Poly(sp.prod(terms),q,domain=sp.QQ).sqf_part()

    def real_root_intervals(self,P,eps=sp.Rational(1,10)**10):
        if P.degree()<=0:return []
        return [iv for iv,m in sp.intervals(P,eps=eps) if m>=1]

    def q_samples_from_critical(self,P):
        ints=self.real_root_intervals(P)
        if not ints:return [sp.Rational(0)]
        samples=[]
        a0,b0=ints[0]; samples.append(sp.floor(a0)-1)
        for (a,b),(c,d) in zip(ints,ints[1:]):
            if b<c:samples.append((b+c)/2)
        an,bn=ints[-1]; samples.append(sp.ceiling(bn)+1)
        return samples

    def root_sign(self, poly_r, root_poly, iv):
        r=self.r
        G=sp.Poly(poly_r,r,domain=sp.QQ);F=sp.Poly(root_poly,r,domain=sp.QQ)
        if G.is_zero:return 0
        gd=sp.gcd(F,G)
        if gd.degree()>0:
            for giv,m in sp.intervals(gd,eps=sp.Rational(1,10)**14):
                if not (giv[1] < iv[0] or iv[1] < giv[0]):return 0
        groots=[x for x,m in sp.intervals(G,eps=sp.Rational(1,10)**14)] if G.degree()>0 else []
        a,b=iv
        for _ in range(12):
            overlap=any(not (gb<a or b<ga) for ga,gb in groots)
            if not overlap:break
            a,b=sp.refine_root(F,a,b,eps=(b-a)/10)
        mid=(a+b)/2;val=G.eval(mid)
        if val>0:return 1
        if val<0:return -1
        raise RuntimeError(("undecided-sign",G,F,(a,b)))

    def classify_vertical_factor(self,f,polys):
        q,r=self.q,self.r
        F=sp.Poly(f,q,r,domain=sp.QQ)
        if F.degree(r)!=0 or F.degree(q)!=1:return []
        qq=sp.solve(sp.Eq(f,0),q)[0]
        crit=[]
        for p in list(polys.values())+[self.D0]:
            pr=sp.Poly(sp.expand(p.subs(q,qq)),r,domain=sp.QQ)
            if pr.is_zero or pr.degree()<=0:continue
            crit.append(pr.as_expr())
        if crit:
            C=sp.Poly(sp.prod(crit),r,domain=sp.QQ).sqf_part()
            ints=[iv for iv,m in sp.intervals(C,eps=sp.Rational(1,10)**12)]
        else:ints=[]
        samples=[]
        if ints:
            samples.append(sp.floor(ints[0][0])-1)
            for (a,b),(c,d) in zip(ints,ints[1:]):
                if b<c:samples.append((b+c)/2)
            samples.append(sp.ceiling(ints[-1][1])+1)
        else:samples=[sp.Rational(0)]
        valid=[]
        for rr in samples:
            signs={}
            for lab,p in polys.items():
                val=sp.simplify(p.subs({q:qq,r:rr}))
                signs[lab]=0 if val==0 else (1 if val>0 else -1)
            dv=sp.simplify(self.D0.subs({q:qq,r:rr}))
            if dv>0 and all(v<=0 for v in signs.values()):
                valid.append({"q":str(qq),"r":str(rr),"signs":signs})
        return valid

    def classify_cell(self,L: sp.Matrix) -> Dict[str,Any]:
        q,r=self.q,self.r
        vec=L*self.wall_vector
        polys={WALLS[i]:sp.factor(vec[i]) for i in range(6)}
        unique={}
        for lab,p in polys.items():
            for f,m in self.primitive_factor_list(p):
                key=sp.srepr(f)
                unique.setdefault(key,{"factor":f,"walls":set()})["walls"].add(lab)
        arcs=[];all_constraints=list(polys.values())+[self.D0]
        for item in unique.values():
            f=item["factor"];wallset=sorted(item["walls"])
            vvalid=self.classify_vertical_factor(f,polys)
            if vvalid:
                arcs.append({"factor":str(f),"walls":wallset,"kind":"ORDINARY" if len(wallset)==1 else "MULTIWALL","samples":vvalid})
                continue
            C=self.critical_q_poly(f,all_constraints);qs=self.q_samples_from_critical(C);valid=[]
            for q0 in qs:
                fq=sp.Poly(sp.expand(f.subs(q,q0)),r,domain=sp.QQ)
                if fq.is_zero or fq.degree()<=0:continue
                for iv,mult in sp.intervals(fq,eps=sp.Rational(1,10)**12):
                    signs={lab:self.root_sign(sp.expand(p.subs(q,q0)),fq,iv) for lab,p in polys.items()}
                    sd=self.root_sign(sp.expand(self.D0.subs(q,q0)),fq,iv)
                    if sd>0 and all(v<=0 for v in signs.values()):
                        valid.append({"q":str(q0),"r_interval":[str(iv[0]),str(iv[1])],"signs":signs})
            if valid:
                arcs.append({"factor":str(f),"walls":wallset,"kind":"ORDINARY" if len(wallset)==1 else "MULTIWALL","samples":valid})
        ordinary=sorted({a["walls"][0] for a in arcs if a["kind"]=="ORDINARY"})
        multi=[a for a in arcs if a["kind"]=="MULTIWALL"]
        return {"polynomials":{k:str(v) for k,v in polys.items()},"arcs":arcs,"ordinary_walls":ordinary,"multiwall_components":multi}


class SampledBoundaryClassifier:
    """Numerical fallback for visualization-only seeds.

    This never upgrades topology to exact/historical status. It only discovers
    candidate ordinary walls by grid sampling inside the D0>0 reduced region.
    """
    def __init__(self,q,r,wall_vector,D0,q_range=(-2,2),r_range=(-1.2,1.2),resolution=220,tol=2e-2):
        import numpy as np
        self.q=q;self.r=r;self.wall_vector=wall_vector;self.D0=D0
        self.q_range=q_range;self.r_range=r_range;self.resolution=resolution;self.tol=tol
        self.np=np
        self.fD=sp.lambdify((q,r),D0,"numpy")

    def classify_cell(self,L):
        np=self.np
        qv=np.linspace(*self.q_range,self.resolution);rv=np.linspace(*self.r_range,self.resolution)
        Q,R=np.meshgrid(qv,rv)
        D=np.asarray(self.fD(Q,R),dtype=float)
        vec=L*self.wall_vector
        polys={WALLS[i]:sp.factor(vec[i]) for i in range(6)}
        vals={k:np.asarray(sp.lambdify((self.q,self.r),p,"numpy")(Q,R),dtype=float) for k,p in polys.items()}
        reduced=(D>0)
        for a in vals.values(): reduced &= (a<=self.tol)
        ordinary=[]
        for k,a in vals.items():
            # boundary candidate: near zero, all others reduced, domain positive
            mask=(D>0)&(np.abs(a)<=self.tol)
            for kk,b in vals.items():
                if kk!=k: mask &= (b<=self.tol)
            if mask.sum()>=3: ordinary.append(k)
        return {"polynomials":{k:str(v) for k,v in polys.items()},"arcs":[],"ordinary_walls":sorted(ordinary),"multiwall_components":[],"status":"SAMPLED/VISUALIZATION-ONLY"}
