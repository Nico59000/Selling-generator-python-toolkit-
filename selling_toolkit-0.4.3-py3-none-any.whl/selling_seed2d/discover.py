from __future__ import annotations

from pathlib import Path
from typing import Dict, Any, Tuple
import hashlib
import json
import sympy as sp

from .algebra import S, FIRST_MOVE, WALL_ACTION, RELABEL, matrix_key, build_finite_group
from .seed import load_seed, seed_matrices
from .chart import build_chart
from .classifier import ExactBoundaryClassifier, SampledBoundaryClassifier


def _json_matrix(M: sp.Matrix):
    return [[str(sp.simplify(x)) for x in row] for row in M.tolist()]


def compile_seed(seed_or_path, output_path=None, progress=False) -> Dict[str,Any]:
    seed=load_seed(seed_or_path) if not isinstance(seed_or_path,dict) else seed_or_path
    chart=build_chart(seed)
    Q,A0,Qc,deck_named=seed_matrices(seed)
    cfg=seed["compile"]
    mode=seed.get("quotient",{}).get("mode","superbase")
    use_relabel=bool(cfg.get("use_superbase_relabelling",True)) and mode in {"superbase","deck-superbase"}
    use_deck=bool(deck_named) and mode=="deck-superbase"
    use_sign=bool(cfg.get("projective_sign",True))

    if use_deck:
        deck_group=build_finite_group([g for _,g in deck_named],int(cfg.get("deck_group_max_size",256)))
    else:
        deck_group=[sp.eye(3)]

    classifier_name=cfg.get("classifier","exact")
    if classifier_name=="exact":
        classifier=ExactBoundaryClassifier(chart.q,chart.r,chart.wall_vector,chart.D0)
    elif classifier_name=="sampled":
        rr=seed["render"]
        classifier=SampledBoundaryClassifier(chart.q,chart.r,chart.wall_vector,chart.D0,
            tuple(rr["q_range"]),tuple(rr["r_range"]),min(280,int(rr.get("resolution",650))))
    else:
        raise ValueError("compile.classifier must be exact or sampled")

    max_fields=int(cfg.get("max_fields",120))
    reps=[sp.eye(3)]
    Lreps=[sp.eye(6)]
    records=[]
    variants={}

    relabels=RELABEL if use_relabel else [sp.eye(3)]
    def add_variants(idx,A):
        for di,D in enumerate(deck_group):
            DA=sp.simplify(D*A)
            for bi,B in enumerate(relabels):
                X=sp.simplify(DA*B)
                variants.setdefault(matrix_key(X),(idx,di,bi,1))
                if use_sign:
                    variants.setdefault(matrix_key(-X),(idx,di,bi,-1))

    add_variants(0,reps[0])
    qi=0; fallback_count=0
    while qi < len(reps) and len(reps) <= max_fields:
        A=reps[qi]; L=Lreps[qi]
        try:
            cls=classifier.classify_cell(L)
            classifier_used=classifier_name
        except Exception as exc:
            if classifier_name=="exact" and cfg.get("fallback_sampled_classifier",True):
                rr=seed["render"]
                sc=SampledBoundaryClassifier(chart.q,chart.r,chart.wall_vector,chart.D0,
                    tuple(rr["q_range"]),tuple(rr["r_range"]),min(280,int(rr.get("resolution",650))))
                cls=sc.classify_cell(L); classifier_used="sampled-fallback"; fallback_count+=1
                cls["fallback_reason"]=repr(exc)
            else:
                raise
        rec={
            "id":qi,
            "path_matrix":_json_matrix(A),
            "wall_action_matrix":_json_matrix(L),
            "ordinary_walls":cls["ordinary_walls"],
            "multiwall_components":[{"factor":x["factor"],"walls":x["walls"]} for x in cls.get("multiwall_components",[])],
            "classifier":classifier_used,
            "neighbors":{},
        }
        for w in cls["ordinary_walls"]:
            An=sp.simplify(A*S[FIRST_MOVE[w]-1])
            Ln=sp.simplify(WALL_ACTION[w]*L)
            key=matrix_key(An)
            if key in variants:
                j,di,bi,sgn=variants[key]
                rec["neighbors"][w]={"target":j,"new":False,"deck_index":di,"relabel_index":bi,"sign":sgn}
            else:
                if len(reps)>=max_fields:
                    rec["neighbors"][w]={"target":None,"new":True,"truncated":True}
                    continue
                j=len(reps); reps.append(An); Lreps.append(Ln); add_variants(j,An)
                rec["neighbors"][w]={"target":j,"new":True}
        records.append(rec)
        if progress:
            print(f"field {qi}: ordinary={rec['ordinary_walls']} multi={[(x['walls'],x['factor']) for x in rec['multiwall_components']]} known={len(reps)}")
        qi+=1

    closed=(qi==len(reps) and len(reps)<=max_fields and all(n.get("target") is not None for r in records for n in r["neighbors"].values()))
    exact_all=all(r["classifier"]=="exact" for r in records)
    if closed and exact_all:
        status="PASS-CLOSED-EXACT"
    elif closed:
        status="CLOSED-SAMPLED/VISUALIZATION-ONLY"
    else:
        status="OPEN/TRUNCATED"

    out={
        "schema":"selling.compiled.v1",
        "toolchain":"selling_seed2d_toolchain_v0_1",
        "seed_name":seed["name"],
        "status":status,
        "closed":closed,
        "all_visited_exact":bool(exact_all),
        "exact_topology":bool(closed and exact_all),
        "fallback_count":fallback_count,
        "field_count":len(reps),
        "processed":qi,
        "quotient_mode":mode,
        "deck_group_size":len(deck_group),
        "use_superbase_relabelling":use_relabel,
        "projective_sign":use_sign,
        "chart":chart.as_jsonable(),
        "records":records,
        "guards":[
            "Exact topology is promoted only when every visited field used the exact algebraic boundary classifier.",
            "Sampled fallback is visualization-only and cannot certify historical incidence.",
            "The renderer uses generated algebraic walls; the source raster is validation-only.",
        ],
    }
    payload=json.dumps(out,indent=2,ensure_ascii=False).encode("utf-8")
    out["sha256_without_self_hash"]=hashlib.sha256(payload).hexdigest()
    if output_path:
        Path(output_path).write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding="utf-8")
    return out
