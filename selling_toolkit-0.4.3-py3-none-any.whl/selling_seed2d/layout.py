from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Dict

import networkx as nx
import numpy as np

from .schemaio import validate_json_object, write_json


def _load(x):
    if isinstance(x, dict):
        return x
    return json.loads(Path(x).read_text(encoding="utf-8"))


def _digest(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")).hexdigest()


def _native_positions(reg: Dict[str, Any]):
    pos = {}
    missing = []
    for v in reg["vertices"]:
        if "approx" in v and len(v["approx"]) == 2:
            pos[int(v["id"])] = (float(v["approx"][0]), float(v["approx"][1]))
        else:
            missing.append(int(v["id"]))
    return pos, missing


def _topological_positions(reg: Dict[str, Any]):
    G = nx.Graph()
    G.add_nodes_from(range(reg["C0"]))
    for e in reg["edges"]:
        a, b = map(int, e["endpoints"])
        if a != b:
            G.add_edge(a, b)
    # Deterministic graph-only layout; no source raster and no chart coordinates.
    raw = nx.spring_layout(G, seed=0, iterations=300, scale=1.0)
    return {int(k): (float(v[0]), float(v[1])) for k, v in raw.items()}


def build_layout(regular_or_path, output_path=None, *, mode="chart_native", style="selling") -> Dict[str, Any]:
    reg = _load(regular_or_path)
    validate_json_object(reg, "selling.regular_complex.v1")
    if not str(reg.get("status", "")).startswith("PASS-EXACT"):
        raise ValueError("layout generation requires an exact regular complex")
    if mode == "chart_native":
        pos, missing = _native_positions(reg)
        if missing:
            raise ValueError(f"chart_native layout lacks coordinates for vertices {missing[:12]}")
        layout_status = "PASS-CHART-NATIVE/RASTER-INDEPENDENT"
    elif mode == "topological_independent":
        pos = _topological_positions(reg)
        layout_status = "PASS-GRAPH-ONLY/RASTER-INDEPENDENT"
    else:
        raise ValueError("mode must be chart_native or topological_independent")

    nodes = []
    for v in reg["vertices"]:
        vid = int(v["id"]); x, y = pos[vid]
        nodes.append({"id": vid, "x": x, "y": y, "kind": v.get("kind", "VERTEX")})

    edges = []
    for e in reg["edges"]:
        eid = int(e["id"]); a, b = map(int, e["endpoints"])
        walls = e.get("walls", [])
        label = "/".join(walls) if walls else (e.get("deck") if e.get("kind") == "DECK-FIXED-MIRROR" else "")
        edges.append({
            "id": eid, "v0": a, "v1": b,
            "x0": pos[a][0], "y0": pos[a][1], "x1": pos[b][0], "y1": pos[b][1],
            "kind": e.get("kind", "EDGE"), "source_kind": e.get("source_kind"),
            "walls": walls, "label": label,
        })

    faces = []
    for fid in range(reg["C2"]):
        steps = reg["face_cycles"][str(fid)]
        vids = [int(st["v_start"]) for st in steps]
        pts = [pos[v] for v in vids]
        cx = float(np.mean([p[0] for p in pts])); cy = float(np.mean([p[1] for p in pts]))
        faces.append({"id": fid, "vertex_cycle": vids, "centroid": [cx, cy]})

    if style == "selling":
        style_obj = {
            "profile": "selling-independent-v1",
            "background": "paper-white",
            "ordinary_edge_width": 0.8,
            "multiwall_edge_width": 1.4,
            "mirror_edge_width": 1.8,
            "node_radius": 1.4,
            "face_labels": True,
            "wall_labels": True,
            "note": "Styling is generated from typed edge metadata only; no historical raster is sampled."
        }
    elif style == "plain":
        style_obj = {"profile": "plain-v1", "ordinary_edge_width": 0.8, "multiwall_edge_width": 0.8, "mirror_edge_width": 1.2, "node_radius": 1.2, "face_labels": True, "wall_labels": False}
    else:
        raise ValueError("style must be selling or plain")

    out = {
        "schema": "selling.layout.v1",
        "toolchain": "selling_seed2d_toolchain_v0_2",
        "seed_name": reg["seed_name"],
        "status": layout_status,
        "mode": mode,
        "geometry_level": "INCIDENCE-CHORD-LAYOUT/NOT-ALGEBRAIC-ARC-GEOMETRY",
        "nodes": nodes,
        "edges": edges,
        "faces": faces,
        "style": style_obj,
        "annotations": [],
        "guards": [
            "Layout changes do not alter C0/C1/C2, boundary matrices, edge endpoints or face cycles.",
            "topological_independent uses only the regular complex graph; chart_native uses algebraic q,r coordinates attached before rendering.",
            "No raster/image feature is used to infer missing incidence.",
            "Edges are layout chords between certified vertices; exact algebraic boundary-curve geometry remains a separate rendering refinement."
        ]
    }
    out["source_regular_structural_digest"] = reg.get("certificates", {}).get("structural_digest")
    out["sha256_without_self_hash"] = _digest(out)
    if output_path:
        write_json(out, output_path)
    return out
