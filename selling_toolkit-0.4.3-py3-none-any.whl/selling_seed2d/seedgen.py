from __future__ import annotations

from pathlib import Path
from typing import Dict, Any
import random
import sympy as sp

from .seed import SEED_SCHEMA, save_seed, default_compile, default_render
from .algebra import int_matrix, signature


def random_unimodular(rng: random.Random, steps: int = 8, shear_bound: int = 2) -> sp.Matrix:
    C=sp.eye(3)
    for _ in range(steps):
        op=rng.choice(["swap","sign","shear"])
        if op=="swap":
            i,j=rng.sample(range(3),2)
            P=sp.eye(3);P.row_swap(i,j);C=P*C
        elif op=="sign":
            i=rng.randrange(3);P=sp.eye(3);P[i,i]=-1;C=P*C
        else:
            i,j=rng.sample(range(3),2);k=0
            while k==0:k=rng.randint(-shear_bound,shear_bound)
            P=sp.eye(3);P[i,j]=k;C=P*C
    assert abs(int(C.det()))==1
    return C


def _global_chart(Qc: sp.Matrix) -> bool:
    B=sp.simplify(Qc.inv())[1:3,1:3]
    det2=sp.factor(B.det())
    return bool(det2>0 and B[0,0]<0)


def _generic_marked_form(D: sp.Matrix, rng: random.Random) -> tuple[sp.Matrix,sp.Matrix]:
    """Return a nontrivially marked integral GL(3,Z)-equivalent form Qc=B^T D B.

    We retain only gauges for which q=z/x,r=-y/x is global.  The returned B is
    provenance only; the compiler works directly with Qc.
    """
    for steps in range(2,13):
        for _ in range(30):
            B=random_unimodular(rng,steps=steps,shear_bound=2)
            Qc=sp.simplify(B.T*D*B)
            if Qc==D or max(abs(int(x)) for x in Qc)>250:
                continue
            if signature(Qc)==(1,2,0) and _global_chart(Qc):
                return Qc,B
    # Fail closed to the diagonal marked form rather than fabricate a bad chart.
    return D,sp.eye(3)


def _ellipse_render_bounds(Qc: sp.Matrix, margin: float = 1.15):
    """Conservative axis-aligned bounds for the global conic D0(q,r)>0."""
    q,r=sp.symbols('q r',real=True)
    u=sp.Matrix([1,-r,q]); det=sp.factor(Qc.det())
    D0=sp.expand(det*(u.T*Qc.inv()*u)[0])
    # D0 = c + l^T x + x^T H x with H negative definite.
    x=sp.Matrix([q,r])
    H=sp.hessian(D0,(q,r))/2
    lin=sp.Matrix([sp.diff(D0,q).subs({q:0,r:0}),sp.diff(D0,r).subs({q:0,r:0})])
    ctr=sp.simplify(-sp.Rational(1,2)*H.inv()*lin)
    R=sp.simplify(D0.subs({q:ctr[0],r:ctr[1]}))
    A=-H
    Ai=sp.simplify(A.inv())
    if not (sp.N(R)>0 and sp.N(A.det())>0 and sp.N(A[0,0])>0):
        return [-2.0,2.0],[-1.2,1.2]
    eq=float(sp.sqrt(R*Ai[0,0])); er=float(sp.sqrt(R*Ai[1,1]))
    cq=float(ctr[0]); cr=float(ctr[1])
    return [cq-margin*eq,cq+margin*eq],[cr-margin*er,cr+margin*er]


def generate_seed(*, rng_seed: int = 0, a: int | None = None, b: int | None = None,
                  c: int | None = None, h: int | None = None, preset: str = "generic", conjugate_steps: int = 8,
                  name: str | None = None, classifier: str = "exact") -> Dict[str,Any]:
    """Generate a schema-compatible seed without reading any raster.

    ``v4`` deliberately creates a high-symmetry marked form with a finite V4
    deck group. ``generic``/``none`` creates a nontrivially marked form and no
    deck quotient, which is useful for stress-testing the universal renderer.
    """
    rng=random.Random(rng_seed)
    a=a or rng.randint(3,13); b=b or rng.randint(1,9); c=c or rng.randint(1,9)
    D=sp.diag(a,-b,-c)

    if preset=="v4":
        # High-symmetry finite-deck stress seed.
        Qc=D; Bmark=sp.eye(3); family={"type":"diagonal-v4","h":0}
    elif preset in {"none","generic"}:
        # A broad global-chart family containing the historical Q2 shape
        # [[7,0,2],[0,-1,0],[2,0,-8]].  For positive a,b,c it always has
        # signature (+,--), positive determinant and a global q,r chart; in
        # practice it also gives a nonempty ordinary-wall base cell.
        h=h or rng.randint(1,max(1,min(4,int((a*c)**0.5))))
        Qc=sp.Matrix([[a,0,h],[0,-b,0],[h,0,-c]])
        Bmark=sp.eye(3); family={"type":"xz-coupled-global","h":h}
    else:
        raise ValueError("preset must be v4, none, or generic")

    # Outer lattice gauge: keeps the compiler input nontrivial while the
    # chart_transform exactly recovers the selected marked form Qc.
    C=random_unimodular(rng,steps=conjugate_steps) if conjugate_steps else sp.eye(3)
    Q=sp.simplify(C.T*Qc*C)
    A=sp.simplify(C.inv())  # integral unimodular; A^T Q A = Qc.
    assert all(sp.Rational(x).q==1 for x in list(A)) and abs(int(A.det()))==1

    deck=[]
    if preset=="v4":
        H1=sp.diag(-1,1,1); H2=sp.diag(1,-1,1)
        for nm,H in [("T",H1),("U",H2)]:
            G=sp.simplify(A*H*A.inv())
            assert sp.simplify(G.T*Q*G-Q)==sp.zeros(3)
            deck.append({"name":nm,"matrix":int_matrix(G)})

    comp=default_compile(); comp["classifier"]=classifier
    qrange,rrange=_ellipse_render_bounds(Qc)
    render=default_render(); render["q_range"]=qrange; render["r_range"]=rrange
    seed={
        "schema":SEED_SCHEMA,
        "name":name or f"generated_{preset}_rng{rng_seed}_diag_{a}_{b}_{c}",
        "provenance":{
            "kind":"generated-compatible-seed",
            "generator":"selling_seed2d.seedgen.generate_seed",
            "rng_seed":rng_seed,
            "diagonal_model":[a,-b,-c],
            "seed_family":family,
            "marked_form_transform":int_matrix(Bmark),
            "outer_conjugating_unimodular":int_matrix(C),
            "historical_claim":"NONE: synthetic seed for the generic constructor",
        },
        "indefinite_gram":int_matrix(Q),
        "chart_transform":int_matrix(A),
        "quotient":{
            "mode":"deck-superbase" if deck else "superbase",
            "deck_generators":deck,
        },
        "compile":comp,
        "render":render,
    }
    return seed


def generate_to_file(path: str | Path, **kwargs):
    seed=generate_seed(**kwargs);save_seed(seed,path);return seed
