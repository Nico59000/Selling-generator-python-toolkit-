from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

from .schemaio import validate_json_object


def _load(x):
    if isinstance(x, dict):
        return x
    return json.loads(Path(x).read_text(encoding="utf-8"))


def render_layout(layout_or_path, output_path, *, dpi=220, title=None) -> str:
    """Render a normalized layout to PNG, SVG or PDF from its file extension."""
    import matplotlib.pyplot as plt

    lay = _load(layout_or_path)
    validate_json_object(lay, "selling.layout.v1")
    node = {int(v["id"]): v for v in lay["nodes"]}
    xs = [v["x"] for v in lay["nodes"]]; ys = [v["y"] for v in lay["nodes"]]
    if not xs:
        raise ValueError("layout has no nodes")
    dx = max(xs) - min(xs); dy = max(ys) - min(ys)
    pad = 0.08 * max(dx, dy, 1.0)

    fig, ax = plt.subplots(figsize=(10, 9))
    ax.set_aspect("equal", adjustable="box")
    ax.set_xlim(min(xs)-pad, max(xs)+pad); ax.set_ylim(min(ys)-pad, max(ys)+pad)
    ax.axis("off")
    ax.set_title(title or f"Selling seed2d - {lay['seed_name']} - {lay['mode']}", fontsize=10)
    st = lay.get("style", {})

    for e in lay["edges"]:
        kind = e.get("kind", "")
        sk = e.get("source_kind")
        if kind == "DECK-FIXED-MIRROR":
            lw = float(st.get("mirror_edge_width", 1.8)); ls = "-"
        elif sk in {"MULTI", "MULTIWALL"}:
            lw = float(st.get("multiwall_edge_width", 1.4)); ls = "-"
        else:
            lw = float(st.get("ordinary_edge_width", 0.8)); ls = "-"
        ax.plot([e["x0"], e["x1"]], [e["y0"], e["y1"]], linewidth=lw, linestyle=ls, color="black")
        if st.get("wall_labels") and e.get("label"):
            mx=(e["x0"]+e["x1"])/2; my=(e["y0"]+e["y1"])/2
            ax.text(mx, my, e["label"], fontsize=4.7, ha="center", va="center")

    ax.scatter(xs, ys, s=float(st.get("node_radius",1.4))*4.0, zorder=3, color="black")
    if st.get("face_labels", True):
        for f in lay["faces"]:
            ax.text(f["centroid"][0], f["centroid"][1], str(f["id"]), fontsize=5.0, ha="center", va="center")

    ax.text(0.01, 0.01, "layout raster-independent; incidence fixed upstream", transform=ax.transAxes, fontsize=6.5, ha="left", va="bottom")
    fig.tight_layout()
    p = Path(output_path); p.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(p, dpi=dpi, bbox_inches="tight")
    plt.close(fig)
    return str(p)
