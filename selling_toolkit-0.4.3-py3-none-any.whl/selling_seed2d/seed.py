from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List
import json
import sympy as sp

from .algebra import int_matrix, signature

SEED_SCHEMA = "selling.seed.v1"


def _matrix(obj, name: str) -> sp.Matrix:
    try:
        M=sp.Matrix([[sp.Rational(x) for x in row] for row in obj])
    except Exception as e:
        raise ValueError(f"invalid {name}: {e}") from e
    if M.shape != (3,3):
        raise ValueError(f"{name} must be 3x3")
    return M


def default_render() -> Dict[str, Any]:
    return {
        "q_range": [-2.0, 2.0],
        "r_range": [-1.2, 1.2],
        "resolution": 650,
        "labels": True,
        "fill_fields": False,
        "show_domain_boundary": True,
        "line_width": 0.7,
    }


def default_compile() -> Dict[str, Any]:
    return {
        "classifier": "exact",
        "max_fields": 120,
        "deck_group_max_size": 256,
        "use_superbase_relabelling": True,
        "projective_sign": True,
        "fallback_sampled_classifier": True,
    }


def validate_seed(seed: Dict[str, Any], strict: bool = True) -> Dict[str, Any]:
    if seed.get("schema") != SEED_SCHEMA:
        raise ValueError(f"seed schema must be {SEED_SCHEMA!r}")
    if not seed.get("name"):
        raise ValueError("seed.name is required")
    Q=_matrix(seed.get("indefinite_gram"), "indefinite_gram")
    if Q != Q.T:
        raise ValueError("indefinite_gram must be symmetric")
    sig=signature(Q)
    if sig != (1,2,0):
        raise ValueError(f"indefinite_gram must have signature (+,--), got {sig}; negate a (--,+) convention before use")
    if sp.factor(Q.det()) <= 0:
        raise ValueError("signature (+,--) requires positive determinant")

    A=_matrix(seed.get("chart_transform", sp.eye(3).tolist()), "chart_transform")
    if A.det()==0:
        raise ValueError("chart_transform must be invertible")
    if strict:
        if any(sp.Rational(x).q != 1 for x in list(A)) or abs(int(A.det())) != 1:
            raise ValueError("chart_transform must lie in GL(3,Z) in strict mode; the universal Selling moves are lattice/superbase moves")
    Qc=sp.simplify(A.T*Q*A)

    quotient=seed.setdefault("quotient", {})
    quotient.setdefault("mode", "deck-superbase" if quotient.get("deck_generators") else "superbase")
    dgens=quotient.setdefault("deck_generators", [])
    for i,g in enumerate(dgens):
        if not isinstance(g,dict) or "matrix" not in g:
            raise ValueError(f"quotient.deck_generators[{i}] must have name,matrix")
        G=_matrix(g["matrix"], f"deck_generators[{i}].matrix")
        if G.det()==0:
            raise ValueError(f"deck generator {g.get('name',i)} is singular")
        if sp.simplify(G.T*Q*G-Q) != sp.zeros(3):
            raise ValueError(f"deck generator {g.get('name',i)} does not preserve indefinite_gram")

    seed.setdefault("compile", default_compile())
    c=default_compile(); c.update(seed["compile"]); seed["compile"]=c
    seed.setdefault("render", default_render())
    r=default_render(); r.update(seed["render"]); seed["render"]=r

    # Compute chart coverage diagnostic. It is not mandatory: a chart can be partial,
    # but we record whether x=0 can meet the real hyperboloid.
    Qin=sp.simplify(Qc.inv())
    y,z=sp.symbols("y z", real=True)
    restr=sp.factor((sp.Matrix([0,y,z]).T*Qin*sp.Matrix([0,y,z]))[0])
    # Determinant/discriminant of the 2x2 restriction: definite iff eigenvalues same sign.
    B=Qin[1:3,1:3]
    Bsig=signature(B.row_join(sp.zeros(2,1)).col_join(sp.zeros(1,3))) if False else None
    # Exact 2x2 definiteness test.
    b11,b12,b22=B[0,0],B[0,1],B[1,1]
    det2=sp.factor(b11*b22-b12*b12)
    chart_global=bool(det2>0 and b11<0)  # for (+,--) hyperboloid sheet, x=0 restriction negative definite

    seed["derived"]={
        "signature": list(sig),
        "determinant": str(sp.factor(Q.det())),
        "chart_gram": [[str(x) for x in row] for row in Qc.tolist()],
        "chart_det": str(sp.factor(Qc.det())),
        "x0_restriction": str(restr),
        "chart_global_projective": chart_global,
    }
    return seed


def load_seed(path: str | Path, strict: bool = True) -> Dict[str, Any]:
    data=json.loads(Path(path).read_text(encoding="utf-8"))
    return validate_seed(data, strict=strict)


def save_seed(seed: Dict[str, Any], path: str | Path) -> None:
    seed=validate_seed(seed)
    Path(path).write_text(json.dumps(seed,indent=2,ensure_ascii=False),encoding="utf-8")


def seed_matrices(seed: Dict[str, Any]):
    Q=_matrix(seed["indefinite_gram"],"indefinite_gram")
    A=_matrix(seed.get("chart_transform",sp.eye(3).tolist()),"chart_transform")
    deck=[]
    for g in seed.get("quotient",{}).get("deck_generators",[]):
        G=_matrix(g["matrix"],"deck_generator")
        # Move original-basis automorphism into chart basis.
        Gc=sp.simplify(A.inv()*G*A)
        deck.append((g.get("name","G"),Gc))
    return Q,A,sp.simplify(A.T*Q*A),deck
