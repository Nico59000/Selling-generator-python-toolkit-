from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Any
import sympy as sp

from .algebra import WALLS, homogeneous
from .seed import seed_matrices


@dataclass
class ProjectiveChart:
    q: sp.Symbol
    r: sp.Symbol
    gram_chart: sp.Matrix
    det: sp.Expr
    D0: sp.Expr
    wall_vector: sp.Matrix
    wall_polynomials: Dict[str, sp.Expr]
    x2: sp.Expr
    positive_correspondent: sp.Matrix
    global_projective: bool

    def as_jsonable(self) -> Dict[str,Any]:
        return {
            "coordinates":"q=z/x, r=-y/x",
            "gram_chart":[[str(x) for x in row] for row in self.gram_chart.tolist()],
            "determinant":str(self.det),
            "D0":str(self.D0),
            "x2":str(self.x2),
            "wall_order":list(WALLS),
            "wall_polynomials":{k:str(v) for k,v in self.wall_polynomials.items()},
            "global_projective":bool(self.global_projective),
        }


def build_chart(seed: Dict[str,Any]) -> ProjectiveChart:
    _Q,_A,Qc,_deck=seed_matrices(seed)
    q,r=sp.symbols("q r", real=True)
    u=sp.Matrix([1,-r,q])
    det=sp.factor(Qc.det())
    den=sp.factor((u.T*Qc.inv()*u)[0])
    D0=sp.factor(det*den)
    if det <= 0:
        raise ValueError("expected positive determinant for signature (+,--)")
    x2=sp.factor(det/D0)
    Qp=sp.simplify(2*x2*(u*u.T)-Qc)
    hh=homogeneous(Qp)
    # Multiplying all six homogeneous coordinates by the *same* D0 is
    # sign-preserving on the real hyperboloid sheet D0>0.  Do not
    # primitive-normalize the six coordinates independently: the certified
    # v50 6x6 wall-action matrices act on their common homogeneous scale.
    vec=[sp.factor(sp.cancel(D0*hh[k])) for k in WALLS]
    walls=dict(zip(WALLS,vec))
    wvec=sp.Matrix(vec)

    # x=0 plane cannot intersect if restriction of Qc^-1 to coordinates 2,3 is negative definite.
    B=Qc.inv()[1:3,1:3]
    det2=sp.factor(B.det())
    global_projective=bool(det2>0 and B[0,0]<0)
    return ProjectiveChart(q,r,Qc,det,sp.factor(D0),wvec,walls,x2,Qp,global_projective)
